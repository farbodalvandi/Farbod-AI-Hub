#!/usr/bin/env bash
set -euo pipefail
release_dir="$(cd "$(dirname "$0")" && pwd)"
target="${1:-}"
if [[ -z "$target" ]]; then
  echo "Farbod AI-Hub 26.0.0 — update your EXISTING Docker installation"
  echo "Enter the full path of the folder you currently use (without quotes)."
  read -r -p "Existing application folder: " target
fi
[[ -n "$target" && -d "$target" ]] || { echo "Existing folder not found. No files changed."; exit 1; }
target="$(cd "$target" && pwd)"
[[ -f "$target/app.py" && -f "$target/compose.yaml" ]] || { echo "Choose the existing application folder containing app.py and compose.yaml."; exit 1; }
if [[ "$target" != "$release_dir" && ( "$target/" == "$release_dir/"* || "$release_dir/" == "$target/"* ) ]]; then
  echo "Extract the update beside the existing folder, not inside it. No files changed."
  exit 1
fi
command -v rsync >/dev/null || { echo "rsync is required for a safe in-place update."; exit 1; }
# The running container still has its original code. Back up its live data before copying.
(
  source "$target/docker-macos/common.sh"
  require_docker
  echo "Creating a backup from the currently running application…"
  compose exec -T app python scripts/backup_data.py
)
if [[ "$target" != "$release_dir" ]]; then
  echo "Updating application files in: $target"
  rsync -a --exclude='.env' --exclude='.env.docker' --exclude='.venv/' --exclude='venv/' \
    --exclude='.git/' --exclude='__pycache__/' --exclude='.pytest_cache/' \
    --exclude='docker-data/' --exclude='instance/' --exclude='knowledge/' \
    --exclude='equipment_files/' --exclude='bank_connection_info/' --exclude='subobject_files/' \
    --exclude='profile_images/' --exclude='logs/' --exclude='runtime/' --exclude='backups/' \
    "$release_dir/" "$target/"
fi
# Existing environment and persistent paths continue to be used in the original folder.
exec bash "$target/docker-macos/update.command"
