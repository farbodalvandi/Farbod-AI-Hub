# Farbod AI-Hub 26.1.4

This update adds an administrator-only Backup & Restore workspace. Configure daily or weekly backups, choose an accessible destination, set retention, include optional ISO files, create and download verified backups, and validate an archive before preparing its restore. In Docker, mount a non-default external destination into the app container first. Apply restores only while the app and worker are stopped; the restore utility saves a safety backup first.

This update adds the optional Soft Glass theme, based on a pale frosted surface, navy text and soft navy shadows. It is selectable alongside Light and Dark and is remembered on the device. The login page uses a premium split layout and follows the selected theme. Infrastructure Copilot is now a compact in-flow bar that does not cover page controls. The Hardware Hub quick links now keep Command Center only.

Recorded server port connections now appear directly in the server profile and in the corresponding port fields in the server inventory row. The redundant Port connections column has been removed. The Asset 360° device panel marks connected ports and shows their destination. Occupied destination ports are removed from selectors and endpoint uniqueness is checked atomically. Network switches now open a dedicated 24/48-port front-panel view like SAN switches. Connected ports show their mapped destination, and port selection opens the existing two-sided connection editor. Network switches support 24 or 48 ports. Server add/edit forms include a PSU count (1–24); existing records without a count retain two ports until edited. Connected PSU ports must be disconnected before reducing the count.

# 25.9.0 — Reference-inspired visual refresh

Read READ_FIRST_FA.txt for safe in-place installation. Build identity: 26.1.4-port-assistant. AI Assist now answers direct SAN switch and server port-connection questions from the recorded physical cable map, including destination ports, fabric, and notes when available. This release retains the managed backup and restore workspace and existing equipment workflows.

# Farbod AI-Hub 25.8.6

Corrected UI release. Start with `READ_FIRST_FA.txt` or `UPGRADE_V25_6.md`.

# Farbod AI-Hub v25.5

Repair resolution now clears active error indicators; document previews support Knowledge and equipment Excel files; serialized warehouse receipts group devices under one parent while preserving individual serial numbers, asset tags and movements. Dark theme readability is improved.

Read [UPGRADE_V25_1.md](UPGRADE_V25_1.md) before updating. Existing data is preserved through additive migrations. XLS preview requires the new xlrd dependency.

# Farbod AI-Hub v25.0

Server inventory shows CPU and Memory; health can be marked Healthy/Resolved; asset profiles include a dated equipment change log with Excel export; Linux Health lets operators select individual read-only checks.

See [UPGRADE_V25.md](UPGRADE_V25.md) for upgrade and validation notes.

# Farbod AI-Hub v24.8.9

English / فارسی interface with RTL support, DellEMC branding and improved English technical-document search. Based on the v24.8.8 warehouse release with the existing Forest Green theme preserved.

Read [UPGRADE_V24_8_9.md](UPGRADE_V24_8_9.md) before updating. Use the English / فارسی buttons at the bottom of the page to change the interface language.

# Farbod AI-Hub v24.8.8 — Warehouse & Document Precision

Based on v24.8.7 Forest Green; the existing theme and login design are preserved.
See [UPGRADE_V24_8_8.md](UPGRADE_V24_8_8.md) for installation, permissions and validation notes.

- Storage: Unit (U) physical height and U Position; additive database migration.
- Offline manufacturer logos beside the selected name and in asset views.
- More precise Persian/English document retrieval, exact generation checks and longer cited excerpts.
- Warehouse: permanent unique stock codes, receipts/issues, required descriptions, transactional balances and retained movement history.

# Farbod AI Hub v24.8.4 — Linux Health Integration

The earlier v24.8.4 baseline is a FastAPI/Starlette/Uvicorn infrastructure workspace for asset management, knowledge, monitoring, Digital Twin and AI-assisted operations. It retains the v24.8 approved interface and fixes the dark, unresponsive Create Plan modal in Autonomous Operations. The Hardware Hub remains the default landing page after sign-in and now includes Linux Health. Light/Dark/System and the six existing accent presets remain available. See `UPGRADE_V24_8_2.md` for this fix and `UPGRADE_V24_7.md` for the earlier security changes.

The Docker stack includes the web application, background worker, rotated backups, health checks, native Ollama connectivity and optional Caddy HTTPS. It runs on Docker Desktop for macOS/Windows and Docker Engine on Linux.

See `UPGRADE_V24_8_3.md` for SSH trust setup and safe upgrade steps.

## Requirements

- macOS with Python 3.11 or newer
- VS Code with the Microsoft Python extension
- Optional: Ollama for locally generated AI answers
- Optional: Tesseract (`brew install tesseract`) for OCR

## Recommended Docker installation on macOS

Install and start Docker Desktop, extract the project to a permanent folder,
then control-click and open:

```text
DOCKER_SETUP.command
```

This builds the application image, starts the application, worker and backup containers, waits for a successful health check, then opens <http://127.0.0.1:8000>. On a brand-new database, sign in with `admin` / `admin123`. An explicitly configured bootstrap password overrides this default. Existing passwords are preserved.

Direct Docker Compose use no longer requires `.env.docker`; the setup script creates it only as a local override file.

```bash
docker compose ps
docker compose logs -f app
```

## Development setup

Open the extracted project folder in VS Code, then run:

```bash
chmod +x scripts/*.sh
./scripts/setup_macos.sh
./scripts/run_dev.sh
```

Open the URL printed in Terminal. On a new database, the initial login is `admin` / `admin123`, unless a bootstrap password override is configured. Existing users and passwords remain unchanged.

VS Code automatically uses `.venv/bin/python`. You can also press **F5** and
select **Farbod AI-Hub: Development** to run and debug the application.

## Daily development workflow

```bash
source .venv/bin/activate
python run_v20.py
```

Run tests before committing changes:

```bash
python -m pytest -q
```

## Native foreground execution

For stable LAN use:

```bash
./scripts/run_production.sh
```

The script-based foreground launcher remains available. Override its bind
address without modifying code:

```bash
FARBOD_ASSET_HOST=192.168.100.200 FARBOD_ASSET_PORT=443 ./scripts/run_production.sh
```

The recommended v15.2 service binds only to `127.0.0.1:8000`. Use a trusted
reverse proxy for HTTPS or remote access; see `macos/Caddyfile.example` and
`UPGRADE_V15_2.md`.

## Environment variables

See `.env.example` for standard local settings.

| Variable | Default | Purpose |
|---|---:|---|
| `FARBOD_ASSET_HOST` | `127.0.0.1` | Listen address |
| `FARBOD_ASSET_PORT` | `8000` in `.env` | Listen port |
| `FARBOD_DATA_DIR` | Application Support in production | Database and uploaded data location |
| `FARBOD_BACKUP_DIR` | Application Support backup folder | Rotated backup location |
| `FARBOD_BACKUP_RETENTION` | `14` | Initial number of archives to keep; adjustable in Backup & Restore |
| `FARBOD_BACKUP_SCHEDULE` | `daily` | Initial schedule: `manual`, `daily`, or `weekly` |
| `FARBOD_BACKUP_TIME` | `02:00` | Initial scheduled time in server-local time |
| `FARBOD_ASSET_TRUST_PROXY` | `0` | Trust proxy forwarding headers |
| `FARBOD_SECURE_COOKIES` | `0` | Mark session cookies HTTPS-only; enabled by HTTPS launcher |
| `FARBOD_SESSION_IDLE_SECONDS` | `1800` | Idle-session timeout |
| `FARBOD_SESSION_MAX_AGE_SECONDS` | `28800` | Maximum signed session-cookie age |
| `FARBOD_LOGIN_MAX_FAILURES` | `5` | Failed logins allowed within the login window |
| `FARBOD_PASSWORD_MIN_LENGTH` | `10` | Minimum length for new passwords |
| `FARBOD_BOOTSTRAP_ADMIN_PASSWORD` | admin123 | Optional first-run password override; custom values require 10 characters except the requested default admin123. |

AI settings can be changed from **System Settings → Local AI / Ollama**. Environment
variables in `.env.example` override saved UI values when you need a centrally
managed deployment. Install and start Ollama separately, download a model, set
the same model name in the UI, and choose **Ollama local LLM**. The application
continues to work in evidence-only mode when Ollama is not installed or offline.

## Project structure

```text
Farbod_AI-Hub/
├── app.py                  FastAPI routes and ASGI application
├── webcore.py              ASGI UI/session compatibility utilities
├── run_v20.py              Unified Uvicorn launcher
├── operations_v20.py       Control plane, agents, jobs and connector registry
├── worker_v20.py           Safe background planning/discovery worker
├── database.py             SQLite schema, migrations and queries
├── ai_engine.py            AI assistant integration
├── document_search.py      Knowledge indexing and retrieval
├── monitoring_connectors.py Infrastructure device connectors
├── paths.py                Resource and writable-data paths
├── requirements.txt        Runtime dependencies
├── requirements-test.txt   Development/test dependencies
├── macos/                  LaunchAgent, service controls and proxy example
├── scripts/                Setup, run and backup utilities
├── .vscode/                Debugger, interpreter and test settings
├── templates/              Jinja HTML templates
├── static/                 CSS, JavaScript, images and offline vendors
├── tests/                  Automated tests
└── instance/               Runtime database and keys (created locally)
```

## Docker on Linux

```bash
chmod +x SETUP_LINUX.sh
./SETUP_LINUX.sh
```

## Docker on Windows

Run in PowerShell from the extracted project folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\SETUP_WINDOWS.ps1
```

Runtime data, uploaded files, secrets and local virtual environments are excluded from Git. Back up the complete application data directory (including `instance/dcam.db`, `instance/secret.key`, profile images and uploaded data) together when moving the application to another host. Never commit `.env.docker`, bootstrap credentials, secrets or backups to source control.


Linux Health v24.8.4 adds FC to block device to multipath correlation, a QLA event timeline, current-tab scan comparison, chrony source/offset/Std Dev details, and a print/PDF report. See `UPGRADE_V24_8_4.md`.

## Version 26.1.2

Flexible 1–100 network switch ports, UPS inventory, configurable 1–12 server PSU counts, and model-only UPS assignments for server and storage power supplies are included. See `RELEASE_NOTES_V26_1_0.md` and `RELEASE_NOTES_V26_1_1.md`.
