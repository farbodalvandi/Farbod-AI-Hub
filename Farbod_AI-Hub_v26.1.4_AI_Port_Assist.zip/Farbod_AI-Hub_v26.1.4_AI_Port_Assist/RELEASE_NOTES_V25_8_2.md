# Farbod AI-Hub v25.8.4 — UI updates

Adds an optional Soft Glass theme inspired by the supplied reference: bright frosted surfaces, navy typography, soft navy shadows and a stronger navy action color. Users can select it alongside Light and Dark. The choice is saved on the current device and is supported on Linux Health as well.

The Infrastructure Copilot bar now stays compact and in the document flow across pages. It no longer overlays page controls. The Hardware Hub top shortcuts now show Command Center only. The login page has a premium split layout and follows the selected appearance. Authentication behavior and saved user data are unchanged.

The update preserves the v25.8.1 cabling and PSU-count features. Package validation checks Python compilation, JavaScript syntax, stylesheet/template wiring, Hub shortcut count, Copilot placement, and archive integrity. The optional pytest suite could not run because `pytest` is not installed in this environment.
