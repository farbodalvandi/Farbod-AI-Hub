# Farbod AI-Hub v25.8.4 — UI refinements

- Moved language selection into navigation/login controls so it no longer covers page content.
- Repositioned the login theme selector to the upper-right and standardized appearance controls in navy.
- Removed the login tagline “A clear view of every system.”
- Improved light-mode text contrast throughout Digital Twin Design Studio.
- Moved Online Users beside the account footer in the sidebar.
- Removed the ISO & Visio Library panel from Command Center.
- Retained Midnight Amber, Soft Glass and all existing application data and capabilities.
