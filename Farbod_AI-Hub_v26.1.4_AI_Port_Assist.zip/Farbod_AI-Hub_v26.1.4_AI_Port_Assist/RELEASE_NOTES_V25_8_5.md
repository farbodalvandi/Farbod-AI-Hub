# Farbod AI-Hub v25.8.6 — Port selection and compact inventory

- Server inventory no longer expands into many port columns; connections appear in a compact expandable cell.
- Network devices can be configured with 24 or 48 ports.
- Occupied ports are omitted from destination selectors. Atomic endpoint uniqueness checks prevent a port from being connected twice.
- Physical network ports are generated from the chosen switch capacity.

This release continues v25.8.4 and preserves its theme and interface refinements.
