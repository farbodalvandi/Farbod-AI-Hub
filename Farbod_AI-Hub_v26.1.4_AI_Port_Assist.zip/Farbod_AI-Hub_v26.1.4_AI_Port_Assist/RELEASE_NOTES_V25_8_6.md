# Farbod AI-Hub v25.8.6 — Automatic port visibility

- Removed the redundant Port connections inventory column.
- Server port destinations appear in the server row and Asset 360 technical profile.
- Connected jacks are highlighted in the Asset 360 device panel and display their destination.
- Unconnected ports retain their existing profile values.
- Existing cabling data and endpoint uniqueness rules are preserved.

See `READ_FIRST_FA.txt` for the in-place update steps.
