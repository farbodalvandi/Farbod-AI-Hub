# Farbod AI-Hub v25.8.7 — Network switch front panel

- Network devices with 24 or 48 ports now open a selectable front-panel view styled like the SAN switch panel.
- Connected ports are highlighted and display the recorded destination.
- Port selection opens the existing two-ended port map to connect, edit, or disconnect cables.
- Existing physical cabling records are preserved.

See `READ_FIRST_FA.txt` for the in-place update steps.
