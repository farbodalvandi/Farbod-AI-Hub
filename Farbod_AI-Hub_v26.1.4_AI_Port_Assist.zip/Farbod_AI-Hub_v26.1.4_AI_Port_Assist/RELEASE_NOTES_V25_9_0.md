# Farbod AI-Hub v25.9.0 — Reference-inspired visual refresh

- Applied a shared, calm light visual system across the app: neutral canvas, white rounded surfaces, soft shadows, pill-shaped navigation and controls, and stronger dashboard data cards.
- Kept the smoky Dark mode and the existing Midnight Amber and Soft Glass presets.
- Restored Light / Dark / System mode selection and the six existing accent colors: Amber, Electric Blue, Cyan, Emerald, Violet, and Ruby.
- Existing pages, data, permissions, and operating workflows are retained. No new infrastructure features were added.

See `READ_FIRST_FA.txt` for the in-place update steps.
