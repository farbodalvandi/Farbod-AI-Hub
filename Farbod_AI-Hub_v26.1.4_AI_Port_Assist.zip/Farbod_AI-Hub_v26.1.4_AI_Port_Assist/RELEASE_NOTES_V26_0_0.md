# Farbod AI-Hub v26.0.0 — Backup & Restore

- Added an administrator-only **Backup & Restore** page under Administration.
- Added manual, daily, and weekly schedules; server-local run time; configurable destination; retention from 1–365 archives; and optional ISO inclusion.
- Scheduled backups are driven by a shared scheduler in native runs and the Docker backup service. A filesystem lock prevents duplicate scheduled jobs when both are active.
- Backup archives are written to a temporary file, integrity-checked, then atomically published. Old archives are rotated according to the selected retention count.
- Added archive download and restore validation. Applying a restore requires stopping the app and worker; the CLI restore utility validates the SQLite database and creates a safety backup before replacing data.
- Existing v25.9.0 UI and equipment workflows are retained.

## Restore

In Backup & Restore, choose **Prepare restore** for a verified archive and follow the displayed command. Keep the application and worker stopped until the restore command completes. Start the app afterward and sign in with the account state contained in that archive.
