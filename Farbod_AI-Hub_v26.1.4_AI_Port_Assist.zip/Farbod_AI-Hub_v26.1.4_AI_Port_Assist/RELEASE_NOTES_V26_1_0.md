# Version 26.1.0 — Power and flexible port capacity

- Network switches support a user-defined port count from 1 to 100.
- Added UPS assets with capacity, topology, battery, management, rack, and status details.
- Server power supply count is configurable from 1 to 12.

