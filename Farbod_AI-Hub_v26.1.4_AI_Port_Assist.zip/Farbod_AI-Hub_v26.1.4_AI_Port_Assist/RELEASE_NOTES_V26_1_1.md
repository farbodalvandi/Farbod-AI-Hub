# Version 26.1.1 — UPS model assignments

- UPS setup no longer asks for outlet or port counts.
- Each server PSU (1–12) and each storage PSU (A/B) can be assigned to a UPS model.
- Multiple power supplies can be assigned to the same UPS.
- Asset profiles show each PSU assignment and UPS profiles list their connected devices.
- Existing v26.1.0 PSU-to-UPS outlet cable records are migrated to model-level assignments when the database opens.
- Assigned UPS devices cannot be deleted until their power supplies are reassigned.
