# Farbod AI-Hub v26.1.2

- Filter physical cabling destinations by port type: FC to SAN switches; Ethernet and management ports to Network Devices; SAS to storage; power supplies to UPS models.
- Assign each PSU directly to a UPS model. Multiple PSUs can share one UPS, without outlet or switch-port selection.
- Corrected the archive root folder to match v26.1.2.
- Marked macOS `.command` launchers executable in the ZIP archive.
