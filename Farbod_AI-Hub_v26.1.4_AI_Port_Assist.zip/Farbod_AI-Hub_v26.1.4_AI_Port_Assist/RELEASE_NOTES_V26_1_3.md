# Farbod AI-Hub v26.1.3

## Storage port connections in inventory
- Removed the standalone Port connections column from the beginning of the Storage inventory table.
- FC cable destinations now appear in the corresponding SPA PORT 0–3 and SPB PORT 0–3 columns, matching the Server inventory pattern.
- Management cable destination appears under Management IP.
- Preserved the compact inventory row layout.

## Packaging
- Launch and Docker command files are marked executable for macOS/Linux ZIP extraction.
