# Farbod AI-Hub v26.1.4 — AI Port Connection Answers

- AI Assist answers direct questions about physical SAN switch and server port connections using the recorded cable map.
- SAN switch FC ports and server NIC/HBA ports identify the connected device and its destination port.
- Fabric and connection notes are included when recorded; unconnected ports are reported explicitly.
- Port-map lookup uses the existing Asset Manager permission.
- Retains the v26.1.3 storage inventory port-column layout and prior offline deployment settings.
