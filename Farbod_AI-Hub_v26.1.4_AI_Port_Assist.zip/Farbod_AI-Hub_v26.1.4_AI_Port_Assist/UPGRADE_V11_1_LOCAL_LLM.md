# Upgrade v11 to v11.1 — Local LLM

No manual database conversion is required. On first start, Farbod AI-Hub adds
the AI settings and per-user conversation tables while preserving existing
assets, users, uploaded documents and monitoring records.

1. Back up `instance/dcam.db`, `instance/secret.key`, `knowledge/` and the other
   upload folders.
2. Replace the source files with this package, but keep the backed-up runtime
   data folders.
3. Start the application once so the database migration runs.
4. Sign in as an administrator and open **Setting → Local AI / Ollama**.
5. Select `Ollama local LLM`, enter the local URL and an installed model name,
   then save. The status label confirms whether the service and model are ready.

`Grounded` is the recommended enterprise mode: answers must use permitted local
evidence and citations. `Hybrid` may use the model's general knowledge when no
local evidence matches, and the interface displays a warning in that case.
