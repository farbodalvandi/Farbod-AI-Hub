# Farbod AI-Hub 12.0 — Intelligent Datacenter Workspace

## Delivered

- Shared spatial UI layer: raised surfaces, responsive cards, dark/light theme integration, visible keyboard focus, reduced-motion support. Existing offline assets remain local.
- Global Copilot dialog in authenticated workspaces, including the standalone Hub, Knowledge, Equipment and Settings pages. Open with the floating button or Command/Ctrl+K. Native dialog supplies keyboard focus containment and Escape dismissal.
- Copilot uses the existing permitted-source query pipeline, supports Persian/English, shows source links, preserves each conversation in the existing per-user history, and links to full evidence/history. New chat starts a separate conversation.
- Progressive text reveal **after generation finishes**. This is not real token streaming; reduced-motion users see complete text immediately.
- Dashboard health distribution and readiness cards derive from actual inventory/index counts. AI runtime availability is checked independently. Inventory status is not live monitoring; unknown states remain visible. Capacity is explicitly unavailable instead of inferred from disk descriptions.
- Admin-only `/diagnostics` checks SQLite integrity, index coverage, model connectivity/installation, application version, current HTTP/HTTPS transport and AI safety boundaries. Checks are read-only and do not probe devices.
- Persistent, atomic per-user AI rate limiting (20 requests per minute) shared across WSGI workers. HTTP 429 includes Retry-After. Trusted deployments may set Flask config `AI_REQUESTS_PER_MINUTE` before serving.
- AI audit events contain provider, result counts, duration and fallback status, not questions or document content. Existing chat history still stores question/answer content. Failures and rate limits are audited. Local AI settings updates now require a CSRF token.
- Additive `ai_request_limits` table/index; existing assets, attachments, settings and chat history are unchanged.

## Safe upgrade

1. Stop the application. Back up the entire writable data directory, including `instance/dcam.db`, `instance/secret.key`, document index and all uploaded-file directories. Keep the secret key with the database: encrypted monitoring credentials depend on it.
2. Extract this release into a new code directory. Keep the original code/data backup intact. Do not copy a fresh empty database over your existing database.
3. Point `FARBOD_DATA_DIR` at the existing data directory before starting. If you previously stored data alongside the code, use that old directory as the data directory.
4. Use the existing virtual environment or install `requirements.txt` via your approved offline mirror. No new Python dependencies are required by v12.
5. Start using the existing macOS development/production scripts. The additive migration runs at startup.
6. Sign in as admin, open Diagnostics, check the database/index, and configure Ollama in Settings. Download model weights separately when internet is available; this package does not contain an LLM.
7. Confirm an existing asset, uploaded document and conversation, then test a Copilot question. For remote access, configure a trusted HTTPS reverse proxy; port 443 alone does not provide TLS.

Rollback: stop v12 and restore the backed-up code/data set. Never restore a database while the application is running.

## Deliberate limits

This is a stable first v12 increment, not every item in the long-term roadmap. Retrieval remains the existing lexical/ranked passage search with optional Ollama grounding; no embedding/vector engine was added. OCR uses the existing optional Tesseract/PDF dependencies. True server token streaming, automated document classification, live capacity telemetry, scheduled monitoring agents, fine-grained per-document ACLs and comprehensive backup/restore UI remain future work. Existing topology and asset-detail screens remain available; no new live 3D rack simulator is claimed.

The AI cannot execute device commands. Prompt instructions and citation validation reduce risk but cannot guarantee resistance to all prompt injection or hallucinations. Treat recommendations as untrusted until verified against the linked source/vendor documentation. Grounded mode may fall back to excerpts when Ollama is unavailable or returns invalid citations.

## Verification

Run `python -m unittest discover -s tests -v` in a Python environment with `requirements-test.txt` installed. New tests cover shared Copilot rendering, admin diagnostics, additive migration and rate limiting. `node --check static/workspace.js` validates browser script syntax. Test fixtures use temporary data; do not run against production data.

## خلاصه فارسی

نسخه ۱۲ ظاهر یکپارچه‌تر، دستیار شناور در صفحات برنامه، نمودار وضعیت واقعی موجودی، کارت آمادگی اسناد و صفحه عیب‌یابی مخصوص مدیر دارد. با ⌘K یا Ctrl+K دستیار را باز کنید. مدل محلی همچنان از Ollama تأمین می‌شود؛ مدل داخل فایل برنامه قرار ندارد. پاسخ‌ها پس از تکمیل تولید، تدریجی نمایش داده می‌شوند و استریم واقعی نیستند. اطلاعات قبلی با مهاجرت افزایشی حفظ می‌شوند، اما قبل از ارتقا از کل پوشه داده و کلید secret.key پشتیبان بگیرید. ظرفیت زنده، جست‌وجوی برداری و اجرای خودکار عملیات در این نسخه اضافه نشده‌اند.
