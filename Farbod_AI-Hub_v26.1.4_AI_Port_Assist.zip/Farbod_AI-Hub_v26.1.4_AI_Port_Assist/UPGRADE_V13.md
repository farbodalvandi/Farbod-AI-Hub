# Farbod AI-Hub v13 — Agentic Datacenter

v13 is the migration bridge between the v12 Flask application and the Flask-free v14 architecture.

## Added
- FastAPI `/api/v2` bridge for all new AI-facing APIs.
- Deterministic specialist Agent Router: Server, Storage, SAN, VMware, Network, General Infrastructure.
- Explicit read-only tool plans; no infrastructure mutation is executed.
- RAG service facade so v14 can swap the current index for embeddings/vector search without changing agent contracts.
- Updated v13 Agentic Edition login and home workspace messaging.
- Dual-runtime development launcher (`run_v13.py`).

## Safety boundary
v13 agents may search, reason and plan. Infrastructure-changing actions remain disabled. v14 can add approval-gated actions with RBAC and audit.

## Run
`pip install -r requirements.txt`

Legacy UI: `python app.py`

Agentic API: `uvicorn api_v2.main:app --host 127.0.0.1 --port 8000`

Or development bridge: `python run_v13.py`
