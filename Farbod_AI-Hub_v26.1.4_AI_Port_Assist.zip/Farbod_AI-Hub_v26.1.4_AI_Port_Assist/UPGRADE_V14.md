# Farbod AI-Hub v14 — Native FastAPI

Version 14 completes the migration started in v13. Flask and the dual-process
bridge have been removed. The UI, authentication, asset manager, knowledge
base, monitoring, diagrams and agent APIs now share one FastAPI/Starlette ASGI
runtime.

## Architecture

- FastAPI application with Uvicorn
- Starlette sessions, static files and responses
- Jinja2 server-rendered UI (existing v13 appearance preserved)
- SQLite data model and existing data directories preserved
- Native `/api/v2` Agentic Datacenter router
- OpenAPI UI at `/docs` and ReDoc at `/redoc`
- HTTPS/443 and self-signed certificate support retained

## Run on macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run_v14.py
```

For development without privileged port 443:

```bash
FARBOD_ASSET_PORT=8443 python run_v14.py
```

Open `https://127.0.0.1:8443` (or port 443 when configured). The first
self-signed certificate produces a normal browser trust warning.

## Data compatibility

Existing `instance/dcam.db`, uploaded knowledge files, equipment files and
certificates remain compatible. Back up the writable data directory before a
production upgrade.
