# Version 14.1 — Administrator and session fixes

- Added a prominent **Log out** action to the main Hub header and Administrator page.
- Administrators can now rename users, change roles, reset passwords, and toggle account status.
- Added user deletion with confirmation.
- Prevented deletion or deactivation of the account currently in use.
- Prevented removal of the final active Administrator account.
- Added validation for usernames, passwords, roles, and duplicate usernames.
- Preserved the active session when an Administrator renames their own account.

Existing databases are compatible and are not replaced during this upgrade.
