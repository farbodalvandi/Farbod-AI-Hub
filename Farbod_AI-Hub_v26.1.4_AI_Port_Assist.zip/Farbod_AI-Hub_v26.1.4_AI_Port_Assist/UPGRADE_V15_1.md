# Farbod AI Hub v15.1 — Command Center UI

Version 15.1 keeps the v15 AI Operations architecture and introduces a new
enterprise visual system.

## What changed

- Reorganized the primary navigation into Command Center, Infrastructure,
  AI Operations, Knowledge, Automation and Administration.
- Kept Server, Storage, SAN and Network categories inside Asset Workspaces
  instead of duplicating them in the primary navigation.
- Rebuilt the dashboard as a Command Center using real inventory, health,
  knowledge coverage, activity and AI runtime data.
- Added a compact Digital Twin overview and an evidence-grounded Copilot card.
- Added responsive desktop, tablet and mobile layouts.
- Added a dedicated v15.1 design system in `static/command-center.css`.
- Reworked Light Mode with opaque surfaces, dark text, visible field borders,
  explicit disabled states, zebra tables and accessible focus indicators.
- Preserved Dark Mode, RBAC, audit logs, AI workflows, ISO/Visio management and
  all existing v15 backend behavior.

## Run on macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run_v15.py
```

Open the URL printed in Terminal. Theme choice and sidebar state are stored in
the browser.

## Verification

The v15.1 package passes all 25 automated application and search tests.

