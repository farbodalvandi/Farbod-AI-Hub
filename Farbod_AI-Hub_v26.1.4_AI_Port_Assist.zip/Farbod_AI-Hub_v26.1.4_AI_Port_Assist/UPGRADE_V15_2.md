# Farbod AI Hub v15.2 — Production Runtime

Version 15.2 preserves the complete v15.1 Command Center and adds a professional
macOS operating model.

## One-time macOS installation

1. Extract the ZIP to a permanent folder. Do not move it after installation.
2. Control-click `INSTALL_ON_MAC.command`, choose **Open**, and confirm macOS.
3. The installer creates `.venv`, installs dependencies, creates `.env`, moves
   mutable data to Application Support, installs two user LaunchAgents and opens
   the application.

No administrator or root access is required for the default local HTTP service.

## Daily use

- `START_FARBOD_AI_HUB.command`
- `STOP_FARBOD_AI_HUB.command`
- `RESTART_FARBOD_AI_HUB.command`
- `STATUS_FARBOD_AI_HUB.command`
- `macos/backup_now.command`

The service starts automatically when the user signs in to macOS and restarts
automatically after an unexpected failure.

## Persistent locations

- Data: `~/Library/Application Support/FarbodAIHub`
- Logs: `~/Library/Application Support/FarbodAIHub/logs`
- Backups: `~/Library/Application Support/FarbodAIHub Backups`
- LaunchAgents: `~/Library/LaunchAgents/com.farbod.aihub*.plist`

The database and encryption key are backed up together. ISO files are excluded
by default because they can be very large. Set `FARBOD_BACKUP_INCLUDE_ISO=1` in
`.env` only when ISO backup storage is available.

## HTTPS

The application intentionally listens on `127.0.0.1:8000` by default. This is
safe for local use and avoids the macOS AirPlay conflict on port 5000.

For trusted HTTPS on port 443, install Caddy separately and use
`macos/Caddyfile.example`. After the proxy is verified, set
`FARBOD_ASSET_TRUST_PROXY=1` in `.env` and restart the service. For enterprise
networks, replace Caddy's internal certificate with a certificate issued by the
organization's CA.

## Uninstall service

Run `macos/uninstall_service.command`. It unloads the services and moves their
definitions to Trash. Application data, backups and source files are preserved.

## Administrator visibility

Open **Administration → Runtime Status** to inspect uptime, PID, Python version,
database size, disk capacity, endpoint, storage paths, backup path and runtime
logs. Host restart controls remain local to macOS by design.
