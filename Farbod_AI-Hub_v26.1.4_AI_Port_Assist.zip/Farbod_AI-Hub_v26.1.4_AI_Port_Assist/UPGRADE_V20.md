# Upgrade to Farbod AI Hub v20.0

Version 20 upgrades v15.3 without deleting its SQLite inventory, uploaded
knowledge, encrypted monitoring credentials or audit history. The v20 schema is
additive and is created automatically at startup.

## What is new

- Enterprise Control Plane and new post-login landing page
- Eight specialist infrastructure agents
- Human-in-the-loop risk policy and administrator approval gate
- Persistent Job & Approval Center with a background worker
- Read-only multi-vendor Connector Framework
- Digital Twin overview plus the existing editable dependency graph
- Correlated event stream and v20 health API
- Docker launchers for macOS, Linux and Windows
- ARM64 and AMD64-compatible Linux container image

## Safe upgrade from v15.3 Docker

1. Stop the old stack but do not delete `docker-data`.
2. Copy the existing `docker-data` folder into the v20 project folder.
3. Run the setup command for your operating system.
4. Sign in and verify **Runtime Status**, **Control Plane** and **Audit Logs**.

The first v20 start creates a SQLite WAL file beside `dcam.db`. Always back up
the complete data directory rather than copying only an open database file.

## Safety boundary

The included worker performs read-only discovery and plan generation. It never
changes a server, storage array, SAN switch, hypervisor or network device.
Vendor credentials remain in the encrypted Monitoring workspace. Future
device-changing adapters must be installed explicitly and remain subject to
the approval gate.

## Start commands

macOS: open `DOCKER_SETUP.command`

Linux:

```bash
chmod +x SETUP_LINUX.sh
./SETUP_LINUX.sh
```

Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\SETUP_WINDOWS.ps1
```

Open <http://127.0.0.1:8000> and change the initial `admin` password.
