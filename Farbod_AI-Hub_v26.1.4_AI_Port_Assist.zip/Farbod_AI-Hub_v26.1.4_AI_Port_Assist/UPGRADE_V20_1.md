# Farbod AI Hub v20.1
- AI Operations top spacing fixed.
- Asset Workspace category submenus added.
- Autonomous Ops active navigation fixed.
- Operation plan repeatable parameters added and persisted in evidence.
- Back to Hub added to shared top bar.
- Modal stacking/pointer interaction hardened for Administration/dialogs.
- Digital Twin relationship repeatable parameters added.
- Asset 360 technical profile scrolling added.
