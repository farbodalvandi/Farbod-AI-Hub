# Farbod AI-Hub v23.2 — Functional Fix Release

- Fixed Add/Edit Equipment interaction layer, including Rack entry forms.
- Added a Digital Twin workspace tile directly to the Farbod AI-Hub home page.
- Hardened modal stacking, pointer interaction, field enabled state and equipment-form scrolling.
- Preserved V23 Command Center design and existing modules.
