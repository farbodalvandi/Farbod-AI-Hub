# V23.3 Import Upload Fix

- Replaced Bootstrap-driven Asset Import modal with a standalone interactive overlay.
- Removed dependency on modal backdrop/focus trap for file selection.
- Restored a visible native file input for reliable CSV/TXT/XLSX selection on macOS, Windows and Linux.
- Preserved existing server-side import endpoint and column matching.
