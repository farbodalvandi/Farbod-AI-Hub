# Farbod AI-Hub v24.0 — Stability Release

This release replaces the Asset Add/Edit and Import windows with standalone overlays that do not use Bootstrap modal backdrops or focus traps. This removes the repeated pointer/mouse interception issue across asset categories, including Rack. The import file picker is a native visible file input and supports CSV/TXT/XLSX through the existing backend. Digital Twin remains available from the Hub home page.

Validation performed: Python compile checks, template structural checks, overlay isolation checks, and verification of asset import backend support. Full browser/device acceptance testing still requires running the application in the target Docker/browser environment.
