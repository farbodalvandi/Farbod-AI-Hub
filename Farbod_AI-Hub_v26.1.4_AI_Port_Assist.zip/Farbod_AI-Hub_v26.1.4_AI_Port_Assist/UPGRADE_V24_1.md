# V24.1 — UX + Asset Intelligence Release

- Copilot launcher moved from the lower floating button to a fixed top AI strip so it no longer covers page controls.
- Left navigation redesigned with flatter information architecture, descriptions, clearer grouping and friendlier hover/active states.
- Added deterministic Rack Capacity Engine. Questions about free/available U in a named rack are calculated directly from live rack + asset placement data rather than guessed by the LLM.
- Fixed FastAPI compatibility Upload wrapper (`tell`, seekability) and XLSX import now passes the underlying binary stream to openpyxl.
- CSV import behavior preserved.
