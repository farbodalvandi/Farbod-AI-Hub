# Farbod AI-Hub v24.3 — Settings / Users Separation

This release is a UI/UX architecture correction. It does not add a new product capability.

## Changed
- System Settings and User & Access Management are now two independent pages using the same application shell.
- `/settings` contains only existing system/AI configuration.
- `/users` contains all existing user create/edit/delete/password/role/status management.
- User CRUD actions now return to `/users` instead of mixing the user workflow back into `/settings`.
- Administration navigation exposes `Users & Access` and `System Settings` as separate destinations.
- Removed the standalone Settings HTML shell and duplicate Copilot/theme/logout shell from Settings; the page now extends `base.html` like the rest of the application.
- Rebuilt the User Management table with valid HTML and responsive behavior.

## Preserved
- Existing account roles and permission checks.
- Existing user management endpoints and database operations.
- Existing AI settings endpoint and AI configuration behavior.
- Existing backend asset, monitoring, knowledge, automation and AI behavior.
