# v24.4 UI refinement

This update changes presentation code only. Existing endpoints, forms, permissions, imports, and backend behavior are preserved.

- Removed the duplicate synchronized horizontal scrollbar and its JavaScript from inventory tables. The existing table container is the sole scroll surface.
- Improved inventory row contrast in light and dark themes, including alternate rows and hover states.
- Added explicit labels to inventory search, selection checkboxes, and asset editor fields.
- Improved administration form and table readability, button sizes, and compact mobile layout.
- Improved mobile navigation visibility and Escape dismissal, and made the theme toggle announce its next action to assistive technology.

Verification: Python source compilation; inventory scroll implementation inspected for duplicate controls. Full browser and template rendering require the app's dependencies and a running instance.
