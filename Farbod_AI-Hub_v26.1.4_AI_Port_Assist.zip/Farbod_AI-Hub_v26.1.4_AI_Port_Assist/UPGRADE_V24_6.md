# Farbod AI-Hub 24.6 — Theme & Profile Refinement

This release is based on v24.5 Liquid Glass. Existing asset, AI, monitoring, digital twin, knowledge, administration and operations behavior is preserved.

## Appearance refinement

- Removed the photographic data-center / globe background treatment from the active UI.
- Added one shared appearance system across Login, the application shell, Farbod AI / Copilot, Command Center, Hardware Hub and legacy standalone workspaces.
- Theme modes: Light, Dark and System.
- Tested accent presets: Amber, Electric Blue, Cyan, Emerald, Violet and Ruby.
- Theme and accent are stored locally in the browser and do not change backend behavior or application data.
- Dark mode uses a neutral smoky graphite base; light mode uses a clean neutral glass base.
- Legacy fixed purple/blue AI styling is bridged to the selected accent where it represents emphasis rather than semantic status.
- The sidebar includes a Theme option, and the Login / top bar include an appearance control.

## Profile photo

Profile photo upload is the single explicitly approved functional addition in this release.

- Each signed-in user can upload or remove their own profile photo from the top-right profile menu.
- Accepted formats: JPEG, PNG and WebP.
- Maximum upload size: 2 MB.
- File contents are validated by image signature; SVG and executable formats are not accepted.
- Images are stored under the writable application data directory in `profile_images/`, not in the read-only container image.
- The database stores only the generated filename in the existing `users` record.
- Profile images appear in the top bar, sidebar, online users panel, Hardware Hub and Users & Access page.
- Profile images are included in normal application backups.

## Docker

The default Docker image tag is now `farbod-ai-hub:24.6` so `docker compose ps` reports the running release clearly.
Keep the existing `/data` volume when upgrading so all assets, knowledge, settings and user data remain intact.
