# Farbod AI-Hub v24.8.2

## Agent operation-plan modal fix

- Fixed the dark, unresponsive **Create plan** window in **Autonomous Ops → Jobs & Approvals**.
- Restored typing and selection in all plan fields.
- Restored **Add parameter**, parameter removal, and JSON synchronization on submit.
- Added modal accessibility labels and a scrollable dialog for smaller screens.

The fix is UI-scoped and does not change the existing agent, approval, connector, or backend behavior.
