# Farbod AI-Hub v24.8.3 — Linux Health

This update starts from v24.8.2 and adds an eighth Hardware Hub card, **Linux Health**. Its page and API use AI-Hub's existing login session and CSRF protection. Fixed read-only SSH checks cover CPU load, memory, filesystem capacity, inode use, failed services, recent kernel errors, network evidence, time sync, multipath and QLogic HBA events. The appearance follows the existing Light/Dark/System mode and six accent presets. Existing module routes and database schema are unchanged.

## Upgrade without losing data

1. Back up the current `docker-data/data` and `docker-data/backups` directories and retain the existing `.env.docker` and signing secret. Do not delete or replace these during the upgrade.
2. Extract the new source files into your existing project folder while preserving the directories above. If using a separate new folder, copy those directories and `.env.docker` into it before starting containers.
3. From the project folder, run `docker compose --env-file .env.docker up -d --build app worker backup` (or use `DOCKER_UPDATE.command` on macOS). Existing users, passwords, and records remain in the preserved data directory.
4. Open Hardware Hub and select **Linux Health**. The normal AI-Hub login is required; there is no second application token.

## Trust the SSH host key

The diagnostic account should have the least permissions needed for read-only checks. The application rejects SSH servers unless their host keys are in `docker-data/data/ssh/known_hosts`. Verify a server's key fingerprint independently through its console or your administration records before adding it. On macOS/Linux, after verifying:

```bash
mkdir -p docker-data/data/ssh
ssh-keyscan -H 10.10.10.25 >> docker-data/data/ssh/known_hosts
chmod 755 docker-data/data/ssh
chmod 644 docker-data/data/ssh/known_hosts
```

For a non-default SSH port use `ssh-keyscan -p PORT -H SERVER`. On Windows, create `docker-data/data/ssh/known_hosts` with verified OpenSSH host-key entries and ensure the container's configured user can read it. The file lives in the existing `/data` volume, so image rebuilds do not remove it. `FARBOD_LINUX_HEALTH_KNOWN_HOSTS` can override its location for native deployments; Docker defaults to `/data/ssh/known_hosts`.

If `/var/log/messages` is unreadable, QLA results show **Unknown**. A QLA event is mapped to a Linux `hostN`, WWPN and PCI function when the log contains an identifier; the SAN switch's physical port still requires fabric-side lookup. No commands are entered by users and there is no automatic remediation.

The user-facing page is `/linux-health`. The API is `/api/linux-health/diagnose`; it requires the active AI-Hub session and CSRF token. At most two diagnostic SSH jobs run concurrently so a slow endpoint cannot monopolize the web server.
