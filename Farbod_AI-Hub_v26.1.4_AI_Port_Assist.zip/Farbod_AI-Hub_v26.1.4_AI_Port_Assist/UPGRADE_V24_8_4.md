# Farbod AI-Hub v24.8.4 — Linux Health diagnosis

Based on v24.8.3. Existing routes, authentication, themes and other modules remain intact.

- FC topology correlates QLogic `fc_host` WWPN and port state with SCSI block devices and visible multipath map/WWID. A missing map is reported as unknown rather than a failed path; expected array path counts still require operator verification.
- QLA errors in the scanned `/var/log/messages` window form a reverse chronological 24-hour timeline. The interpretation relates QLA and multipath findings as a hypothesis, not an asserted root cause. If logs are unreadable, the timeline is empty.
- Comparison uses the prior scan of the same host, SSH port and account in the current browser tab. It compares check status, FC state and visible block paths. It is cleared on page reload and stores no SSH password or evidence.
- Chrony reports RefID, selected source, last/RMS offset, source Std Dev (jitter estimate) and root dispersion when `chronyc` and `chronyd` are available. The original `timedatectl` check remains.
- Print / Save PDF uses the browser print dialog and includes evidence. Treat generated reports as sensitive because they may contain hostnames, WWPNs, WWIDs and logs. No report is saved on the server.

The default scan remains fixed and read-only. A `sos report` is **not** run automatically: it creates a potentially sensitive archive on the target server and can take substantial time. If support requires it, run `sos report` under an authorized administrator account and sanitize the archive with the platform tools before sharing. Oracle Linux 6 uses `sosreport` if installed; availability varies by host.

To use the topology view, the SSH account needs readable `/sys/class/fc_host`, `/sys/class/scsi_device` and access to `multipath -ll`. QLA timeline requires access to `/var/log/messages`. Restricted access is reported as incomplete evidence.
