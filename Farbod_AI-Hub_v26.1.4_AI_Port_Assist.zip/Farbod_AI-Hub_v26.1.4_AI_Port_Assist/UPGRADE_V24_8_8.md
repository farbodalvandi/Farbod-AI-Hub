# v24.8.8 — Warehouse & Document Precision

## Upgrade an existing Mac Docker installation

1. Keep Docker Desktop running. In the CURRENT application folder, run `bash docker-macos/backup_now.command` and confirm the backup succeeds.
2. Extract this ZIP over the source files in that SAME application folder. Do not delete or replace `docker-data`, `.env.docker`, `.env`, or existing persistent-data paths. This release contains source and example settings only, with no credentials or user databases.
3. From the current application folder, run:

   ```bash
   bash docker-macos/update.command
   ```

   This takes another backup, builds the app/worker/backup images, then recreates the containers. The existing account/password and mounted data remain in use. A Docker build requires dependencies to be available through your configured network/package mirror.
4. Refresh the browser. Confirm version 24.8.8 and open Warehouse from Hardware Hub or the sidebar.
5. Database migration runs automatically. The first document query reindexes existing documents with the new search rules; large collections can take longer on the first request. Check document coverage/OCR warnings in AI before relying on a result.

For Windows/Linux Docker, retain the same existing compose environment and persistent mounts, back up, rebuild and recreate app/worker/backup with your existing compose command. No architecture-specific binary dependency was added.

## Storage and brand display

`Unit (U)` is the physical rack height (for example `2` or `2U`). `U Position` is the starting rack position. Both appear in storage add/edit/detail/list, and exports follow the schema. Explicit rack height is used by rack visualization and the capacity helper.

Manufacturer previews show locally bundled HPE, HP, Dell (also Dell EMC/EMC), Cisco, NetApp, IBM, Huawei, Lenovo and Broadcom marks. Standard seven manufacturer defaults are covered. Custom/unrecognized brands remain text; no incorrect logo is substituted. Adding an arbitrary new brand does not automatically download its logo. No network request is needed to display bundled logos.

## Warehouse

- Admin and manager: register equipment and post receipts/issues. Operator: view/search/history only, consistent with existing asset edit permissions.
- Each equipment entry has a unique permanent stock code (automatic `WH-…` or a user-entered code), name, brand, model, optional serial, location and required description.
- New equipment starts at zero. Every balance change must use an IN or OUT transaction with positive integer quantity and a nonblank explanation.
- Optional supplier/recipient/destination and document/ticket reference are recorded.
- Serial-numbered equipment is limited to one on-hand unit per code. Bulk parts use a code without a serial number.
- Each movement retains quantity, before/after balance, explanation, user and UTC timestamp. Stock changes, ledger inserts and system logs commit together.
- An immediate SQLite transaction prevents concurrent over-issue. Submission tokens prevent identical request replays. They are not a substitute for reviewing separate, intentionally submitted transactions.
- Posted history has no edit/delete action and is protected by database triggers. Correct mistakes with a compensating movement that references the original entry. Warehouse history is independent of the 30-day system-log cleanup.
- Warehouse items are separate from installed assets; this release does not automatically move or remove an Asset Manager record when stock is issued.

## AI behavior and limits

- Normalizes Persian memory expressions (including «رمی»), DIMM terms, `Gen 12`, `G12`, and joined model/generation names.
- Keeps model and generation anchors, prioritizes relevant technical sections, rejects mismatched-generation passages and conservatively avoids ambiguous mixed-generation sections.
- Up to six passages per document, with longer excerpts and page/source citations. Missing model in a follow-up can be resolved from the recent user question.
- For compatibility questions, installed inventory is not used as evidence of supported specifications. Missing document evidence produces an explicit insufficiency answer, including in hybrid mode.
- Ollama instructions require the exact model/generation and separate memory type/capacity/speed and evidenced restrictions. Without Ollama, the app provides cited source excerpts, not synthesized model answers.
- Citation validation checks IDs, not the factual truth of every model sentence. These changes improve retrieval and grounding; they do not guarantee every answer is correct.
- The user's actual DL380 Gen12 document and configured model were not supplied in this workspace. Test that document after upgrade; no real DL380 Gen12 RAM specification is hardcoded.

## Verification

Eight new tests passed: migration with existing storage data, inventory validation, replay prevention, concurrent issue control, stock-code uniqueness/serialized stock, Persian retrieval/generation separation, missing-evidence behavior, follow-up context and application routes/permissions/CSRF (some checks share a test).

The existing 26 search tests passed. Linux Health integration is run separately because the legacy search test suite changes global database paths without restoring them across test modules.

Tests ran on Linux/Python 3.12 with FastAPI 0.128.2 and isolated test dependencies; no Docker Desktop/macOS runtime was available for a full container build. The production dependency manifest remains unchanged. Run `python -m pytest tests/test_v2488.py -q` with the app/test requirements installed. Run legacy test modules in separate processes.
