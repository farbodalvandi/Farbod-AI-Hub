# Farbod AI-Hub v24.8.9 — DellEMC, English Search & Persian UI

## Upgrade on your Mac

Keep Docker Desktop running and use the existing application folder and data paths.

1. Run `bash docker-macos/backup_now.command` in the current application folder and confirm success.
2. Extract this release over the source files in that same folder. Preserve `docker-data`, `.env.docker`, `.env` and your configured persistent-data paths.
3. Run `bash docker-macos/update.command` in that folder. It creates a backup, rebuilds images and recreates the services.
4. Refresh the browser. Confirm version 24.8.9. Existing accounts and passwords remain unchanged.

## Language

Use the fixed **English / فارسی** control at the bottom of the login page and application pages. It reloads the current page with the selected language; save an open form before switching. The preference is stored in an HTTP-only browser cookie for one year and survives logout. It is per browser, not synchronized between devices. English remains the default.

The Persian interface uses right-to-left layout and a local RTL Bootstrap stylesheet. Navigation, static page text, common controls, equipment field labels, warehouse screens, settings and many dynamic UI labels use a local Persian catalog. Technical identifiers, model names, IPs, user-entered data, original documents, raw command output and diagnostic evidence are not translated. Some generated technical messages and uncommon dynamic descriptions remain in their original language. AI answers continue to follow the language of the question rather than forcing the UI language. No translation service or additional network connection is required.

## DellEMC

The default Dell manufacturer becomes DellEMC. The additive migration consolidates Dell/Dell EMC/DellEMC/EMC lookup aliases and updates existing equipment and warehouse manufacturer fields without changing equipment IDs, model names, serials or inventory balances. Historical ledger and audit records are preserved. The UI bundles the combined Dell EMC logo and displays it for those aliases.

Logo provenance: Dell Technologies; Wikimedia Commons, File:Dell_EMC_logo.svg; PD-textlogo, subject to trademark. See static/brands/README.txt.

## English technical questions

Improved normalization for `Gen 12`, `Generation-12`, `G12`, `DL380-Gen12`, `DL380Gen12` and `DL 380`; memory terminology includes DIMM/RDIMM/LRDIMM/UDIMM/MRDIMM plurals. English question filler words no longer dominate relevance scoring. Questions about memory type, maximum capacity and compatible modules are treated as specification questions even if they omit the word "support". Installed inventory is not treated as proof of supported hardware.

The first search reindexes existing documents for the updated rules. Model/generation constraints and source/page citations remain in force. With local evidence mode, the app shows source excerpts; synthesized grounded answers require a configured Ollama model. Missing evidence produces an explicit insufficiency message. This is not a guarantee that every generated answer is correct. The actual user DL380 Gen12 document and local model configuration were not available for verification.

## Verification

46 tests passed: 20 current-release/warehouse tests plus 26 existing search tests. Current checks include eight English RAM-question variants, wrong-generation exclusion, DellEMC migration idempotency, English↔Persian switching, RTL stylesheets, source-data preservation, cookie persistence through logout, CSRF and supported-language validation, and application route rendering. All 10 application JavaScript files passed syntax checks and all Jinja templates parsed.

Tests used Linux/Python 3.12, FastAPI 0.128.2 and isolated test dependencies. A full Docker Desktop/macOS build and browser screenshot review were not performed. Production requirements remain unchanged. Run legacy search test modules in separate processes because they change global database paths.
