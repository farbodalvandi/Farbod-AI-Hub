# Farbod AI-Hub v25.0

## Changes
- Server profile labels CPU and Memory while retaining existing CPU/RAM data.
- Server status choices include Healthy and Resolved; both display as healthy.
- Equipment profiles include a dated change log for hardware changes such as memory upgrades. Export each device's history to Excel.
- Linux Health provides selectable read-only checks. At least one check must be selected; passwords remain transient and are not saved.

## Upgrade
1. Back up the application data directory and database.
2. Stop the current service/container and extract this release over a separate application folder.
3. Keep the existing data directory and `.env` settings; do not replace them with sample files.
4. Start the application using the existing platform instructions.
5. Confirm the displayed version is 25.0, existing server inventory and RAM values remain present, a change record can be added/exported, and selected Linux checks appear in the report.

The database schema is additive/compatible. Existing RAM values are preserved under the same stored field.
