# Farbod AI-Hub 25.1 — Repairs, document previews and serialized warehouse

## Changes
- Repair severity now includes Green / Resolved. Recording a resolution updates the asset's current status and clears its active red repair badge. Historical incident records remain visible in the history.
- Healthy / Resolved asset status is reflected in the health badge and dashboard. Neutral equipment change records do not mark a server unhealthy.
- Existing repair tables migrate transactionally, retaining record IDs, dates, descriptions and authors.
- Knowledge PDF previews permit framing only by this application's own origin. Other application pages still reject framing. Word DOCX previews include paragraphs and tables directly in the page.
- Equipment and Bank Connection files now have offline previews for XLSX, XLS and CSV, sheet selection and pagination (100 rows per page, first 100 columns). Formulas are shown as text, not recalculated. Download Original retains the complete file and formatting. Legacy DOC/ZIP files retain a download fallback.
- Warehouse serialized receipts take a quantity and require that many serial numbers and asset tags. Each unit has its own permanent stock code and immutable movement history. Identical name/brand/model records are displayed under one parent with a summed in-stock quantity.
- Existing serialized warehouse rows are grouped without changing their IDs, codes, quantities or movement history. Old records without an asset tag remain blank; values are never invented.
- Open a parent to see its serials and asset tags. Use an individual unit's History / receive / issue link for outgoing and returning units. Returning an existing serial uses its existing record.
- Batch receipts are atomic, reject duplicate serials/tags and prevent a repeated submission from increasing stock twice. A receipt supports 1–200 devices.
- Dark theme text, table cells, form labels, fields, dropdowns and previews use readable foreground colors.

## Upgrade
1. Stop the current app and back up the entire persistent data directory, including the SQLite database and uploaded files.
2. Keep the existing data directory and `.env` settings. Point FARBOD_DATA_DIR to the same persistent location when using a new source folder.
3. Update dependencies with the supplied requirements.txt, using your normal package source/Nexus for offline installations. XLS preview adds xlrd 2.0.2. Docker users rebuild with the supplied compose configuration; the default image tag is 25.1.
4. Start the application. The migration runs at startup. Refresh the browser so the versioned CSS and JavaScript reload.
5. Verify the displayed version is 25.1.

## Validation
34 targeted automated tests passed, including prior warehouse and bilingual UI regression tests and new checks for:
- legacy repair-table migration, retained history, green resolution and neutral change records;
- grouped ten-unit receipt, individual issue, duplicate/idempotency handling and invalid-batch rollback;
- legacy warehouse grouping with an unchanged movement ledger;
- PDF frame headers, DOCX tables, XLSX sheet selection/pagination, escaping and original download;
- authenticated routes, CSRF and bilingual template rendering.
Python syntax and warehouse JavaScript syntax checks also passed.
Browser visual verification could not be completed because the Chromium download failed in the build environment.
