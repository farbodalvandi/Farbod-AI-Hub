# Farbod AI-Hub 25.2 — HPE Product Bulletin catalogs

Version 25.2 adds support for HPE Product Bulletin `.RS` catalogs in the
Knowledge module. Upload an `.RS` file under the appropriate category to read
its catalog text in the app and make that text searchable in the existing
Knowledge search source. Original files remain downloadable.

The app treats `.RS` files as ZIP containers and reads their HTML catalog
pages. It does not extract archive members to disk or run the contained HTML.
Standard size and upload limits still apply.

Back up the application data before upgrading and retain the prior release as
your rollback copy, following the existing deployment procedure.
