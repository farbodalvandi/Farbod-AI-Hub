# Farbod AI-Hub 25.3 — Large Knowledge upload batches

Version 25.3 lets Knowledge users upload a large collection by selecting
multiple files or choosing a folder. The browser sends files one at a time and
shows progress and a saved/skipped/failed summary, so the full collection is
not packed into one large request. Existing per-file upload limits still apply.

HPE Product Bulletin `.RS` catalogs are checked as ZIP containers and remain
readable and searchable after upload.
