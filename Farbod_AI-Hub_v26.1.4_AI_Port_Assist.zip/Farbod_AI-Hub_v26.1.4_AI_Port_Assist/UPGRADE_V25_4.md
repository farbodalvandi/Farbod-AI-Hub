# Farbod AI-Hub 25.4

## SAN switch port map

- Choose 32, 56, or 96 ports when creating a SAN switch.
- Open a switch to see a switch-front port map. Select any port to record its destination, fabric/VSAN, and notes.
- Port connections are stored separately from the asset profile and survive application restarts and upgrades.
- Legacy switches without a configured count open with a 32-port view; edit the switch profile to set its actual count.

## HPE Product Bulletin `.RS` — superseded in 25.5

- Version 25.5 no longer opens, uploads, or indexes `.rs` files because their search quality was insufficient.
- Previously stored `.rs` files remain in the Knowledge list for manual selection and deletion. Search synchronization removes their indexed passages.

## Upgrade

Back up the application data directory and environment configuration, replace the application files, rebuild/recreate the Docker image as `farbod-ai-hub:25.4`, then verify the database and stored files. The port-count column and SAN port connection table are created automatically; existing inventory rows are preserved.
