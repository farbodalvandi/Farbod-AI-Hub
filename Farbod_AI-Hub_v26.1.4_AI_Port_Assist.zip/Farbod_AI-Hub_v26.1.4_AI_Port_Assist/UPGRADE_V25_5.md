# Farbod AI-Hub 25.5

## Knowledge updates

- Knowledge no longer accepts, previews, or indexes HPE Product Bulletin `.rs` files. PDF, DOC, and DOCX remain supported.
- Existing `.rs` catalog files remain visible in the Knowledge list so they can be selected and deleted. They are excluded from Knowledge search; startup index synchronization removes their old indexed passages.
- Select individual files or use Select all, then choose Delete selected. Deletion is limited to the currently selected Knowledge category and removes both the database entry and stored file.
- Multi-file and folder upload remain available for supported file formats.

## Upgrade

Back up the application data directory and environment configuration. Replace the application files, rebuild/recreate the Docker image as `farbod-ai-hub:25.5`, then verify the database, Knowledge list, and stored files. Existing asset records, SAN port mappings, and supported Knowledge files are preserved.
