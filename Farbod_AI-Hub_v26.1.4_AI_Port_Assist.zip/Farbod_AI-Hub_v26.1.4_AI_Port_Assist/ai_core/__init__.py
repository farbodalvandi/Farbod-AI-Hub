"""Farbod AI-Hub v15 AI Operations core (read-only by design)."""
