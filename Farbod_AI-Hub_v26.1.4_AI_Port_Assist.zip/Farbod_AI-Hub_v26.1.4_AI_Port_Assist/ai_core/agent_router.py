"""Deterministic, read-only agent router for Farbod AI-Hub v14."""
from dataclasses import dataclass, asdict
import re

@dataclass
class AgentPlan:
    agent: str
    intent: str
    tools: list[str]
    risk: str = "read-only"
    requires_approval: bool = False
    reason: str = ""
    def to_dict(self): return asdict(self)

RULES = [
    ("san", r"\b(san|brocade|fabric|zoning|wwpn|wwn|fc path|fibre channel)\b", "SAN Agent", ["asset_search", "knowledge_rag", "brocade_read"]),
    ("storage", r"\b(storage|unity|powerstore|oceanstor|lun|pool|volume|raid)\b", "Storage Agent", ["asset_search", "knowledge_rag", "storage_read"]),
    ("virtualization", r"\b(esxi|vmware|vcenter|datastore|vm\b|virtualization)\b", "VMware Agent", ["asset_search", "knowledge_rag", "vmware_read"]),
    ("server", r"\b(server|ilo|idrac|redfish|bios|firmware|dl\d+|proliant|poweredge)\b", "Server Agent", ["asset_search", "knowledge_rag", "redfish_read"]),
    ("network", r"\b(network|switch|router|vlan|ethernet|nic|ip address)\b", "Network Agent", ["asset_search", "knowledge_rag", "network_read"]),
]

def route(question: str) -> AgentPlan:
    q=(question or "").lower()
    for intent, pattern, agent, tools in RULES:
        if re.search(pattern,q):
            return AgentPlan(agent,intent,tools,reason=f"Matched {intent} infrastructure context.")
    return AgentPlan("Infrastructure Agent","general",["asset_search","knowledge_rag"],reason="No specialist domain was required.")
