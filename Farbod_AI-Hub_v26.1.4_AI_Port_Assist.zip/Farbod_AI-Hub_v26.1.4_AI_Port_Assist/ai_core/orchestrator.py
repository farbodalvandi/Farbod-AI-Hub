"""Deterministic v15 AI operations orchestrator.

The orchestrator adds useful structure without requiring a cloud model.  It
never connects to or changes infrastructure; it only classifies the question
and turns retrieved evidence into a reviewable analysis plan.
"""
from dataclasses import dataclass, asdict
import re


DOMAINS = {
    "server": ("Server Agent", r"\b(server|ilo|idrac|redfish|bios|firmware|dl\d+|proliant|poweredge)\b"),
    "storage": ("Storage Agent", r"\b(storage|unity|powerstore|oceanstor|lun|pool|volume|raid|disk)\b"),
    "san": ("SAN Agent", r"\b(san|brocade|fabric|zoning|wwpn|wwn|fibre channel|fc path)\b"),
    "virtualization": ("VMware Agent", r"\b(esxi|vmware|vcenter|datastore|virtual machine|\bvm\b)\b"),
    "network": ("Network Agent", r"\b(network|switch|router|vlan|ethernet|nic|gateway|ip address)\b"),
}

MODE_HINTS = {
    "diagnose": r"\b(error|failed|failure|down|offline|critical|warning|problem|issue|diagnos|root cause|علت|خطا|خراب)\b",
    "capacity": r"\b(capacity|utilization|usage|free space|growth|forecast|ظرفیت|فضای خالی)\b",
    "runbook": r"\b(runbook|procedure|steps|how to|upgrade|install|configure|روش|مراحل|چگونه)\b",
}


@dataclass
class OrchestrationPlan:
    mode: str
    agents: list[str]
    domains: list[str]
    risk: str
    confidence: int
    requires_approval: bool
    read_only: bool = True

    def to_dict(self):
        return asdict(self)


def plan(question, requested_mode="auto"):
    text = (question or "").lower()
    domains = [key for key, (_, pattern) in DOMAINS.items() if re.search(pattern, text)]
    if not domains:
        domains = ["general"]
    if requested_mode in {"ask", "diagnose", "capacity", "runbook"}:
        mode = requested_mode
    else:
        mode = next((name for name, pattern in MODE_HINTS.items() if re.search(pattern, text)), "ask")
    risk = "high" if re.search(r"\b(delete|format|erase|shutdown|reboot|factory reset|حذف|خاموش|ریست)\b", text) else (
        "medium" if mode in {"diagnose", "runbook"} else "low")
    agents = [DOMAINS[d][0] for d in domains if d in DOMAINS]
    if not agents:
        agents = ["Infrastructure Agent"]
    agents += ["Evidence Agent", "Safety Agent"]
    confidence = min(96, 58 + (12 if domains != ["general"] else 0) + (8 if mode != "ask" else 0) + min(12, len(domains) * 4))
    return OrchestrationPlan(mode, agents, domains, risk, confidence, risk == "high")


def recommendations(orchestration, assets, files):
    found = bool(assets or files)
    items = []
    if orchestration.mode == "diagnose":
        items = ["Confirm the current alert and timestamp.", "Compare affected assets with the cited vendor evidence.",
                 "Validate redundancy before planning any change."]
    elif orchestration.mode == "capacity":
        items = ["Verify utilization with a current monitoring sample.", "Record growth over at least two comparable periods.",
                 "Keep operational headroom and vendor limits separate."]
    elif orchestration.mode == "runbook":
        items = ["Review prerequisites and backup or rollback points.", "Test the procedure on a non-production target.",
                 "Require an approved change window before execution."]
    else:
        items = ["Open the cited records to verify the current values.", "Refine the question with a serial number, model, or alert if needed."]
    if not found:
        items.insert(0, "Add or index a relevant manual, asset record, or monitoring result before making a site-specific decision.")
    return items
