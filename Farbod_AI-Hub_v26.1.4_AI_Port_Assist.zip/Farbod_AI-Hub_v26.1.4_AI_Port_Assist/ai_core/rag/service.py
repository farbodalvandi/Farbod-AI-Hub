"""RAG facade with a stable contract for future vector backends."""
import search_service

def retrieve(query, sources=None):
    sources = sources or {"Knowledge","Equipment","Bank connections","Asset attachments"}
    return {"assets": search_service.assets(query), "documents": search_service.files(query, sources)}
