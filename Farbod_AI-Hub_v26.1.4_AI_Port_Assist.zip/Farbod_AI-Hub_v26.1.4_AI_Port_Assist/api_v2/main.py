"""Native agent API router hosted by the Farbod AI-Hub FastAPI runtime."""
import os
import secrets
import time

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

import database as db
from ai_core.agent_router import route

router = APIRouter(prefix="/api/v2", tags=["Agentic Datacenter"])


class AskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=4000)
    mode: str = Field(default="auto", pattern="^(auto|ask|diagnose|capacity|runbook)$")


def _require_authenticated_api(request: Request):
    now = int(time.time())
    timeout = max(300, int(os.environ.get("FARBOD_SESSION_IDLE_SECONDS", "1800")))
    last_activity = int(request.session.get("last_activity") or 0)
    if last_activity and now - last_activity > timeout:
        request.session.clear()
        raise HTTPException(status_code=401, detail="Session expired")

    username = request.session.get("username")
    user = db.get_user(username) if username else None
    if not user or not user["active"]:
        raise HTTPException(status_code=401, detail="Authentication required")
    request.session["last_activity"] = now
    return user


def _require_csrf(request: Request):
    expected = request.session.get("_csrf_token") or request.session.get("search_csrf")
    supplied = request.headers.get("x-csrf-token", "")
    if not expected or not supplied or not secrets.compare_digest(str(supplied), str(expected)):
        raise HTTPException(status_code=403, detail="CSRF validation failed")


@router.get("/healthz")
def health():
    return {"status": "ok", "service": "FarbodAIHub-Agentic-API", "version": "24.8.2", "mode": "read-only"}


@router.post("/agent/plan")
def agent_plan(body: AskRequest, request: Request):
    _require_authenticated_api(request)
    _require_csrf(request)
    from ai_core.orchestrator import plan
    return {"version": "24.8.2", "plan": plan(body.question, body.mode).to_dict(), "executed": False}
