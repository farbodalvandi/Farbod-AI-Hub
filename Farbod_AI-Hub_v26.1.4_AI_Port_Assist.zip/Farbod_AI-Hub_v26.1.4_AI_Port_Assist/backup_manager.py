"""Configuration and filesystem helpers for the admin backup workspace."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import paths


def settings_path() -> Path:
    return Path(paths.runtime_dir()) / "backup-settings.json"


def defaults() -> dict:
    try:
        retention = max(1, min(365, int(os.environ.get("FARBOD_BACKUP_RETENTION", "14"))))
    except ValueError:
        retention = 14
    include_iso = os.environ.get("FARBOD_BACKUP_INCLUDE_ISO", "0").lower() not in {"0", "false", "no", ""}
    schedule = os.environ.get("FARBOD_BACKUP_SCHEDULE", "daily").lower()
    if schedule not in {"manual", "daily", "weekly"}:
        schedule = "daily"
    return {
        "enabled": os.environ.get("FARBOD_BACKUP_ENABLED", "1").lower() not in {"0", "false", "no", "off"},
        "schedule": schedule,
        "time": os.environ.get("FARBOD_BACKUP_TIME", "02:00"),
        "weekday": 6,
        "retention": retention,
        "include_iso": include_iso,
        "directory": paths.backup_dir(),
    }


def load_settings() -> dict:
    data = defaults()
    try:
        saved = json.loads(settings_path().read_text(encoding="utf-8"))
        if isinstance(saved, dict):
            data.update(saved)
    except (OSError, ValueError):
        pass
    # The environment is authoritative for pre-existing deployments.
    env_dir = os.environ.get("FARBOD_BACKUP_DIR")
    if env_dir and not settings_path().exists():
        data["directory"] = os.path.abspath(os.path.expandvars(os.path.expanduser(env_dir)))
    return data


def save_settings(data: dict) -> dict:
    directory = os.path.abspath(os.path.expandvars(os.path.expanduser(str(data["directory"]))))
    os.makedirs(directory, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=settings_path().parent,
                                     prefix="backup-settings-", delete=False) as stream:
        json.dump({**data, "directory": directory}, stream, indent=2)
        temporary = stream.name
    os.replace(temporary, settings_path())
    return {**data, "directory": directory}


def status_path() -> Path:
    return Path(paths.runtime_dir()) / "backup-status.json"


def load_status() -> dict:
    try:
        result = json.loads(status_path().read_text(encoding="utf-8"))
        return result if isinstance(result, dict) else {}
    except (OSError, ValueError):
        return {}


def save_status(data: dict) -> None:
    target = status_path()
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=target.parent,
                                     prefix="backup-status-", delete=False) as stream:
        json.dump(data, stream, indent=2)
        temporary = stream.name
    os.replace(temporary, target)
