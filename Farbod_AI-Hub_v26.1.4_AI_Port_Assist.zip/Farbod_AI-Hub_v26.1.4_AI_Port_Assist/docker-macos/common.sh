#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
env_file="$project_dir/.env.docker"

pause_terminal(){ if [[ -t 0 ]]; then read -r -p "Press Return to close…" _; fi; }
require_docker(){
  command -v docker >/dev/null || { echo "Docker Desktop is not installed or docker is not in PATH."; pause_terminal; exit 1; }
  docker info >/dev/null 2>&1 || { echo "Start Docker Desktop, wait until it is ready, then try again."; pause_terminal; exit 1; }
  docker compose version >/dev/null || { echo "Docker Compose v2 is required."; pause_terminal; exit 1; }
}
require_config(){ :; }
compose(){
  if [[ -f "$env_file" ]]; then
    docker compose --env-file "$env_file" "$@"
  else
    docker compose "$@"
  fi
}

if [[ -f "$env_file" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$env_file"
  set +a
fi
bind_ip="${FARBOD_DOCKER_BIND_IP:-127.0.0.1}"
http_port="${FARBOD_DOCKER_HTTP_PORT:-8000}"
https_port="${FARBOD_DOCKER_HTTPS_PORT:-443}"
http_url="http://$bind_ip:$http_port"
https_url="https://localhost${https_port:+:$https_port}"
[[ "$https_port" == "443" ]] && https_url="https://localhost"

# Verify the application serving requests, rather than trusting the image name.
verify_running_release(){
  local attempt
  for attempt in {1..30}; do
    if compose exec -T app python -c 'import json,urllib.request; d=json.load(urllib.request.urlopen("http://127.0.0.1:8000/healthz",timeout=3)); assert d.get("version")=="26.1.4" and d.get("build")=="26.1.4-port-assistant", d; print("Verified running Farbod AI-Hub " + d["build"])' 2>/dev/null; then
      return 0
    fi
    sleep 2
  done
  echo "Could not verify running version 26.1.4-port-assistant. Check DOCKER_LOGS.command before using this build."
  return 1
}
