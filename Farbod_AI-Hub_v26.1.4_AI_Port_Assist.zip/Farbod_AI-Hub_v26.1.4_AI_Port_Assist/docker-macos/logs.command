#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
echo "Press Control+C to stop following logs."
compose logs --tail=200 -f app worker backup
