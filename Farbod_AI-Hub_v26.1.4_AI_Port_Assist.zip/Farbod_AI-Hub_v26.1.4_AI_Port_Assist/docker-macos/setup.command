#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker

echo "Farbod AI Hub v26.1.4 — Docker setup"
if [[ ! -f "$env_file" ]]; then
  cp .env.docker.example "$env_file"
  /usr/bin/sed -i '' "s/^FARBOD_DOCKER_UID=.*/FARBOD_DOCKER_UID=$(id -u)/" "$env_file"
  /usr/bin/sed -i '' "s/^FARBOD_DOCKER_GID=.*/FARBOD_DOCKER_GID=$(id -g)/" "$env_file"
  chmod 600 "$env_file"
  echo "Created .env.docker for UID $(id -u)."
fi

# shellcheck disable=SC1090
set -a; source "$env_file"; set +a
data_path="${FARBOD_DOCKER_DATA_DIR:-./docker-data/data}"
backup_path="${FARBOD_DOCKER_BACKUP_DIR:-./docker-data/backups}"
mkdir -p "$data_path/instance" "$data_path/knowledge" "$data_path/equipment_files" \
  "$data_path/bank_connection_info" "$data_path/subobject_files" "$data_path/logs" "$data_path/runtime" "$backup_path"
chmod -R u+rwX "$data_path" "$backup_path"

native_data="$HOME/Library/Application Support/FarbodAIHub"
if [[ -d "$native_data" && ! -f "$data_path/instance/dcam.db" ]]; then
  echo "Migrating existing v15.2 application data into Docker storage…"
  ditto "$native_data" "$data_path"
fi

if lsof -nP -iTCP:"${FARBOD_DOCKER_HTTP_PORT:-8000}" -sTCP:LISTEN >/dev/null 2>&1 \
   && ! docker ps --format '{{.Names}}' | grep -qx 'farbod-ai-hub-app'; then
  echo "Port ${FARBOD_DOCKER_HTTP_PORT:-8000} is already in use."
  echo "If v15.2 LaunchAgent is running, use STOP_FARBOD_AI_HUB.command before Docker setup."
  pause_terminal
  exit 1
fi

compose config --quiet
compose up -d --build app worker backup
verify_running_release

echo "Waiting for container health…"
for _ in {1..90}; do
  status="$(compose ps --format json app 2>/dev/null || true)"
  if curl -fsS "$http_url/healthz" >/dev/null 2>&1; then
    echo "Farbod AI Hub is ready: $http_url"
    if [[ -f "$data_path/instance/bootstrap-admin.txt" ]]; then
      echo "First-run admin credentials: $data_path/instance/bootstrap-admin.txt"
      echo "Change the password after login, then delete that file."
    fi
    open "$http_url"
    pause_terminal
    exit 0
  fi
  if printf '%s' "$status" | grep -q 'unhealthy'; then break; fi
  sleep 2
done
echo "Container did not become healthy. Run DOCKER_LOGS.command for details."
compose ps
pause_terminal
exit 1
