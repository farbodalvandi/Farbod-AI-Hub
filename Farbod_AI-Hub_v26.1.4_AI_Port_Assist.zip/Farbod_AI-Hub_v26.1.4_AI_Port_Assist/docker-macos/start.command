#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
echo "Building and starting Farbod AI-Hub 26.1.4 from this folder…"
compose up -d --build --force-recreate app worker backup
verify_running_release
for _ in {1..30}; do curl -fsS "$http_url/healthz" >/dev/null 2>&1 && { echo "Running: $http_url"; open "$http_url"; pause_terminal; exit 0; }; sleep 2; done
echo "The application is not healthy yet. Run DOCKER_LOGS.command."; pause_terminal; exit 1
