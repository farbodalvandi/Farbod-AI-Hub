#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
export FARBOD_ASSET_TRUST_PROXY=1
export FARBOD_SECURE_COOKIES=1
compose --profile https up -d --build --force-recreate app worker backup caddy
verify_running_release
echo "HTTPS started at $https_url"
echo "Caddy uses a local CA. Your browser may require you to trust its certificate."
open "$https_url"
pause_terminal
