#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
compose --profile https stop
echo "Containers stopped. Data and backups were preserved."
pause_terminal
