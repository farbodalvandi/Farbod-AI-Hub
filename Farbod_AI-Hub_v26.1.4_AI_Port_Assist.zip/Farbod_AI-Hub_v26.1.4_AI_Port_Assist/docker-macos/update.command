#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
echo "Creating a pre-update backup…"
compose exec -T app python scripts/backup_data.py
compose build app worker backup
compose up -d --force-recreate app worker backup
verify_running_release
echo "Image rebuilt and containers replaced. Persistent data was preserved."
pause_terminal
