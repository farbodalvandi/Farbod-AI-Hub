#!/bin/sh
set -eu
trap 'exit 0' TERM INT
echo "Backup schedule service ready; settings are managed in the Backup & Restore page."
while true; do
  python /app/scripts/backup_scheduler.py || true
  sleep 60 & wait $! || exit 0
done
