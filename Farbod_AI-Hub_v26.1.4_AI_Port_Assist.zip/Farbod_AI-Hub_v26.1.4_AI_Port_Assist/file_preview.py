"""Offline document previews. Cell values are escaped by Jinja, never executed."""
from pathlib import Path
import csv
from itertools import islice

PAGE_SIZE = 100
MAX_COLUMNS = 100


def workbook_page(path, sheet=0, page=1):
    ext = Path(path).suffix.lower()
    page = max(1, min(int(page), 10000))
    start = (page - 1) * PAGE_SIZE
    sheets, rows = [], []
    book = None
    try:
        if ext == '.xlsx':
            from openpyxl import load_workbook
            book = load_workbook(path, read_only=True, data_only=False, keep_links=False)
            sheets = book.sheetnames
            sheet = max(0, min(int(sheet), len(sheets)-1))
            ws = book[sheets[sheet]]
            # Ignore inflated declared worksheet dimensions; bound displayed columns.
            ws.reset_dimensions()
            rows = list(islice(ws.iter_rows(max_col=MAX_COLUMNS, values_only=True), start, start+PAGE_SIZE+1))
        elif ext == '.xls':
            import xlrd
            book = xlrd.open_workbook(path, on_demand=True)
            sheets = book.sheet_names()
            sheet = max(0, min(int(sheet), len(sheets)-1))
            ws = book.sheet_by_index(sheet)
            rows = [ws.row_values(i,0,min(ws.ncols,MAX_COLUMNS))
                    for i in range(start,min(ws.nrows,start+PAGE_SIZE+1))]
        elif ext == '.csv':
            sheets = ['CSV']; sheet = 0
            with open(path, encoding='utf-8-sig', errors='replace', newline='') as handle:
                rows = [r[:MAX_COLUMNS] for r in islice(csv.reader(handle),start,start+PAGE_SIZE+1)]
        else:
            raise ValueError('Unsupported spreadsheet format')
        has_next = len(rows)>PAGE_SIZE
        rows = rows[:PAGE_SIZE]
        last_column = max((i+1 for row in rows for i,value in enumerate(row) if value is not None and value != ''),default=1)
        rows = [[str(v)[:10000] if v is not None else '' for v in row[:last_column]] for row in rows]
        return dict(sheets=sheets,sheet=sheet,page=page,rows=rows,start=start,has_next=has_next)
    finally:
        if book is not None:
            if ext == '.xls': book.release_resources()
            else: book.close()


def word_content(path):
    from docx import Document
    doc = Document(path)
    blocks=[]
    # Preserve paragraph/table order, with bounded preview size.
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    for child in list(doc.element.body)[:3000]:
        if child.tag.endswith('}p'):
            p=Paragraph(child,doc)
            blocks.append({'kind':'paragraph','text':p.text})
        elif child.tag.endswith('}tbl'):
            table=Table(child,doc)
            blocks.append({'kind':'table','rows':[[cell.text for cell in row.cells[:100]] for row in table.rows[:500]]})
    return blocks
