"""Offline UI localization. Only explicitly marked UI strings are translated."""
import json
import re
from pathlib import Path
from webcore import request

FA = json.loads((Path(__file__).parent / 'locales' / 'fa.json').read_text(encoding='utf-8'))

def locale():
    try:
        return 'fa' if request.cookies.get('farbod_language') == 'fa' else 'en'
    except LookupError:
        return 'en'

def translate(value):
    if not isinstance(value, str) or locale() != 'fa':
        return value
    return FA.get(value, value)
