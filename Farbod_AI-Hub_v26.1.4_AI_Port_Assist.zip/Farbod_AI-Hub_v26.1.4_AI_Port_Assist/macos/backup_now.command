#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
if [[ ! -x "$project_dir/.venv/bin/python" ]]; then echo "Run install_service.command first."; pause_terminal; exit 1; fi
"$project_dir/.venv/bin/python" "$project_dir/scripts/backup_data.py"
pause_terminal
