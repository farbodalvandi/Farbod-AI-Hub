#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_dir"

echo "Farbod AI Hub v24.8 — macOS service installation"
command -v python3 >/dev/null || { echo "Python 3 is required."; read -r; exit 1; }

if [[ ! -x .venv/bin/python ]]; then
  echo "Creating isolated Python environment…"
  python3 -m venv .venv
fi
echo "Installing application dependencies…"
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env with secure local defaults."
fi

# shellcheck disable=SC1091
source "$project_dir/macos/common.sh"
mkdir -p "$data_dir/instance" "$data_dir/knowledge" "$data_dir/equipment_files" "$data_dir/bank_connection_info" "$data_dir/subobject_files"

# First installation preserves the database and encryption key shipped with or
# already used by the source package. Existing production data is never replaced.
if [[ ! -f "$data_dir/instance/dcam.db" && -f "$project_dir/instance/dcam.db" ]]; then
  ditto "$project_dir/instance" "$data_dir/instance"
fi
for folder in knowledge equipment_files bank_connection_info subobject_files; do
  if [[ -d "$project_dir/$folder" && -z "$(find "$data_dir/$folder" -mindepth 1 -print -quit 2>/dev/null)" ]]; then
    ditto "$project_dir/$folder" "$data_dir/$folder"
  fi
done

cat > "$service_plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$service_label</string>
  <key>ProgramArguments</key><array><string>$project_dir/.venv/bin/python</string><string>$project_dir/run_v20.py</string></array>
  <key>WorkingDirectory</key><string>$project_dir</string>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Background</string><key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$data_dir/logs/service.log</string>
  <key>StandardErrorPath</key><string>$data_dir/logs/service-error.log</string>
</dict></plist>
PLIST

cat > "$backup_plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$backup_label</string>
  <key>ProgramArguments</key><array><string>$project_dir/.venv/bin/python</string><string>$project_dir/scripts/backup_data.py</string></array>
  <key>WorkingDirectory</key><string>$project_dir</string>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>2</integer><key>Minute</key><integer>30</integer></dict>
  <key>StandardOutPath</key><string>$data_dir/logs/backup.log</string>
  <key>StandardErrorPath</key><string>$data_dir/logs/backup-error.log</string>
</dict></plist>
PLIST

plutil -lint "$service_plist" "$backup_plist"
launchctl bootout "gui/$UID/$service_label" 2>/dev/null || true
launchctl bootout "gui/$UID/$backup_label" 2>/dev/null || true
launchctl bootstrap "gui/$UID" "$service_plist"
launchctl bootstrap "gui/$UID" "$backup_plist"
launchctl enable "gui/$UID/$service_label"
launchctl enable "gui/$UID/$backup_label"
launchctl kickstart -k "gui/$UID/$service_label"

echo "Waiting for the application health check…"
for _ in {1..20}; do
  if curl -fsS "$app_url/healthz" >/dev/null 2>&1; then
    echo "Installation completed successfully: $app_url"
    open "$app_url"
    pause_terminal
    exit 0
  fi
  sleep 1
done
echo "Service was installed but health check is not ready. Review: $data_dir/logs/service-error.log"
pause_terminal
exit 1
