#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
if [[ ! -f "$service_plist" ]]; then echo "Service is not installed. Run install_service.command first."; pause_terminal; exit 1; fi
launchctl print "gui/$UID/$service_label" >/dev/null 2>&1 || launchctl bootstrap "gui/$UID" "$service_plist"
launchctl kickstart -k "gui/$UID/$service_label"
for _ in {1..15}; do curl -fsS "$app_url/healthz" >/dev/null 2>&1 && { echo "Farbod AI Hub is running: $app_url"; open "$app_url"; pause_terminal; exit 0; }; sleep 1; done
echo "Service started but is not healthy yet. Check $data_dir/logs/service-error.log"; pause_terminal; exit 1
