#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
launchctl bootout "gui/$UID/$service_label" 2>/dev/null || true
launchctl bootout "gui/$UID/$backup_label" 2>/dev/null || true
trash_dir="$HOME/.Trash/FarbodAIHub-Service-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$trash_dir"
[[ -f "$service_plist" ]] && mv "$service_plist" "$trash_dir/"
[[ -f "$backup_plist" ]] && mv "$backup_plist" "$trash_dir/"
echo "Service definitions moved to: $trash_dir"
echo "Application data, backups and source files were preserved."
pause_terminal
