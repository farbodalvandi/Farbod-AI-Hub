# -*- coding: utf-8 -*-
"""Project resource and writable-data paths for source-based execution."""
import os


PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))


def resource_dir():
    return PROJECT_DIR


def data_dir():
    if os.environ.get("FARBOD_DATA_DIR"):
        path = os.path.abspath(os.path.expandvars(os.path.expanduser(os.environ["FARBOD_DATA_DIR"])))
        os.makedirs(path, exist_ok=True)
        return path
    return PROJECT_DIR


def logs_dir():
    path = os.path.join(data_dir(), "logs")
    os.makedirs(path, exist_ok=True)
    return path


def runtime_dir():
    path = os.path.join(data_dir(), "runtime")
    os.makedirs(path, exist_ok=True)
    return path


def backup_dir():
    configured = os.environ.get("FARBOD_BACKUP_DIR")
    if configured:
        path = os.path.abspath(os.path.expandvars(os.path.expanduser(configured)))
    else:
        path = os.path.expanduser("~/Library/Application Support/FarbodAIHub Backups")
    os.makedirs(path, exist_ok=True)
    return path


def iso_dir():
    """Where uploaded .iso files are stored. Kept separate from instance/
    (which holds the small sqlite DB) since ISOs can be several GB each."""
    path = os.path.join(data_dir(), "instance", "isos")
    os.makedirs(path, exist_ok=True)
    return path
