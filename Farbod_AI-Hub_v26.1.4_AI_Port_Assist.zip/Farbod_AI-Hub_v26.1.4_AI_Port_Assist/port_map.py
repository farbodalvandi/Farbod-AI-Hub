"""Recorded physical cabling. One endpoint belongs to at most one cable."""
from contextlib import closing
from datetime import datetime
import database as db
import re

KINDS = ('Ethernet', 'FC', 'Management', 'SAS', 'Power')

# Legacy server profile fields correspond to the physical jacks shown in the
# device port panel. Keep one canonical mapping so lists and profiles agree.
SERVER_FIELD_PORTS = {
    'ETH Port1': 'NIC / P1', 'ETH Port2': 'NIC / P2',
    'ETH Port3': 'NIC / P3', 'ETH Port4': 'NIC / P4',
    'network_port1': 'NIC / P1', 'network_port2': 'NIC / P2',
    'network_port3': 'NIC / P3', 'network_port4': 'NIC / P4',
    'HBA1 Port1': 'HBA1 / P1', 'HBA1 Port2': 'HBA1 / P2',
    'HBA2 Port1': 'HBA2 / P1', 'HBA2 Port2': 'HBA2 / P2',
}

# Storage inventory already has controller port columns. Show FC cabling in
# those columns, matching the server inventory's inline connection display.
STORAGE_FIELD_PORTS = {
    **{f'SPA_PORT_{i}': f'A / FC{i + 1}' for i in range(4)},
    **{f'SPB_PORT_{i}': f'B / FC{i + 1}' for i in range(4)},
    'management_ip': 'A / MGMT1',
}

def ensure_schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS physical_ports (
        asset_table TEXT NOT NULL, asset_id INTEGER NOT NULL, name TEXT NOT NULL,
        kind TEXT NOT NULL, section TEXT NOT NULL, hidden INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(asset_table,asset_id,name))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS physical_cables (
        id INTEGER PRIMARY KEY AUTOINCREMENT, fabric TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '', updated_by TEXT NOT NULL, updated_at TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS physical_endpoints (
        cable_id INTEGER NOT NULL REFERENCES physical_cables(id) ON DELETE CASCADE,
        asset_table TEXT NOT NULL, asset_id INTEGER NOT NULL, port TEXT NOT NULL,
        PRIMARY KEY(asset_table,asset_id,port))''')

def defaults(table, asset):
    if table == 'servers':
        count = int(asset['power_count'] or 2)
        return [(f'NIC / P{i}', 'Ethernet','Network') for i in range(1,5)] + [(f'HBA{h} / P{i}','FC',f'HBA {h}') for h in (1,2) for i in (1,2)] + [('iLO','Management','Management')] + [(f'PSU{i}','Power','Power supplies') for i in range(1,count+1)]
    if table == 'storage':
        return [(f'{c} / {k}{i}',kind,f'Controller {c}') for c in ('A','B') for k,kind,n in [('FC','FC',4),('ETH','Ethernet',2),('MGMT','Management',1),('SAS','SAS',2)] for i in range(1,n+1)] + [('PSU1','Power','Power A'),('PSU2','Power','Power B')]
    if table == 'san_switches':
        try: count=int(asset['port_count'] or asset['fc_ports'] or 32)
        except (ValueError,TypeError): count=32
        return [(f'FC{i}','FC','Fibre Channel') for i in range(1,min(500,max(1,count))+1)]
    if table == 'network':
        try: count=int(asset['port_count'] or 24)
        except (ValueError,TypeError): count=24
        count=min(100,max(1,count))
        return [(f'Port{i}','Ethernet','Network') for i in range(1,count+1)]
    return []

def ports(table, asset_id):
    asset=db.get_asset(table,asset_id) if table in db.SCHEMAS else None
    if asset is None: raise ValueError('Asset not found')
    result={n:dict(name=n,kind=k,section=s) for n,k,s in defaults(table,asset)}
    with closing(db.get_conn()) as conn:
        for row in conn.execute('SELECT * FROM physical_ports WHERE asset_table=? AND asset_id=?',(table,asset_id)):
            if row['hidden']: result.pop(row['name'],None)
            else: result[row['name']]=dict(row)
    if table == 'servers':
        count=int(asset['power_count'] or 2)
        result={n:v for n,v in result.items() if not (n.startswith('PSU') and n[3:].isdigit() and int(n[3:])>count)}
    return result

def mappings(table,asset_id):
    with closing(db.get_conn()) as conn:
        rows=conn.execute('''SELECT a.port, b.asset_table AS target_table,b.asset_id AS target_id,b.port AS target_port,c.*
          FROM physical_endpoints a JOIN physical_endpoints b ON a.cable_id=b.cable_id
          AND NOT (a.asset_table=b.asset_table AND a.asset_id=b.asset_id AND a.port=b.port)
          JOIN physical_cables c ON c.id=a.cable_id WHERE a.asset_table=? AND a.asset_id=?''',(table,asset_id)).fetchall()
    result={}
    for row in rows:
        item=dict(row); other=db.get_asset(item['target_table'],item['target_id'])
        item['target_label']=db.asset_label(item['target_table'],other) if other else 'Removed asset'
        result[row['port']]=item
    return result

def answer_query(question):
    """Answer direct physical-port questions from the recorded cable map."""
    q = str(question or "")
    q = q.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'))
    low = q.lower()
    if not re.search(r'\b(?:port|fc\s*\d+|hba\s*\d+|nic\s*[/ ]\s*p?\d+)\b|پورت', low):
        return None
    if not re.search(r'\b(?:connect(?:ed|ion)?|plugged|cable|where|what|to)\b|وصل|متصل|اتصال|چی', low):
        return None
    if re.search(r'san\s*switch|sanswitch|سنسوییچ|سن\s*سوئیچ', low):
        table = 'san_switches'
        port_match = re.search(r'(?:fc\s*)?\bport\s*(\d+)\b|پورت\s*(\d+)|fc\s*(\d+)', low)
        port_num = next((int(x) for x in port_match.groups() if x), None) if port_match else None
        prefix = re.search(r'(?:san\s*switch|sanswitch|سنسوییچ|سن\s*سوئیچ)\s*(?:#|no\.?|number|شماره)?\s*(\d+)', low)
    elif re.search(r'\bserver\b|سرور', low):
        table = 'servers'
        port_match = re.search(r'(?:port\s*(\d+)|پورت\s*(\d+)|(?:hba|nic)\s*\d*\s*[/ ]\s*p?\s*(\d+))', low)
        port_num = next((int(x) for x in port_match.groups() if x), None) if port_match else None
        prefix = re.search(r'(?:server|سرور)\s*(?:#|no\.?|number|شماره)?\s*(\d+)', low)
    else:
        return None
    if not port_num:
        return None
    assets = [dict(row) for row in db.list_assets(table)]
    if prefix:
        wanted = int(prefix.group(1))
        assets = [row for row in assets if int(row['id']) == wanted or any(
            str(row.get(k) or '').strip().lower() == prefix.group(0).lower()
            for k in ('asset_tag','model','serial_number'))]
    matches = []
    for row in assets:
        ports_for_asset = mappings(table, row['id'])
        candidates = [f'FC{port_num}'] if table == 'san_switches' else [
            name for name in ports(table, row['id']) if re.search(rf'\bP{port_num}\b', name, re.I)]
        for port in candidates:
            matches.append((row, port, ports_for_asset.get(port)))
    return {'table': table, 'port_number': port_num, 'matches': matches} if matches else None

def configure(table,asset_id,name,kind,section,hide,user):
    current=ports(table,asset_id); name=name.strip(); section=section.strip()
    if not name or len(name)>60 or not section or len(section)>60 or kind not in KINDS: raise ValueError('Provide a port name, section and valid type (60 characters maximum).')
    with closing(db.get_conn()) as conn:
        conn.execute('BEGIN IMMEDIATE')
        if conn.execute('SELECT 1 FROM physical_endpoints WHERE asset_table=? AND asset_id=? AND port=?',(table,asset_id,name)).fetchone(): raise ValueError('Disconnect this port before changing its definition.')
        conn.execute('INSERT OR REPLACE INTO physical_ports VALUES(?,?,?,?,?,?)',(table,asset_id,name,kind,section,int(hide)))
        conn.commit()
    db.log_action(user,'port_configure',f'{table}#{asset_id} {name} hidden={hide}')

def connect(table,asset_id,port,target_table,target_id,target_port,fabric,notes,user):
    a=ports(table,asset_id).get(port);b=ports(target_table,target_id).get(target_port)
    if not a or not b: raise ValueError('Select existing ports on both devices.')
    if (table,asset_id)==(target_table,target_id): raise ValueError('Select a different destination device.')
    compatible=a['kind']==b['kind'] or {a['kind'],b['kind']} <= {'Ethernet','Management'}
    if not compatible: raise ValueError('Port types are incompatible.')
    if len(fabric)>120 or len(notes)>3000: raise ValueError('Connection details are too long.')
    with closing(db.get_conn()) as conn:
        conn.execute('BEGIN IMMEDIATE')
        for t,i,p in [(table,asset_id,port),(target_table,target_id,target_port)]:
            if conn.execute('SELECT 1 FROM physical_endpoints WHERE asset_table=? AND asset_id=? AND port=?',(t,i,p)).fetchone(): raise ValueError('A selected port is already connected. Disconnect it first.')
        cid=conn.execute('INSERT INTO physical_cables(fabric,notes,updated_by,updated_at) VALUES(?,?,?,?)',(fabric,notes,user,datetime.now().isoformat())).lastrowid
        conn.executemany('INSERT INTO physical_endpoints VALUES(?,?,?,?)',[(cid,table,asset_id,port),(cid,target_table,target_id,target_port)])
        conn.commit()
    db.log_action(user,'cable_connect',f'{table}#{asset_id} {port} <-> {target_table}#{target_id} {target_port}')

def disconnect(table,asset_id,port,user):
    with closing(db.get_conn()) as conn:
        conn.execute('BEGIN IMMEDIATE')
        row=conn.execute('SELECT cable_id FROM physical_endpoints WHERE asset_table=? AND asset_id=? AND port=?',(table,asset_id,port)).fetchone()
        if row:
            conn.execute('DELETE FROM physical_endpoints WHERE cable_id=?',(row[0],))
            conn.execute('DELETE FROM physical_cables WHERE id=?',(row[0],))
        conn.commit()
    db.log_action(user,'cable_disconnect',f'{table}#{asset_id} {port}')
