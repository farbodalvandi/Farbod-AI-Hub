/* Offline brand marks. Unknown/custom brands keep their text without a false logo. */
(() => {
  const brands = {hpe:'hpe', 'hewlett packard enterprise':'hpe', hp:'hp', dell:'dellemc', dellemc:'dellemc', 'dell emc':'dellemc', emc:'dellemc', cisco:'cisco', netapp:'netapp', ibm:'ibm', huawei:'huawei', lenovo:'lenovo', broadcom:'broadcom'};
  function logo(value) {
    const key = brands[(value || '').trim().toLowerCase()];
    if (!key) return null;
    const img = document.createElement('img');
    img.src = '/static/brands/' + key + '.svg'; img.alt = value + ' logo';
    img.width = key === 'dellemc' ? 80 : 38; img.height = 28;
    img.style.cssText = 'object-fit:contain;background:#fff;border-radius:5px;padding:4px;margin-inline-end:8px;vertical-align:middle;flex:none';
    img.addEventListener('error', () => img.remove());
    return img;
  }
  function mount() {
    document.querySelectorAll('[name="manufacturer"]').forEach(input => {
      if (input.dataset.brandReady) return; input.dataset.brandReady = '1';
      const preview=document.createElement('span'); preview.setAttribute('aria-live','polite');
      preview.className='d-flex align-items-center mt-2';
      const group=input.closest('.input-group'); if(group)group.insertAdjacentElement('afterend',preview);else input.insertAdjacentElement('afterend',preview);
      const render=()=>{preview.replaceChildren(); const img=logo(input.value); if(img) preview.appendChild(img); preview.appendChild(document.createTextNode(input.value || ''));};
      input.addEventListener('change',render); input.addEventListener('input',render); render();
      // Existing asset modals set select.value programmatically before opening.
      document.addEventListener('shown.bs.modal',render);
    });
    document.querySelectorAll('[data-brand]').forEach(node=>{
      if(node.dataset.brandRendered)return;node.dataset.brandRendered='1';
      const img=logo(node.dataset.brand);if(img)node.prepend(img);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',mount);else mount();
})();
