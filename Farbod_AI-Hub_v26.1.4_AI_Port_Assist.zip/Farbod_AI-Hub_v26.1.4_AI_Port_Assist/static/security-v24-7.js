/* Farbod AI-Hub v24.7 request hardening: CSRF propagation for same-origin writes. */
(function(){
  'use strict';
  const meta=document.querySelector('meta[name="csrf-token"]');
  const token=meta?meta.getAttribute('content'):'';
  const unsafe=new Set(['POST','PUT','PATCH','DELETE']);
  function sameOrigin(url){
    try{return new URL(url||window.location.href,window.location.href).origin===window.location.origin}catch(_){return false}
  }
  function protectForm(form){
    const method=(form.getAttribute('method')||'GET').toUpperCase();
    if(!token||!unsafe.has(method))return;
    let field=form.querySelector('input[name="csrf"]');
    if(!field){field=document.createElement('input');field.type='hidden';field.name='csrf';form.appendChild(field)}
    field.value=token;
  }
  document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('form').forEach(protectForm));
  document.addEventListener('submit',event=>protectForm(event.target),true);

  if(window.fetch){
    const nativeFetch=window.fetch.bind(window);
    window.fetch=function(input,init){
      init=init?Object.assign({},init):{};
      const method=(init.method||((input&&input.method)||'GET')).toUpperCase();
      const url=typeof input==='string'?input:(input&&input.url)||window.location.href;
      if(token&&unsafe.has(method)&&sameOrigin(url)){
        const headers=new Headers(init.headers||((input&&input.headers)||undefined));
        if(!headers.has('X-CSRF-Token'))headers.set('X-CSRF-Token',token);
        init.headers=headers;
      }
      return nativeFetch(input,init);
    };
  }

  if(window.XMLHttpRequest&&token){
    const nativeOpen=XMLHttpRequest.prototype.open;
    const nativeSend=XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open=function(method,url){this.__farbodMethod=String(method||'GET').toUpperCase();this.__farbodUrl=url;return nativeOpen.apply(this,arguments)};
    XMLHttpRequest.prototype.send=function(){if(unsafe.has(this.__farbodMethod)&&sameOrigin(this.__farbodUrl)){try{this.setRequestHeader('X-CSRF-Token',token)}catch(_){}}return nativeSend.apply(this,arguments)};
  }
})();
