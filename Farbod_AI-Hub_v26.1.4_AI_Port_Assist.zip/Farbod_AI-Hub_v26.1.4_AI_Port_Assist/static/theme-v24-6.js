/* Farbod AI-Hub v24.6 appearance controller. Purely client-side. */
(function(){
  'use strict';
  const root=document.documentElement;
  const allowedModes=['light','dark','system'];
  const allowedAccents=['amber','blue','cyan','emerald','violet','ruby'];
  const media=window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function storedMode(){
    const modern=localStorage.getItem('farbod-theme-mode');
    if(allowedModes.includes(modern)) return modern;
    const legacy=localStorage.getItem('farbod-theme');
    if(legacy==='light'||legacy==='dark') return legacy;
    return media&&media.matches?'dark':'light';
  }
  function storedAccent(){const value=localStorage.getItem('farbod-accent');return allowedAccents.includes(value)?value:'blue';}
  function storedPreset(){const value=localStorage.getItem('farbod-theme-preset');return ['soft-glass','midnight-amber'].includes(value)?value:'';}
  function resolved(mode){return mode==='system'?(media&&media.matches?'dark':'light'):mode;}
  function apply(mode,accent,persist,preset=''){
    if(preset==='soft-glass') mode='light';
    if(preset==='midnight-amber') mode='dark';
    if(!allowedModes.includes(mode)) mode=storedMode();
    if(!allowedAccents.includes(accent)) accent=storedAccent();
    const actual=resolved(mode);
    root.dataset.themeMode=mode;
    root.dataset.theme=actual;
    root.dataset.accent=accent;
    if(preset==='soft-glass'||preset==='midnight-amber') root.dataset.themePreset=preset; else delete root.dataset.themePreset;
    if(persist){
      localStorage.setItem('farbod-theme-mode',mode);
      localStorage.setItem('farbod-theme',actual); // backwards compatibility with older pages.
      localStorage.setItem('farbod-accent',accent);
      if(preset==='soft-glass'||preset==='midnight-amber') localStorage.setItem('farbod-theme-preset',preset); else localStorage.removeItem('farbod-theme-preset');
    }
    if(document.readyState!=='loading') syncControls();
  }
  function syncControls(){
    const mode=root.dataset.themeMode||storedMode();
    const accent=root.dataset.accent||storedAccent();
    const preset=root.dataset.themePreset||'';
    document.querySelectorAll('[data-theme-mode-choice]').forEach(btn=>btn.setAttribute('aria-pressed',String(!preset&&btn.dataset.themeModeChoice===mode)));
    document.querySelectorAll('[data-theme-preset-choice]').forEach(btn=>btn.setAttribute('aria-pressed',String(btn.dataset.themePresetChoice===preset)));
    document.querySelectorAll('[data-accent-choice]').forEach(btn=>btn.setAttribute('aria-pressed',String(btn.dataset.accentChoice===accent)));
    document.querySelectorAll('[data-theme-trigger]').forEach(btn=>{
      const icon=btn.querySelector('[data-theme-icon]');
      if(icon) icon.className='bi '+(resolved(mode)==='dark'?'bi-moon-stars-fill':'bi-sun-fill');
      btn.setAttribute('title','Theme: '+mode);
    });
  }

  // Apply before styles finish painting to avoid a light/dark flash.
  apply(storedMode(),storedAccent(),false,storedPreset());

  function buildPopover(){
    if(document.getElementById('themePopover')) return document.getElementById('themePopover');
    const pop=document.createElement('section');
    pop.id='themePopover'; pop.className='theme-popover'; pop.hidden=true;
    pop.setAttribute('aria-label','Theme and appearance');
    pop.innerHTML=`
      <div class="theme-popover-head"><div><strong>${window.uiText("Theme")}</strong><small>${window.uiText("Appearance is saved on this device.")}</small></div><button class="theme-popover-close" type="button" aria-label="${window.uiText("Close theme settings")}"><i class="bi bi-x-lg"></i></button></div>
      <div class="theme-section"><span class="theme-section-label">${window.uiText("Mode")}</span><div class="theme-mode-grid">
        <button type="button" class="theme-mode-choice" data-theme-mode-choice="light"><i class="bi bi-sun"></i> ${window.uiText("Light")}</button>
        <button type="button" class="theme-mode-choice" data-theme-mode-choice="dark"><i class="bi bi-moon-stars"></i> ${window.uiText("Dark")}</button>
        <button type="button" class="theme-mode-choice" data-theme-mode-choice="system"><i class="bi bi-circle-half"></i> ${window.uiText("System")}</button>
        <button type="button" class="theme-mode-choice" data-theme-preset-choice="soft-glass"><i class="bi bi-droplet-half"></i> ${window.uiText("Soft Glass")}</button>
        <button type="button" class="theme-mode-choice" data-theme-preset-choice="midnight-amber"><i class="bi bi-moon-stars-fill"></i> ${window.uiText("Midnight Amber")}</button>
      </div></div>
      <div class="theme-section"><span class="theme-section-label">${window.uiText("Accent")}</span><div class="theme-accent-grid">
        ${[['amber','#f59e0b','Amber'],['blue','#3b82f6','Electric Blue'],['cyan','#06b6d4','Cyan'],['emerald','#176b52','Emerald'],['violet','#8b5cf6','Violet'],['ruby','#e11d48','Ruby']].map(([key,color,label])=>`<button type="button" class="theme-accent-choice" data-accent-choice="${key}" style="--swatch:${color}" title="${window.uiText(label)}" aria-label="${window.uiText(label)}"></button>`).join('')}
      </div></div>
`;
    document.body.appendChild(pop);
    pop.querySelector('.theme-popover-close').addEventListener('click',()=>closePopover(true));
    pop.querySelectorAll('[data-theme-mode-choice]').forEach(btn=>btn.addEventListener('click',()=>apply(btn.dataset.themeModeChoice,root.dataset.accent||storedAccent(),true,'')));
    pop.querySelectorAll('[data-theme-preset-choice]').forEach(btn=>btn.addEventListener('click',()=>apply('light',root.dataset.accent||storedAccent(),true,btn.dataset.themePresetChoice)));
    pop.querySelectorAll('[data-accent-choice]').forEach(btn=>btn.addEventListener('click',()=>apply(root.dataset.themeMode||storedMode(),btn.dataset.accentChoice,true)));
    return pop;
  }
  function closePopover(returnFocus){
    const pop=document.getElementById('themePopover'); if(!pop||pop.hidden) return;
    pop.hidden=true;
    document.querySelectorAll('[data-theme-trigger]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
    if(returnFocus && window.__farbodThemeTrigger) window.__farbodThemeTrigger.focus();
  }
  function togglePopover(trigger){
    const pop=buildPopover();
    const opening=pop.hidden;
    if(opening){
      pop.hidden=false; window.__farbodThemeTrigger=trigger;
      document.querySelectorAll('[data-theme-trigger]').forEach(btn=>btn.setAttribute('aria-expanded',String(btn===trigger)));
      syncControls();
      requestAnimationFrame(()=>pop.querySelector('[aria-pressed="true"]')?.focus());
    }else closePopover(false);
  }

  document.addEventListener('DOMContentLoaded',()=>{
    buildPopover(); syncControls();
    document.querySelectorAll('[data-theme-trigger]').forEach(btn=>{
      btn.setAttribute('aria-haspopup','true'); btn.setAttribute('aria-controls','themePopover'); btn.setAttribute('aria-expanded','false');
      btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();togglePopover(btn);});
    });
    document.addEventListener('click',e=>{const pop=document.getElementById('themePopover');if(pop&&!pop.hidden&&!pop.contains(e.target)&&!e.target.closest('[data-theme-trigger]')) closePopover(false);});
    document.addEventListener('keydown',e=>{if(e.key==='Escape') closePopover(true);});
  });

  if(media){
    const onChange=()=>{if((root.dataset.themeMode||storedMode())==='system') apply('system',root.dataset.accent||storedAccent(),false);};
    if(media.addEventListener) media.addEventListener('change',onChange); else if(media.addListener) media.addListener(onChange);
  }
})();
