/* One serial/tag pair per unit; server independently validates exact count. */
document.querySelectorAll('[data-serialized-receipt]').forEach(form=>{
  const count=form.querySelector('[data-unit-count]'), body=form.querySelector('[data-serial-rows]');
  const cached=[];
  function render(){
    [...body.rows].forEach((row,i)=>{cached[i]=[row.querySelector('[name="serial_numbers"]').value,row.querySelector('[name="asset_tags"]').value]});
    const n=Number(count.value); if(!Number.isInteger(n)||n<1||n>200)return;
    body.replaceChildren();
    for(let i=0;i<n;i++){
      const tr=document.createElement('tr'),th=document.createElement('th');th.textContent=i+1;tr.append(th);
      ['serial_numbers','asset_tags'].forEach((name,j)=>{const td=document.createElement('td'),input=document.createElement('input');input.className='form-control';input.name=name;input.required=true;input.maxLength=200;input.value=cached[i]?.[j]||'';input.setAttribute('aria-label',`${j?'Asset tag':'Serial number'} ${i+1}`);td.append(input);tr.append(td)});
      body.append(tr);
    }
  }
  count.addEventListener('change',render);count.addEventListener('input',render);render();
});
