(() => {
  'use strict';
  const dialog = document.getElementById('copilot-dialog');
  if (!dialog) return;
  const question = document.getElementById('copilot-question');
  const status = document.getElementById('copilot-status');
  const transcript = document.getElementById('copilot-transcript');
  const send = document.getElementById('copilot-send');
  let conversation = null, busy = false, timer;
  const show = () => {if (!dialog.open) dialog.showModal(); question.focus();};
  document.getElementById('copilot-open').addEventListener('click', show);
  dialog.querySelector('[data-close]').addEventListener('click', () => dialog.close());
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {event.preventDefault(); show();}
  });
  function node(tag, text, cls) {const el = document.createElement(tag); el.textContent = text; if(cls) el.className = cls; return el;}
  document.getElementById('copilot-new').addEventListener('click', () => {
    if (busy) return;
    clearInterval(timer); conversation = null; transcript.replaceChildren(); status.textContent = ''; question.focus();
  });
  document.getElementById('copilot-form').addEventListener('submit', async event => {
    event.preventDefault(); if (busy || !question.value.trim()) return;
    clearInterval(timer); busy = true; send.disabled = true;
    const q = question.value.trim(); transcript.append(node('p', q, 'v12-user')); question.value = '';
    status.textContent = 'Retrieving permitted evidence and preparing the answer…';
    try {
      const payload = {q}; if (conversation) payload.conversation_id = conversation;
      const response = await fetch(dialog.dataset.query, {method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':dialog.dataset.csrf},body:JSON.stringify(payload)});
      if(response.redirected) throw new Error('Session expired. Sign in again.');
      const result = await response.json();
      if(!response.ok) throw new Error(result.error || 'Request failed. Please retry.');
      conversation = result.conversation_id;
      const answer = node('div', '', 'v12-answer'); answer.dir = 'auto'; transcript.append(answer);
      // This is presentation-only reveal, not server token streaming.
      const text = result.answer; let position = 0;
      const finish = () => {answer.textContent = text; clearInterval(timer);};
      if(matchMedia('(prefers-reduced-motion: reduce)').matches) finish();
      else timer = setInterval(() => {position += Math.max(30, Math.ceil(text.length / 40)); answer.textContent = text.slice(0, position); if(position >= text.length) finish();}, 20);
      if(result.warning) transcript.append(node('p', result.warning, 'v12-note'));
      const evidence = node('div', '', 'v12-shortcuts');
      [...result.assets, ...result.files].slice(0, 6).forEach(source => {
        const link = node('a', '['+source.citation+'] '+(source.label || source.name));
        const url = new URL(source.url, location.origin);
        if(url.origin === location.origin) {link.href = url.href; link.target = '_blank'; link.rel = 'noopener'; evidence.append(link);}
      });
      const history = node('a', 'Open full answer & history →'); history.href = '/ai-assistant?conversation='+encodeURIComponent(conversation); evidence.append(history); transcript.append(evidence);
      status.textContent = result.provider+' · answer ready · no actions executed';
      answer.scrollIntoView({block:'nearest'});
    } catch(error) {status.textContent = error.message; question.value = q;}
    finally {busy = false; send.disabled = false;}
  });
})();
