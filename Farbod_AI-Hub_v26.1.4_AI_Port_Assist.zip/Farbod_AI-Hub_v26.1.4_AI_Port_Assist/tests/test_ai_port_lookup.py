import unittest
from unittest.mock import patch

import port_map


class AIPortLookupTests(unittest.TestCase):
    def test_persian_san_switch_query_finds_fc_connection(self):
        switch = {"id": 1, "manufacturer": "Dell", "model": "SAN Switch 1"}
        cable = {"target_table": "servers", "target_id": 7, "target_port": "HBA1 / P1",
                 "target_label": "Server 7", "fabric": "A", "notes": ""}
        with patch.object(port_map.db, "list_assets", return_value=[switch]), \
             patch.object(port_map, "mappings", return_value={"FC1": cable}):
            result = port_map.answer_query("به پورت ۱ sanswitch 1 من چی وصل شده؟")
        self.assertEqual(result["table"], "san_switches")
        self.assertEqual(result["matches"][0][1], "FC1")
        self.assertEqual(result["matches"][0][2]["target_port"], "HBA1 / P1")

    def test_english_server_query_finds_connected_san_port(self):
        server = {"id": 7, "manufacturer": "Dell", "model": "R760", "asset_tag": "SRV7"}
        cable = {"target_table": "san_switches", "target_id": 1, "target_port": "FC1",
                 "target_label": "SAN Switch 1", "fabric": "A", "notes": ""}
        with patch.object(port_map.db, "list_assets", return_value=[server]), \
             patch.object(port_map, "mappings", return_value={"HBA1 / P1": cable}), \
             patch.object(port_map, "ports", return_value={"NIC / P1": {}, "HBA1 / P1": {}}):
            result = port_map.answer_query("Where is server 7 port 1 connected?")
        self.assertEqual(result["table"], "servers")
        self.assertIn("FC1", [entry[2]["target_port"] for entry in result["matches"] if entry[2]])

    def test_unrelated_questions_do_not_trigger_port_lookup(self):
        self.assertIsNone(port_map.answer_query("How much memory is installed in server 7?"))


if __name__ == "__main__":
    unittest.main()
