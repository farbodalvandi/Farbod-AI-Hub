"""Integration coverage for backup archive integrity and restore behavior."""
import os
import sqlite3
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_backup_restore_round_trip(tmp_path):
    data = tmp_path / "data"
    backups = tmp_path / "backups"
    (data / "instance").mkdir(parents=True)
    (data / "knowledge").mkdir()
    (data / "equipment_files").mkdir()
    with sqlite3.connect(data / "instance" / "dcam.db") as connection:
        connection.execute("CREATE TABLE sample (value TEXT)")
        connection.execute("INSERT INTO sample VALUES ('before')")
    (data / "instance" / "secret.key").write_text("s" * 40)
    (data / "knowledge" / "manual.txt").write_text("original file")
    env = os.environ.copy()
    env.update(FARBOD_DATA_DIR=str(data), FARBOD_BACKUP_DIR=str(backups), FARBOD_BACKUP_RETENTION="3")

    subprocess.run([sys.executable, "scripts/backup_data.py"], cwd=ROOT, env=env, check=True)
    archive = next(backups.glob("FarbodAIHub_Backup_*.zip"))
    with sqlite3.connect(data / "instance" / "dcam.db") as connection:
        connection.execute("UPDATE sample SET value='after'")
    (data / "knowledge" / "manual.txt").write_text("modified file")
    (data / "equipment_files" / "stale.txt").write_text("must be cleared")
    (data / "instance" / "isos").mkdir()
    (data / "instance" / "isos" / "keep.iso").write_text("not included in backup")
    subprocess.run([sys.executable, "scripts/restore_backup.py", "--backup", str(archive),
                    "--data-dir", str(data)], cwd=ROOT, env=env, check=True)

    with sqlite3.connect(data / "instance" / "dcam.db") as connection:
        assert connection.execute("SELECT value FROM sample").fetchone()[0] == "before"
    assert (data / "knowledge" / "manual.txt").read_text() == "original file"
    assert not (data / "equipment_files" / "stale.txt").exists()
    assert (data / "instance" / "isos" / "keep.iso").exists()
    assert len(list(backups.glob("FarbodAIHub_Backup_*.zip"))) == 2  # original + safety backup


def test_restore_rejects_archive_path_traversal(tmp_path):
    sys.path.insert(0, str(ROOT / "scripts"))
    from restore_backup import validate

    archive_path = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        archive.writestr("backup-manifest.json", "{}")
        archive.writestr("instance/dcam.db", "not a database")
        archive.writestr("../../outside.txt", "must not escape")
    with zipfile.ZipFile(archive_path) as archive:
        with pytest.raises(ValueError, match="unsafe path"):
            validate(archive)
