from linux_health_service import fc_topology, time_report, event_timeline


def test_fc_mapping_does_not_invent_missing_maps():
    ports = 'host3|0x5001|Online|16 Gbit|/pci/0000:01:00.0|qla2xxx'
    paths = 'host3|sdb|3:0:0:7\nhost3|sdc|3:0:1:7'
    mp = 'data (3600abc) dm-1 ARRAY,LUN\n|- 3:0:0:7 sdb 8:16 active ready running'
    result = fc_topology(ports, paths, mp)
    assert result[0]['paths'][0]['map'] == {'name': 'data', 'wwid': '3600abc'}
    assert result[0]['paths'][1]['map'] is None


def test_chrony_selected_source_and_stddev():
    output = 'Reference ID    : 0A000001 (10.0.0.1)\nRef time (UTC)  : Mon Sep 29 05:00:00 2026\nLast offset     : +0.000001 seconds\nRMS offset      : 0.000002 seconds\nRoot dispersion : 0.000010 seconds\n--SOURCES--\n^* 10.0.0.1 2 6 377 25 +1us[+2us] +/- 20us\n--SOURCESTATS--\n10.0.0.1 14 7 180 0.002 0.003 +1us 4us'
    status, reason = time_report(output)
    assert status == 'healthy' and '4us' in reason and '10.0.0.1' in reason


def test_timeline_limits_to_24h():
    logs = '2026-09-29 10:00:00\nSep 29 09:59:00 host kernel: qla2xxx link down\nSep 27 09:00:00 host kernel: qla2xxx reset'
    result = event_timeline(logs)
    assert len(result) == 1 and 'link down' in result[0]['message']
