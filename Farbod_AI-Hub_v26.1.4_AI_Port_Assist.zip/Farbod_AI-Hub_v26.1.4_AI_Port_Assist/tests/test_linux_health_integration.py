"""Regression checks for the AI-Hub Linux Health integration."""
import time


def _signed_in_client():
    from app import app
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["username"] = "admin"
        sess["last_activity"] = int(time.time())
        sess["_csrf_token"] = "integration-csrf"
        sess["search_csrf"] = "integration-csrf"
    return client


def test_hub_link_and_authenticated_page():
    from app import app
    client = app.test_client()
    assert client.get("/linux-health").status_code in (302, 303, 307)
    client = _signed_in_client()
    hub = client.get("/hardware-hub")
    assert hub.status_code == 200
    assert 'href="http://testserver/linux-health"' in hub.text
    page = client.get("/linux-health")
    assert page.status_code == 200
    assert "csrf-token" in page.text
    assert "Back to Hub" in page.text
    assert client.get("/static/linux-health/app.js").status_code == 200


def test_diagnostic_api_requires_session_csrf_and_trusted_host(monkeypatch, tmp_path):
    from app import app
    payload = {"host": "127.0.0.1", "port": 22, "username": "diagnostic", "password": "test-password"}
    assert app.test_client().post("/api/linux-health/diagnose", json=payload).status_code == 401
    client = _signed_in_client()
    assert client.post("/api/linux-health/diagnose", json=payload).status_code == 403
    monkeypatch.setenv("FARBOD_LINUX_HEALTH_KNOWN_HOSTS", str(tmp_path / "absent"))
    response = client.post("/api/linux-health/diagnose", json=payload,
                           headers={"X-CSRF-Token": "integration-csrf"})
    assert response.status_code == 503
    assert "known_hosts" in response.json()["detail"]
