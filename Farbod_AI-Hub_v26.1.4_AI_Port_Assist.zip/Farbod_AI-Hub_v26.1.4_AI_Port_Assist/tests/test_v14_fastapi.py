def test_public_health_and_login_page():
    from fastapi.testclient import TestClient
    from app import asgi_app
    with TestClient(asgi_app) as client:
        assert client.get("/healthz").json()["status"] == "ok"
        page = client.get("/login")
        assert page.status_code == 200
        assert "login" in page.text.lower()


def test_native_agentic_api_requires_session_and_csrf():
    import time
    import database as db
    from app import app, asgi_app

    client = app.test_client()
    unauthenticated = client.post("/api/v2/agent/plan", json={"question": "Check SAN switch health"})
    assert unauthenticated.status_code == 401

    with client.session_transaction() as sess:
        sess["username"] = "admin"
        sess["last_activity"] = int(time.time())
        sess["_csrf_token"] = "test-token"
        sess["search_csrf"] = "test-token"

    response = client.post(
        "/api/v2/agent/plan",
        json={"question": "Check SAN switch health"},
        headers={"X-CSRF-Token": "test-token"},
    )
    assert response.status_code == 200
    assert response.json()["version"] == "24.8.2"
    assert response.json()["executed"] is False
