from ai_core.orchestrator import plan
from ai_engine import InfrastructureAgent


def test_specialist_routing_and_safety():
    result = plan("Diagnose a failed Brocade SAN path", "auto")
    assert result.mode == "diagnose"
    assert "san" in result.domains
    assert result.read_only is True


def test_high_risk_request_requires_approval():
    result = plan("Delete the storage volume", "auto")
    assert result.risk == "high"
    assert result.requires_approval is True


def test_copilot_result_has_explainability_fields():
    result = InfrastructureAgent(lambda _: [], lambda _: [], {}).run("capacity forecast for storage")
    assert result["orchestration"]["mode"] == "capacity"
    assert result["recommendations"]
    assert 0 <= result["confidence"] <= 100
