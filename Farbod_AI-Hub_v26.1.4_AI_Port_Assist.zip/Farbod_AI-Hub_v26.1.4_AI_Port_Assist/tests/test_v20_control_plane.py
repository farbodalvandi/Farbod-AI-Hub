import importlib


def test_v20_schema_and_risk_gate(tmp_path, monkeypatch):
    monkeypatch.setenv("FARBOD_DATA_DIR", str(tmp_path))
    import paths
    import database
    import operations_v20 as ops
    importlib.reload(paths)
    importlib.reload(database)
    database.init_db()
    ops.ensure_schema(database)

    low_id = ops.create_job(database, "Inventory discovery", "inventory", "discover", "DC-1", "low", "admin")
    high_id = ops.create_job(database, "Storage change", "runbook", "change", "Array-1", "high", "admin")
    jobs = {row["id"]: row for row in ops.list_jobs(database)}
    assert jobs[low_id]["status"] == "queued"
    assert jobs[low_id]["approval_required"] == 0
    assert jobs[high_id]["status"] == "awaiting_approval"
    assert jobs[high_id]["approval_required"] == 1


def test_v20_only_admin_can_approve(tmp_path, monkeypatch):
    monkeypatch.setenv("FARBOD_DATA_DIR", str(tmp_path))
    import paths
    import database
    import operations_v20 as ops
    importlib.reload(paths)
    importlib.reload(database)
    database.init_db()
    ops.ensure_schema(database)
    job_id = ops.create_job(database, "Firmware plan", "firmware", "plan", "Server-1", "medium", "operator")
    try:
        ops.transition_job(database, job_id, "approve", "operator", is_admin=False)
        assert False, "operator approval must be rejected"
    except PermissionError:
        pass
    ops.transition_job(database, job_id, "approve", "admin", is_admin=True)
    job = next(row for row in ops.list_jobs(database) if row["id"] == job_id)
    assert job["status"] == "queued"
    assert job["approved_by"] == "admin"


def test_v20_connector_is_read_only(tmp_path, monkeypatch):
    monkeypatch.setenv("FARBOD_DATA_DIR", str(tmp_path))
    import paths
    import database
    import operations_v20 as ops
    importlib.reload(paths)
    importlib.reload(database)
    database.init_db()
    ops.ensure_schema(database)
    connector_id = ops.add_connector(database, "Lab iLO", "redfish", "https://10.0.0.10", "admin")
    connector = next(row for row in ops.list_connectors(database) if row["id"] == connector_id)
    assert connector["mode"] == "read-only"
    payload = ops.health_payload(database)
    assert payload["version"] == "20.0"
    assert payload["mode"] == "human-in-the-loop"
