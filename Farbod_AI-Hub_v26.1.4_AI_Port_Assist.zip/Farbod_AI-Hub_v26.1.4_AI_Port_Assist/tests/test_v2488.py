import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import pytest
import database as db
from warehouse import create_item, move_stock
from document_search import DocumentIndex, normalize

@pytest.fixture
def warehouse_db(tmp_path, monkeypatch):
    monkeypatch.setattr(db,'BASE_DIR',str(tmp_path))
    monkeypatch.setattr(db,'DB_FILE',str(tmp_path/'instance'/'test.db'))
    db.init_db()
    return db

def new_item(serial=''):
    return create_item({'name':'Memory module','description':'Spare modules','serial_number':serial},'admin')

def movement(qty=1,direction='IN',**kw):
    return dict(quantity=str(qty),direction=direction,notes='Received against delivery note',request_token=uuid.uuid4().hex,**kw)

def test_stock_validation_history_idempotency(warehouse_db):
    item=new_item(); receipt=movement(5)
    assert move_stock(item,receipt,'admin')
    assert not move_stock(item,receipt,'admin')
    assert move_stock(item,movement(2,'OUT'),'admin')
    for bad in [dict(movement(),notes='  '),movement(4,'OUT'),movement(-1),movement('1.5')]:
        with pytest.raises(ValueError): move_stock(item,bad,'admin')
    with closing(db.get_conn()) as conn:
        assert conn.execute('SELECT quantity FROM warehouse_items WHERE id=?',(item,)).fetchone()[0]==3
        rows=conn.execute('SELECT * FROM warehouse_movements ORDER BY id').fetchall()
        assert [(r['before_qty'],r['after_qty']) for r in rows]==[(0,5),(5,3)]
        assert all(r['username']=='admin' and r['notes'] for r in rows)
        with pytest.raises(Exception):conn.execute('DELETE FROM warehouse_movements')

def test_concurrent_issues_cannot_overdraw(warehouse_db):
    item=new_item();move_stock(item,movement(1),'admin')
    def issue(_):
        try: return move_stock(item,movement(1,'OUT'),'admin')
        except ValueError:return False
    with ThreadPoolExecutor(max_workers=2) as pool: assert sorted(pool.map(issue,range(2)))==[False,True]

def test_codes_and_serials(warehouse_db):
    data={'code':'TEST-001','name':'Server','description':'One chassis'}
    create_item(data,'admin')
    with pytest.raises(ValueError):create_item(dict(data,code='test-001'),'admin')
    item=new_item('SERIAL-ONE')
    with pytest.raises(ValueError):move_stock(item,movement(2),'admin')

def test_storage_migration_preserves_existing_record(warehouse_db):
    row_id=db.create_asset('storage',{'model':'Unity','serial_number':'keep-me'},'admin')
    with closing(db.get_conn()) as conn,conn:
        conn.execute('ALTER TABLE storage DROP COLUMN rack_units')
        conn.execute('ALTER TABLE storage DROP COLUMN u_position')
    db.init_db()
    db.update_asset('storage',row_id,{'model':'Unity','serial_number':'keep-me','rack_units':'2','u_position':'10'},'admin')
    row=db.get_asset('storage',row_id)
    assert row['serial_number']=='keep-me' and row['rack_units']=='2' and row['u_position']=='10'

def test_persian_memory_question_and_generation(tmp_path):
    index=DocumentIndex(str(tmp_path/'search.db'))
    docs=[]
    # Synthetic specs intentionally avoid claiming real product facts.
    for gen in [11,12]:
        path=tmp_path/f'DL380 Gen{gen}.txt'
        path.write_text(f'HPE DL380 Gen{gen}\n'+('General chassis information. '*90)+f'\nMemory: synthetic test DIMM TYPE-{gen}; population rule fixture.',encoding='utf8')
        docs.append(dict(key=str(gen),source='Knowledge',name=path.name,path=str(path),description='',url='/doc/'+str(gen)))
    index.sync(docs)
    found=index.search('سرور dl380 gen 12 چه مدل رمی ساپورت می کنه؟',['Knowledge'])
    assert found and all(f['key']=='12' for f in found)
    assert any('TYPE-12' in f['excerpt'] for f in found)
    assert normalize('DL380Gen12')=='dl380 gen12'
    assert not index.search('dl380 gen13 memory',['Knowledge'])
    assert not index.search('dl380 gen12 memory',['Equipment'])

def test_spec_no_evidence_does_not_invoke_model():
    from ai_engine import InfrastructureAgent
    a=InfrastructureAgent(lambda q:[{'citation':'A1','label':'DL380','fields':{'RAM':'installed'},'table':'servers','id':1}],lambda q:[],{'provider':'ollama','answer_mode':'hybrid'})
    a.ollama=lambda *args:pytest.fail('No evidence must not call a model for compatibility')
    result=a.run('DL380 Gen12 what RAM does it support?')
    assert 'Insufficient document evidence' in result['answer']

def test_followup_recovers_model():
    from ai_engine import InfrastructureAgent
    calls=[]
    a=InfrastructureAgent(lambda q:[],lambda q:calls.append(q) or [])
    a.run('چه مدل رمی ساپورت می کنه؟',[{'role':'user','content':'DL380 Gen12'},{'role':'assistant','content':'DL380 Gen11'}])
    assert 'dl380 gen12' in calls[0] and 'gen11' not in calls[0]

def client_for(role):
    from app import app
    username='test-'+role
    with closing(db.get_conn()) as conn,conn:
        conn.execute("INSERT OR IGNORE INTO users(username,password_hash,role,full_name,active) VALUES (?,?,?,?,1)",(username,'unused',role,role))
    client=app.test_client()
    with client.session_transaction() as sess:
        sess.update(username=username,last_activity=int(time.time()),_csrf_token='csrf-test',search_csrf='csrf-test')
    return client

def test_pages_roles_csrf_and_end_to_end(warehouse_db):
    from app import app
    assert app.test_client().get('/warehouse').status_code in (302,303,307)
    client=client_for('admin')
    assert client.get('/warehouse').status_code==200
    assert 'Warehouse' in client.get('/hardware-hub').text
    assert client.post('/warehouse/items',data={'name':'blocked'}).status_code==403
    created=client.post('/warehouse/items',data={'csrf':'csrf-test','code':'DEMO-01','name':'Spare','description':'Test'},follow_redirects=False)
    assert created.status_code in (302,303,307)
    with closing(db.get_conn()) as conn: item=conn.execute("SELECT id FROM warehouse_items WHERE code='DEMO-01'").fetchone()[0]
    page=client.get(f'/warehouse/{item}')
    assert page.status_code==200 and 'Movement description' in page.text
    data=movement(3);data['csrf']='csrf-test'
    posted=client.post(f'/warehouse/{item}',data=data,follow_redirects=False)
    assert posted.status_code in (302,303,307)
    operator=client_for('operator')
    assert operator.get(f'/warehouse/{item}').status_code==200
    assert operator.post(f'/warehouse/{item}',data=data).status_code==403
    assert operator.post('/warehouse/items',data={'csrf':'csrf-test'}).status_code==403
    for brand in ['hpe','dell','cisco','netapp','ibm','huawei','lenovo']:
        assert client.get(f'/static/brands/{brand}.svg').status_code==200
    assert 'Unit (U)' in client.get('/assets/storage').text
