import re
from pathlib import Path
from contextlib import closing
import pytest
import database as db
from document_search import DocumentIndex, normalize
from tests.test_v2488 import warehouse_db, client_for

@pytest.mark.parametrize('question',[
 'What type of RAM does the HPE ProLiant DL380 Gen12 support?',
 'Which memory modules are compatible with DL380 Gen 12?',
 'What kind of DIMMs can I use in a DL380 G12?',
 'Tell me the supported RAM for DL380-Gen12.',
 'DL 380 Generation-12 memory specifications',
 'What RDIMMs are supported by DL380Gen12?',
 'What is the maximum memory capacity of DL380 gen-12?',
 'What type of RAM is supported by HPE DL380 Gen ۱۲?'])
def test_english_spec_questions(tmp_path,question):
 index=DocumentIndex(str(tmp_path/'index.db'));docs=[]
 for gen in [11,12]:
  path=tmp_path/f'guide{gen}.txt';path.write_text(f'DL380 Gen{gen}\n'+('General introduction. '*100)+f'\nRDIMMs: SYNTHETIC-TYPE-{gen}. Memory capacity: synthetic fixture.\n')
  docs.append(dict(key=str(gen),source='Knowledge',name=path.name,description='',url='/doc/'+str(gen),path=str(path)))
 index.sync(docs)
 found=index.search(question,['Knowledge'])
 assert found and all(x['key']=='12' for x in found)
 assert any('SYNTHETIC-TYPE-12' in x['excerpt'] for x in found)

def test_migration_dell_to_dellemc(warehouse_db):
 row_id=db.create_asset('storage',{'manufacturer':'Dell','model':'Unity','serial_number':'keep'},'admin')
 db.add_lookup_value('manufacturer','Dell');db.add_lookup_value('manufacturer','Dell EMC')
 db.init_db();db.init_db()
 assert db.get_asset('storage',row_id)['manufacturer']=='DellEMC'
 assert db.get_asset('storage',row_id)['serial_number']=='keep'
 lookups=db.get_lookup('manufacturer')
 assert 'DellEMC' in lookups and 'Dell' not in lookups and 'Dell EMC' not in lookups

def test_language_switch_and_data_preservation(warehouse_db):
 from app import app
 client=client_for('admin')
 assert 'lang="en"' in client.get('/warehouse').text
 response=client.post('/language',data={'csrf':'csrf-test','language':'fa','next':'/warehouse'},follow_redirects=False)
 assert response.status_code in (302,303,307)
 assert response.headers['location'].endswith('/warehouse')
 assert 'HttpOnly' in response.headers['set-cookie']
 page=client.get('/warehouse')
 assert 'lang="fa"' in page.text and 'dir="rtl"' in page.text and 'ثبت' in page.text
 assert 'bootstrap.rtl.min.css' in page.text
 # User values must remain byte-for-byte identical, even when equal to an English UI label.
 row_id=db.create_asset('storage',{'manufacturer':'DellEMC','model':'Warehouse','serial_number':'ABC-192.0.2.1'},'admin')
 detail=client.get(f'/assets/storage/{row_id}')
 assert 'Warehouse' in detail.text and 'ABC-192.0.2.1' in detail.text
 for route in ['/hardware-hub','/linux-health','/ai-assistant','/assets/storage','/settings','/warehouse']:
  page=client.get(route);assert page.status_code==200,(route,page.text[:200])
  assert 'dir="rtl"' in page.text,route
  assert '/language' in page.text,route
 assert client.post('/language',data={'language':'en'}).status_code==403
 assert client.post('/language',data={'csrf':'csrf-test','language':'xx'}).status_code==400
 client.post('/language',data={'csrf':'csrf-test','language':'en','next':'https://bad.example'})
 assert 'lang="en"' in client.get('/warehouse').text
 assert 'Stock codes' in client.get('/warehouse').text

def test_login_language_survives_logout(warehouse_db):
 client=client_for('admin')
 client.post('/language',data={'csrf':'csrf-test','language':'fa','next':'/warehouse'})
 client.post('/logout',data={'csrf':'csrf-test'})
 page=client.get('/login')
 assert 'lang="fa"' in page.text and 'نام کاربری' in page.text
 assert 'English' in page.text

def test_dellemc_asset_and_template_syntax(warehouse_db):
 from app import app
 for path in Path('templates').glob('*.html'):app.jinja_env.parse(path.read_text())
 client=client_for('admin')
 logo=client.get('/static/brands/dellemc.svg')
 assert logo.status_code==200 and '<svg' in logo.text
 assert "dellemc:'dellemc'" in client.get('/static/brands.js').text
