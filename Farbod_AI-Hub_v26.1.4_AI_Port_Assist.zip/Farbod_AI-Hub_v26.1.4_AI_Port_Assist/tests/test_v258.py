import pytest
import database as db
import port_map as pm
from werkzeug.security import check_password_hash,generate_password_hash
from tests.test_v2488 import warehouse_db,client_for

@pytest.mark.parametrize('count',[2,4,6])
def test_power_count_forms_and_panel(warehouse_db,count):
    sid=db.create_asset('servers',{'model':'DL580','power_count':str(count)},'admin')
    powers=[n for n,p in pm.ports('servers',sid).items() if p['kind']=='Power']
    assert powers==[f'PSU{i}' for i in range(1,count+1)]
    client=client_for('admin')
    assert f'PSU{count}' in client.get(f'/assets/servers/{sid}/port-map').text
    assert 'name="power_count"' in client.get('/assets/servers').text
    assert 'name="power_count"' in client.get(f'/assets/servers/{sid}/edit').text

def test_inventory_shows_live_recorded_connections_and_removal(warehouse_db):
    server=db.create_asset('servers',{'model':'SERVER-TEST'},'admin')
    storage=db.create_asset('storage',{'model':'STORAGE-TEST'},'admin')
    pm.connect('servers',server,'HBA1 / P1','storage',storage,'A / FC1','Fabric A','','admin')
    client=client_for('admin')
    page=client.get('/assets/servers');assert page.status_code==200
    assert 'STORAGE-TEST' in page.text and 'A / FC1' in page.text and 'Fabric A' in page.text
    assert 'SERVER-TEST' in client.get('/assets/storage').text
    pm.disconnect('storage',storage,'A / FC1','admin')
    assert 'STORAGE-TEST' not in client.get('/assets/servers').text

def test_power_reduction_protects_connections_and_validation(warehouse_db):
    server=db.create_asset('servers',{'power_count':'6'},'admin')
    target=db.create_asset('storage',{'model':'PDU'},'admin')
    pm.connect('servers',server,'PSU6','storage',target,'PSU1','B','','admin')
    with pytest.raises(ValueError,match='Disconnect'):db.update_asset('servers',server,{'power_count':'4'},'admin')
    assert db.get_asset('servers',server)['power_count']=='6'
    pm.disconnect('servers',server,'PSU6','admin')
    db.update_asset('servers',server,{'power_count':'4'},'admin')

@pytest.mark.parametrize('count',[24,48])
def test_network_switch_has_selectable_front_panel_and_live_destinations(warehouse_db,count):
    switch=db.create_asset('network',{'model':f'ACCESS-{count}','manufacturer':'HPE','port_count':str(count)},'admin')
    peer=db.create_asset('network',{'model':'UPLINK-SWITCH','port_count':'24'},'admin')
    port=f'Port{count}'
    pm.connect('network',switch,port,'network',peer,'Port1','VLAN 100 / Fabric A','uplink','admin')

    client=client_for('admin')
    panel=client.get(f'/assets/network/{switch}')
    assert panel.status_code==200
    assert f'{count} ports' in panel.text
    assert f'ACCESS-{count}' in panel.text
    assert f'port=Port{count}' in panel.text
    assert 'connected' in panel.text

    selected=client.get(f'/assets/network/{switch}?port={port}')
    assert selected.status_code==200
    assert 'UPLINK-SWITCH / Port1' in selected.text
    assert 'VLAN 100 / Fabric A' in selected.text
    assert 'physical-port' in selected.text or 'port-map' in selected.text
    assert 'PSU6' not in pm.ports('servers',server)
    for value in ['0','-1','25','2.5','abc']:
        with pytest.raises(ValueError):db.create_asset('servers',{'power_count':value},'admin')

def test_default_admin_and_preserve_existing(warehouse_db):
    user=db.get_user('admin');assert check_password_hash(user['password_hash'],'admin123')
    conn=db.get_conn();conn.execute('UPDATE users SET password_hash=? WHERE username=?',(generate_password_hash('existing-pass-123'),'admin'));conn.commit();conn.close()
    db.init_db();assert check_password_hash(db.get_user('admin')['password_hash'],'existing-pass-123')

def test_existing_server_defaults_and_missing_field_edit(warehouse_db):
    sid=db.create_asset('servers',{'power_count':'6'},'admin')
    db.update_asset('servers',sid,{'model':'Updated'},'admin')
    assert db.get_asset('servers',sid)['power_count']=='6'
    conn=db.get_conn();conn.execute('UPDATE servers SET power_count=NULL WHERE id=?',(sid,));conn.commit();conn.close()
    assert len([p for p in pm.ports('servers',sid).values() if p['kind']=='Power'])==2
