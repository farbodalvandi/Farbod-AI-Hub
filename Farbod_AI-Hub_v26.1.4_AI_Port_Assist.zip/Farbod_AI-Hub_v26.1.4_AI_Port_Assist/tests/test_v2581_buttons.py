from pathlib import Path

def test_stronger_semantic_buttons_for_both_themes():
    css=Path('static/interface-v25-6.css').read_text()
    for color in ('#2878d0','#15966a','#d94343','#f0a51b','#008fa3','#5d6d7d'):
        assert color in css
    assert 'html[data-theme="dark"] .btn-outline-primary' in css
    assert 'button:focus-visible' in css and 'button:disabled' in css
    assert 'html[data-theme] body[data-interface]' in css
