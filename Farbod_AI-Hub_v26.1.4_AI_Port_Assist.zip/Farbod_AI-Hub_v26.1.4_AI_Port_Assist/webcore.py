"""Small Flask-free compatibility layer for the v15 FastAPI application.

It lets the mature route functions keep their concise style while every
request, response, session and template is served natively by ASGI.
"""
from __future__ import annotations

import inspect
import io
import json
import logging
import os
import re
import secrets
from base64 import b64encode
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from itsdangerous import TimestampSigner

# Template compatibility for the existing Jinja views.
if not hasattr(Request, "args"):
    Request.args = property(lambda self: MultiDict(self.query_params))


_request_ctx: ContextVar[Request] = ContextVar("request")
_form_ctx: ContextVar[Any] = ContextVar("form", default={})
_json_ctx: ContextVar[Any] = ContextVar("json", default=None)
_app_ctx: ContextVar["WebApp"] = ContextVar("app")


class MultiDict:
    def __init__(self, source): self.source = source
    def get(self, key, default=None, type=None):
        value = self.source.get(key, default)
        if type is not None and value is not None:
            try: return type(value)
            except (TypeError, ValueError): return default
        return value
    def getlist(self, key):
        getter = getattr(self.source, "getlist", None)
        return getter(key) if getter else [self.source[key]] if key in self.source else []
    def __getitem__(self, key): return self.source[key]
    def __iter__(self): return iter(self.source)
    def keys(self): return self.source.keys()
    def items(self): return self.source.items()


class Upload:
    def __init__(self, upload): self._upload = upload
    @property
    def filename(self): return self._upload.filename
    def save(self, destination):
        self._upload.file.seek(0)
        with open(destination, "wb") as target:
            while chunk := self._upload.file.read(1024 * 1024): target.write(chunk)
    def read(self, *args): return self._upload.file.read(*args)
    def seek(self, *args): return self._upload.file.seek(*args)
    def tell(self): return self._upload.file.tell()
    def readable(self): return True
    def seekable(self): return True
    @property
    def stream(self): return self._upload.file


class RequestProxy:
    def _r(self): return _request_ctx.get()
    @property
    def method(self): return self._r().method
    @property
    def path(self): return self._r().url.path
    @property
    def endpoint(self): return self._r().scope.get("endpoint_name")
    @property
    def remote_addr(self): return self._r().client.host if self._r().client else None
    @property
    def is_secure(self): return self._r().url.scheme == "https"
    @property
    def referrer(self): return self._r().headers.get("referer")
    @property
    def headers(self): return self._r().headers
    @property
    def cookies(self): return self._r().cookies
    @property
    def args(self): return MultiDict(self._r().query_params)
    @property
    def form(self): return MultiDict(_form_ctx.get())
    @property
    def files(self):
        form = _form_ctx.get()
        class FileMultiDict(MultiDict):
            def getlist(self, key):
                return [Upload(v) for k, v in form.multi_items() if k == key and hasattr(v, "file")]
        return FileMultiDict({k: Upload(v) for k, v in form.multi_items() if hasattr(v, "file")})
    @property
    def values(self):
        merged = dict(self._r().query_params)
        merged.update({k: v for k, v in _form_ctx.get().items() if isinstance(v, str)})
        return MultiDict(merged)
    @property
    def json(self): return _json_ctx.get()
    def get_json(self, silent=False): return _json_ctx.get()


class SessionProxy:
    def _s(self): return _request_ctx.get().session
    def get(self, *a, **kw): return self._s().get(*a, **kw)
    def setdefault(self, *a, **kw): return self._s().setdefault(*a, **kw)
    def clear(self): return self._s().clear()
    def __getitem__(self, k): return self._s()[k]
    def __setitem__(self, k, v): self._s()[k] = v
    def __contains__(self, k): return k in self._s()


request, session = RequestProxy(), SessionProxy()


def _route_path(path: str) -> str:
    path = re.sub(r"<int:([A-Za-z_]\w*)>", r"{\1:int}", path)
    return re.sub(r"<([A-Za-z_]\w*)>", r"{\1}", path)


class WebApp:
    def __init__(self, name, template_folder, static_folder):
        self.fastapi = FastAPI(title="Farbod AI-Hub", version="25.3")

        @self.fastapi.middleware("http")
        async def _security_headers_middleware(req: Request, call_next):
            response = await call_next(req)
            response.headers.setdefault("X-Content-Type-Options", "nosniff")
            response.headers.setdefault("X-Frame-Options", "DENY")
            response.headers.setdefault("Referrer-Policy", "same-origin")
            response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
            response.headers.setdefault(
                "Content-Security-Policy",
                "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; "
                "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                "font-src 'self' data:; connect-src 'self'; frame-src 'self'; media-src 'self' blob:"
            )
            forwarded_proto = (req.headers.get("x-forwarded-proto") or "").split(",", 1)[0].strip().lower()
            if req.url.scheme == "https" or forwarded_proto == "https":
                response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
            return response

        self.templates = Jinja2Templates(directory=template_folder)
        self.jinja_env = self.templates.env
        self.logger = logging.getLogger("farbod-ai-hub")
        self._config = {}
        self.templates.env.globals.update(url_for=url_for, get_flashed_messages=get_flashed_messages)
        self.fastapi.mount("/static", StaticFiles(directory=static_folder), name="static")
        self._before, self._after, self._context = [], [], []
        self._secret_key = "change-me"
        self._session_added = False
        _app_ctx.set(self)

    @property
    def secret_key(self): return self._secret_key
    @secret_key.setter
    def secret_key(self, value):
        self._secret_key = value
        if not self._session_added:
            secure_cookie = os.environ.get("FARBOD_SECURE_COOKIES", "0").lower() in {"1", "true", "yes", "on"}
            same_site = os.environ.get("FARBOD_SESSION_SAMESITE", "lax").strip().lower()
            if same_site not in {"lax", "strict", "none"}:
                same_site = "lax"
            max_age = max(300, int(os.environ.get("FARBOD_SESSION_MAX_AGE_SECONDS", "28800")))
            self.fastapi.add_middleware(
                SessionMiddleware,
                secret_key=value,
                same_site=same_site,
                https_only=secure_cookie,
                max_age=max_age,
            )
            self._session_added = True
    @property
    def config(self): return self._config
    def template_filter(self, name):
        def deco(fn): self.templates.env.filters[name] = fn; return fn
        return deco
    def context_processor(self, fn): self._context.append(fn); return fn
    def before_request(self, fn): self._before.append(fn); return fn
    def after_request(self, fn): self._after.append(fn); return fn
    def errorhandler(self, code):
        def deco(fn):
            async def handler(req, exc):
                token = _request_ctx.set(req); _app_ctx.set(self)
                try: return _normalize(fn(exc))
                finally: _request_ctx.reset(token)
            self.fastapi.add_exception_handler(code, handler)
            return fn
        return deco
    def route(self, path, methods=None):
        methods = methods or ["GET"]
        def deco(fn):
            signature = inspect.signature(fn)
            endpoint_name = fn.__name__
            async def endpoint(req: Request):
                req.scope["endpoint_name"] = endpoint_name
                token = _request_ctx.set(req); _app_ctx.set(self)
                try:
                    max_length = int(self._config.get("MAX_CONTENT_LENGTH") or 0)
                    raw_length = req.headers.get("content-length")
                    if max_length and raw_length:
                        try:
                            if int(raw_length) > max_length:
                                raise HTTPException(status_code=413, detail="Request body is too large")
                        except ValueError:
                            raise HTTPException(status_code=400, detail="Invalid Content-Length")
                    form = await req.form() if req.method in {"POST", "PUT", "PATCH", "DELETE"} and "application/json" not in req.headers.get("content-type", "") else {}
                    form_token = _form_ctx.set(form)
                    try:
                        content_type = req.headers.get("content-type", "")
                        payload = await req.json() if "application/json" in content_type else None
                    except Exception: payload = None
                    json_token = _json_ctx.set(payload)
                    try:
                        if req.method in {"POST", "PUT", "PATCH", "DELETE"}:
                            expected = req.session.get("_csrf_token") or req.session.get("search_csrf")
                            supplied = req.headers.get("x-csrf-token")
                            if not supplied and hasattr(form, "get"):
                                supplied = form.get("csrf")
                            if not supplied and isinstance(payload, dict):
                                supplied = payload.get("csrf") or payload.get("_csrf")
                            if not expected or not supplied or not secrets.compare_digest(str(supplied), str(expected)):
                                raise HTTPException(status_code=403, detail="CSRF validation failed")
                        for hook in self._before:
                            result = hook()
                            if result is not None: return _normalize(result)
                        kwargs = {k: req.path_params[k] for k in signature.parameters if k in req.path_params}
                        response = _normalize(fn(**kwargs))
                        for hook in self._after: response = _normalize(hook(response) or response)
                        return response
                    finally: _json_ctx.reset(json_token); _form_ctx.reset(form_token)
                finally: _request_ctx.reset(token)
            endpoint.__name__ = endpoint_name
            self.fastapi.add_api_route(_route_path(path), endpoint, methods=methods, name=endpoint_name)
            return fn
        return deco
    def run(self, host="127.0.0.1", port=8000, **kwargs):
        import uvicorn
        uvicorn.run(self.fastapi, host=host, port=port,
                    reload=bool(kwargs.get("use_reloader", False)))
    def test_client(self):
        from fastapi.testclient import TestClient
        client = TestClient(self.fastapi, follow_redirects=False)
        response_type = type(client.get("/healthz"))
        if not hasattr(response_type, "get_json"):
            response_type.get_json = lambda response: response.json()
            response_type.get_data = lambda response, as_text=False: response.text if as_text else response.content
            response_type.data = property(lambda response: response.content)
            response_type.location = property(lambda response: response.headers.get("location"))
        signer = TimestampSigner(str(self.secret_key))

        @contextmanager
        def session_transaction():
            data = {}
            yield data
            encoded = b64encode(json.dumps(data).encode("utf-8"))
            client.cookies.set("session", signer.sign(encoded).decode("utf-8"))

        client.session_transaction = session_transaction
        return client


def _normalize(value):
    status, headers = 200, None
    if isinstance(value, tuple):
        value, status, *rest = value
        headers = rest[0] if rest else None
    if isinstance(value, Response):
        value.status_code = status if status != 200 else value.status_code
        if headers: value.headers.update(headers)
        return value
    if isinstance(value, (dict, list)): return JSONResponse(value, status_code=status, headers=headers)
    return Response(str(value), status_code=status, headers=headers, media_type="text/html")


def _ensure_csrf_token(req=None):
    req = req or _request_ctx.get()
    token = req.session.get("_csrf_token") or req.session.get("search_csrf")
    if not token:
        token = secrets.token_urlsafe(32)
    req.session["_csrf_token"] = token
    # Backwards compatibility with v20-v24.6 templates and JavaScript.
    req.session["search_csrf"] = token
    return token


def render_template(name, **context):
    app = _app_ctx.get(); req = _request_ctx.get()
    merged = {"session": session, "csrf_token": _ensure_csrf_token(req)}
    for processor in app._context: merged.update(processor())
    merged.update(context)
    return app.templates.TemplateResponse(req, name, merged)


def url_for(endpoint, **values):
    req = _request_ctx.get()
    if endpoint == "static" and "filename" in values:
        values["path"] = values.pop("filename")
    path_values, query = {}, {}
    route = next((r for r in req.app.routes if getattr(r, "name", None) == endpoint), None)
    param_names = set(getattr(route, "param_convertors", {}))
    for key, val in values.items(): (path_values if key in param_names else query)[key] = val
    url = str(req.url_for(endpoint, **path_values))
    if query: url += ("&" if "?" in url else "?") + urlencode(query)
    return url


def redirect(location, code=302): return RedirectResponse(location, status_code=code)
def jsonify(*args, **kwargs):
    data = args[0] if len(args) == 1 else list(args) if args else kwargs
    return JSONResponse(data)
def abort(code): raise HTTPException(status_code=code)
def flash(message, category="message"):
    messages = session.setdefault("_flashes", []); messages.append((category, message)); session["_flashes"] = messages
def get_flashed_messages(with_categories=False):
    messages = session.get("_flashes", []); session["_flashes"] = []
    from i18n import translate
    messages = [(category, translate(message)) for category, message in messages]
    return messages if with_categories else [m[1] for m in messages]
def send_file(path_or_file, mimetype=None, as_attachment=False, download_name=None):
    if isinstance(path_or_file, (str, os.PathLike)):
        return FileResponse(path_or_file, media_type=mimetype, filename=download_name if as_attachment else None)
    data = path_or_file.getvalue() if hasattr(path_or_file, "getvalue") else path_or_file.read()
    headers = {"Content-Disposition": f'attachment; filename="{download_name}"'} if as_attachment and download_name else {}
    return Response(data, media_type=mimetype or "application/octet-stream", headers=headers)


def secure_filename(value):
    value = os.path.basename(value).replace(" ", "_")
    return re.sub(r"[^A-Za-z0-9_.-]", "", value)
