"""Safe background worker for v20 read-only plans and discovery jobs."""

import os
import time
from pathlib import Path

import database as db
import operations_v20 as ops
import paths


POLL_SECONDS = max(2, int(os.environ.get("FARBOD_WORKER_POLL_SECONDS", "5")))


def claim_next_job():
    conn = db.get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT * FROM v20_jobs WHERE status='queued' ORDER BY id LIMIT 1"
        ).fetchone()
        if row is None:
            conn.rollback()
            return None
        conn.execute(
            "UPDATE v20_jobs SET status='running',updated_at=? WHERE id=? AND status='queued'",
            (ops.utcnow(), row["id"]),
        )
        conn.commit()
        return dict(row)
    finally:
        conn.close()


def complete_plan(job):
    # v20.0 executes analysis/discovery only. Device-changing adapters remain
    # behind a future, explicit execution plugin and cannot be reached here.
    result = (
        "Read-only plan completed. Inventory context and policy evidence were "
        "evaluated; no infrastructure configuration was changed."
    )
    conn = db.get_conn()
    conn.execute(
        "UPDATE v20_jobs SET status='completed',action=?,updated_at=? WHERE id=?",
        (f"{job['action']} — {result}", ops.utcnow(), job["id"]),
    )
    conn.commit()
    conn.close()
    ops.record_event(db, "info", "Background Worker", f"Job #{job['id']} completed", result, f"job:{job['id']}")


def heartbeat():
    runtime = Path(paths.data_dir()) / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    (runtime / "worker-heartbeat").touch()


def main():
    db.init_db()
    ops.ensure_schema(db)
    while True:
        heartbeat()
        job = claim_next_job()
        if job:
            complete_plan(job)
            continue
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
