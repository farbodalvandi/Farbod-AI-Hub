#!/usr/bin/env bash
set -euo pipefail
url="http://127.0.0.1:11434"
model="${1:-qwen3.5:9b}"

echo "Farbod AI-Hub — Local LLM Check"
echo "--------------------------------"
if ! command -v ollama >/dev/null 2>&1; then
  echo "Ollama: NOT INSTALLED"
  exit 1
fi
echo "Ollama CLI: $(ollama --version 2>/dev/null || echo installed)"
if ! curl -fsS "$url/api/tags" >/dev/null 2>&1; then
  echo "Ollama API: OFFLINE ($url)"
  exit 2
fi
echo "Ollama API: ONLINE ($url)"
if ollama list | awk 'NR>1 {print $1}' | grep -Fxq "$model"; then
  echo "Model: INSTALLED ($model)"
else
  echo "Model: NOT FOUND ($model)"
  echo "Installed models:"
  ollama list || true
  exit 3
fi
