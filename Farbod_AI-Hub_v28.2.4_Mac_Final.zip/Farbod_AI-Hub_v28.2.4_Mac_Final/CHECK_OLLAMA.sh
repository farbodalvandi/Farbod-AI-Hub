#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker compose --env-file .env.docker exec -T app python - <<'PYTEST'
import os,json,urllib.request
url=os.environ['FHW_OLLAMA_URL'].rstrip('/')
with urllib.request.urlopen(url+'/api/tags',timeout=10) as r: data=json.load(r)
names=[m['name'] for m in data.get('models',[])]
print('Ollama reachable:',url)
print('Installed models:',', '.join(names) or '(none)')
model=os.environ['FHW_OLLAMA_MODEL']
if model not in names: raise SystemExit('Configured model missing: '+model)
print('Configured model is available:',model)
PYTEST
