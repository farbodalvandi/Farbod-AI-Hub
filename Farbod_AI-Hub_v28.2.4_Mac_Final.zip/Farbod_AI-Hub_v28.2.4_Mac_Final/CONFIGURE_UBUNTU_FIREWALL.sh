#!/usr/bin/env bash
set -euo pipefail
if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with sudo: sudo ./CONFIGURE_UBUNTU_FIREWALL.sh"
  exit 1
fi
if ! command -v ufw >/dev/null 2>&1; then
  echo "UFW is not installed; no UFW rules were changed."
  exit 0
fi
status="$(ufw status | head -1)"
if ! grep -Eqi '^Status:[[:space:]]+active[[:space:]]*$' <<<"$status"; then
  echo "UFW is not active; no firewall rule is required here."
  exit 0
fi
ufw allow 80/tcp comment 'Farbod AI-Hub HTTP redirect'
ufw allow 443/tcp comment 'Farbod AI-Hub HTTPS'
ufw status
