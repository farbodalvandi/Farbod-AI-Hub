#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"
if [[ -f .env.docker ]]; then
  C=(docker compose --env-file .env.docker --profile https)
else
  C=(docker compose --profile https)
fi
"${C[@]}" cp caddy:/data/caddy/pki/authorities/local/root.crt ./fhw-caddy-root.crt
echo "Exported: $project_dir/fhw-caddy-root.crt"
echo "Install this CA certificate only on managed/trusted client devices that should trust Farbod AI-Hub HTTPS."
