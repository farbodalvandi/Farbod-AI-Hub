# Farbod AI-Hub v27.0.5 — Local LLM on macOS

This edition is prepared for a native local LLM using Ollama. The recommended default model is `qwen3.5:9b` and the default answer mode is `hybrid`.

## One-click setup

Double-click:

`SETUP_LOCAL_LLM_MAC.command`

The helper will:

1. install Ollama if it is missing using Ollama's official installer;
2. start the local Ollama API on `127.0.0.1:11434`;
3. download `qwen3.5:9b`;
4. test the local model;
5. restart an installed Farbod AI-Hub macOS service when possible.

Then open **Settings → Local AI / Ollama** and confirm:

- Provider: `Ollama local LLM`
- URL for native macOS: `http://127.0.0.1:11434`
- Model: `qwen3.5:9b`
- Answer mode: `Hybrid`

## Docker Desktop on the same Mac

Containers cannot reach the Mac host through `127.0.0.1`. The included `compose.yaml` therefore uses:

`http://host.docker.internal:11434`

The Docker defaults are already set to Ollama + `qwen3.5:9b` + Hybrid.

## Smaller or larger models

You can run the setup helper with another model:

```bash
./SETUP_LOCAL_LLM_MAC.command qwen3.5:4b
```

or:

```bash
./SETUP_LOCAL_LLM_MAC.command qwen3.5:27b
```

`qwen3.5:4b` uses less unified memory. `qwen3.5:9b` is the recommended balanced default for Apple Silicon. Use 27B only when sufficient unified memory is available.

## How AI Assist uses it

AI Assist continues to check structured application data first, including RAID flow, inventory analysis, physical port mapping, rack capacity, asset search and indexed Knowledge evidence. Ollama then produces a conversational answer from the retrieved evidence. In Hybrid mode, when no local evidence matches, the local model may answer from its own general knowledge and the UI displays that distinction.

If Ollama is stopped or the selected model is missing, AI Assist falls back to local evidence search instead of making the application unavailable.
