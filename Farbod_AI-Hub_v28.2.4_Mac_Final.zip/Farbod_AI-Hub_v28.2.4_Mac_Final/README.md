# Farbod AI-Hub 28.2.0 — Mac Complete

Based on Mac 27.0.9, preserving Equipment Profile types, site/subcategory deletion, custom fields and previous fixes.

## Appearance
- Removed Forest Green. Existing Forest selection migrates to Glassy Light.
- Restored Glassy Light: pale blue translucent panels and navy controls.
- Added Cream Light: warm ivory background, white cards/fields, dark text and terracotta actions inspired by the supplied reference.
- Retained Dusty Rose, Steel Blue, Classic Dark and Midnight Amber.
- Shared selection across the main app and Linux Health. First-run default: Cream Light.

## Mac upgrade
Back up your existing data first. Start Docker Desktop, extract this ZIP and run RUN_MAC.command. If needed, open Terminal in the extracted folder and run `bash RUN_MAC.command`.
Keep your existing data directories and .env.docker. The launcher detects an existing Docker installation and retains its mounted data. Release checks and image tags use 28.2.0.

This source package requires access to configured image/package sources for Docker build. It does not include a prebuilt offline image.

## 28.2.0 — Automation and enterprise workflow
- Home modules are grouped by inventory, operations, and knowledge. Data Quality and Automation Center have direct entry points.
- The Automation Center can run a read-only inventory quality scan on demand or daily/weekly on the server's local clock. Results and findings remain in the writable data directory and appear in the event log.
- Page surfaces, typography, table headers, status colors, focus states, and controls use one higher-contrast enterprise system in light and dark modes.
- Audit logs, asset change history, data quality review, operations approvals, and backup schedules remain available.
