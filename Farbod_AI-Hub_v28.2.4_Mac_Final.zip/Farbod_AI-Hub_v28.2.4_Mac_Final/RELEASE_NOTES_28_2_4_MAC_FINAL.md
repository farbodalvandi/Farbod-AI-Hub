# Farbod AI-Hub 28.2.4 — Mac Final

Personal Farbod branding and original logo. Complete application from company 28.2.4, adapted to the established Mac Docker Desktop launchers and deployment configuration.

Includes independent Linux Health Command Library with searchable custom/built-in commands, full script editing and no default-selected commands; 1–256 network/SAN ports; eight FC and eight Ethernet ports per named ICB; optional warehouse identifiers with duplicate detection; atomic bulk issues; mandatory movement dates and filtered Excel reports; all five themes.

Start Docker Desktop, extract this archive and run DOCKER_START.command. Open https://localhost. First build requires access to public images/package sources. For upgrades, back up first, preserve .env.docker and docker-data, overlay application files in the existing installation and run DOCKER_UPDATE.command. Existing custom image references and data paths are retained. No architecture is forced; Docker selects the platform supported by the Mac.

Local Ollama default: http://host.docker.internal:11434. Model weights are not bundled.

This is a Final release package, not a signed macOS .app or DMG. Validation is performed with mocked Mac launcher commands and local application/browser tests; native macOS Docker execution is not available in this environment.
