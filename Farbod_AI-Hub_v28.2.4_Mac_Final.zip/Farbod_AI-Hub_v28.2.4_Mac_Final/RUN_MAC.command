#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo 'Install/start Docker Desktop first.'; exit 1; }
docker info >/dev/null 2>&1 || { echo 'Start Docker Desktop and wait until it is ready.'; exit 1; }
# Keep existing bind-mounted data when this complete release is extracted elsewhere.
if [[ ! -f .env.docker ]] && docker inspect farbod-ai-hub-app >/dev/null 2>&1; then
  old_dir="$(docker inspect -f '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' farbod-ai-hub-app)"
  old_project="$(docker inspect -f '{{ index .Config.Labels "com.docker.compose.project" }}' farbod-ai-hub-app)"
  data_source="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{if eq .Type "bind"}}{{.Source}}{{end}}{{end}}{{end}}' farbod-ai-hub-app)"
  backup_source="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/backups"}}{{if eq .Type "bind"}}{{.Source}}{{end}}{{end}}{{end}}' farbod-ai-hub-app)"
  if [[ -z "$data_source" || -z "$backup_source" || ! -d "$data_source" || ! -d "$backup_source" ]]; then
    echo 'Existing installation found, but its data directories could not be verified. No containers were changed.'
    exit 1
  fi
  for setting in "$data_source" "$backup_source" "$old_project"; do
    if [[ "$setting" == *"'"* || "$setting" == *$'\n'* || "$setting" == *$'\r'* ]]; then
      echo 'The existing path/project requires manual configuration. No containers were changed.'; exit 1
    fi
  done
  running="$(docker inspect -f '{{.State.Running}}' farbod-ai-hub-app)"
  if [[ "$running" == true ]]; then
    echo 'Creating backup of the existing installation...'
    docker exec farbod-ai-hub-app python /app/scripts/backup_data.py
  fi
  umask 077
  tmp_env="$(mktemp .env.docker.XXXXXX)"
  trap 'rm -f "$tmp_env"' EXIT
  if [[ -f "$old_dir/.env.docker" ]]; then
    cp "$old_dir/.env.docker" "$tmp_env"
  else
    cp .env.docker.example "$tmp_env"
    printf '\nFHW_DOCKER_UID=%s\nFHW_DOCKER_GID=%s\n' "$(id -u)" "$(id -g)" >> "$tmp_env"
  fi
  # Repair legacy damage before replacing the managed values.
  perl -pi -e 's/^(FHW_DOCKER_IMAGE=farbod-ai-hub:27\.0\.3)(FHW_[A-Z0-9_]+=)/$1\n$2/' "$tmp_env"
  perl -ni -e 'print unless /^(FHW_DOCKER_DATA_DIR|FHW_DOCKER_BACKUP_DIR|FHW_DOCKER_IMAGE|COMPOSE_PROJECT_NAME)=/' "$tmp_env"
  printf '\nFHW_DOCKER_IMAGE=farbod-ai-hub:28.2.0\n' >> "$tmp_env"
  printf "FHW_DOCKER_DATA_DIR='%s'\nFHW_DOCKER_BACKUP_DIR='%s'\n" "$data_source" "$backup_source" >> "$tmp_env"
  if [[ -n "$old_project" && "$old_project" != '<no value>' ]]; then
    printf "COMPOSE_PROJECT_NAME='%s'\n" "$old_project" >> "$tmp_env"
  fi
  chmod 600 "$tmp_env"
  mv "$tmp_env" .env.docker
  trap - EXIT
  echo "Existing data retained at: $data_source"
fi
exec bash docker-macos/setup.command
