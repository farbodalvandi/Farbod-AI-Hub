#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"

command -v docker >/dev/null || { echo "Docker Engine is required."; exit 1; }
docker info >/dev/null 2>&1 || { echo "Docker is not running or this user cannot access it."; exit 1; }
docker compose version >/dev/null || { echo "Docker Compose v2 is required."; exit 1; }

if [[ ! -f .env.docker ]]; then
  cp .env.docker.example .env.docker
  sed -i "s/^FHW_DOCKER_UID=.*/FHW_DOCKER_UID=$(id -u)/" .env.docker
  sed -i "s/^FHW_DOCKER_GID=.*/FHW_DOCKER_GID=$(id -g)/" .env.docker
  chmod 600 .env.docker
fi

mkdir -p docker-data/data/{instance,knowledge,equipment_files,bank_connection_info,subobject_files,logs,runtime} docker-data/backups
chmod -R u+rwX docker-data
docker compose --env-file .env.docker config --quiet
docker compose --env-file .env.docker up -d --build app worker backup
docker compose --env-file .env.docker ps
echo "Farbod AI-Hub v28.1.3: http://127.0.0.1:8000"
