#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
model="${1:-qwen3.5:9b}"
ollama_url="http://127.0.0.1:11434"

pause_terminal() {
  if [[ -t 0 ]]; then read -r -p "Press Return to close…" _; fi
}

trap 'echo; echo "Local LLM setup did not finish. Review the message above."; pause_terminal' ERR

echo "============================================================"
echo " Farbod AI-Hub v28.2.0 — Local LLM Setup"
echo " Model: $model"
echo "============================================================"
echo

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This helper is for macOS."
  exit 1
fi

if ! command -v ollama >/dev/null 2>&1; then
  echo "Ollama is not installed. Installing the official local runtime…"
  curl -fsSL https://ollama.com/install.sh | sh
fi

echo "Ollama: $(ollama --version 2>/dev/null || echo installed)"

# Start the native macOS app when present. Otherwise start the CLI server.
if ! curl -fsS "$ollama_url/api/tags" >/dev/null 2>&1; then
  if [[ -d /Applications/Ollama.app ]]; then
    echo "Starting Ollama.app…"
    open -a Ollama
  else
    echo "Starting Ollama local service…"
    mkdir -p "$HOME/Library/Logs/FarbodAIHub"
    nohup ollama serve >"$HOME/Library/Logs/FarbodAIHub/ollama.log" 2>&1 &
  fi
fi

printf "Waiting for Ollama API"
for _ in {1..30}; do
  if curl -fsS "$ollama_url/api/tags" >/dev/null 2>&1; then
    echo " — ready"
    break
  fi
  printf "."
  sleep 1
 done

if ! curl -fsS "$ollama_url/api/tags" >/dev/null 2>&1; then
  echo
  echo "Ollama did not become ready at $ollama_url."
  exit 1
fi

echo
echo "Downloading local model $model …"
ollama pull "$model"

echo
echo "Testing the model…"
response="$(curl -fsS "$ollama_url/api/chat" \
  -H 'Content-Type: application/json' \
  -d "{\"model\":\"$model\",\"messages\":[{\"role\":\"user\",\"content\":\"Reply with exactly: LOCAL AI READY\"}],\"stream\":false}" || true)"
if [[ "$response" == *"LOCAL AI READY"* ]]; then
  echo "Model test: OK"
else
  echo "Model responded, but the exact health phrase was not detected. The runtime is still available."
fi

# Update native settings only when a .env already manages AI via environment variables.
# Fresh/native v28.2.0 installs use database-backed settings, so the Settings page remains editable.
if [[ -f "$project_dir/.env" ]] && grep -qE '^FHW_AI_PROVIDER=' "$project_dir/.env"; then
  python3 - "$project_dir/.env" "$model" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); model=sys.argv[2]
text=p.read_text(encoding='utf-8')
updates={
 'FHW_AI_PROVIDER':'ollama',
 'FHW_OLLAMA_URL':'http://127.0.0.1:11434',
 'FHW_OLLAMA_MODEL':model,
 'FHW_AI_ANSWER_MODE':'hybrid',
}
lines=text.splitlines()
seen=set(); out=[]
for line in lines:
    key=line.split('=',1)[0].strip() if '=' in line and not line.lstrip().startswith('#') else ''
    if key in updates:
        out.append(f'{key}={updates[key]}'); seen.add(key)
    else:
        out.append(line)
for key,value in updates.items():
    if key not in seen: out.append(f'{key}={value}')
p.write_text('\n'.join(out)+'\n',encoding='utf-8')
PY
fi

echo
echo "Local LLM is ready."
echo "Ollama API: $ollama_url"
echo "Model:      $model"
echo
echo "Next: restart Farbod AI-Hub, then open Settings → Local AI / Ollama."

# Restart an installed native Farbod AI-Hub service if present.
if [[ -x "$project_dir/macos/restart.command" ]] && [[ -f "$HOME/Library/LaunchAgents/com.fhw.aihub.plist" ]]; then
  echo "Restarting Farbod AI-Hub…"
  "$project_dir/macos/restart.command" || true
fi

pause_terminal
