$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker Desktop is required. Install it and enable Linux containers."
}
docker info | Out-Null
docker compose version | Out-Null

if (-not (Test-Path ".env.docker")) {
    Copy-Item ".env.docker.example" ".env.docker"
}

$directories = @(
    "docker-data/data/instance", "docker-data/data/knowledge",
    "docker-data/data/equipment_files", "docker-data/data/bank_connection_info",
    "docker-data/data/subobject_files", "docker-data/data/logs",
    "docker-data/data/runtime", "docker-data/backups"
)
foreach ($directory in $directories) {
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
}

docker compose --env-file .env.docker config --quiet
docker compose --env-file .env.docker up -d --build app worker backup
docker compose --env-file .env.docker ps
Write-Host "FHW AI Hub v26.3.2: http://127.0.0.1:8000" -ForegroundColor Green
Start-Process "http://127.0.0.1:8000"
