# -*- coding: utf-8 -*-
"""
Farbod AI-Hub - Enterprise Infrastructure Platform
Run:
    pip install -r requirements.txt
    python3 app.py
Then open the configured URL. New installations generate a one-time admin password in instance/bootstrap-admin.txt.
"""

import csv
import io
import os
import secrets
import uuid
import json
import math
import urllib.request
import urllib.error
from urllib.parse import urlparse
import ssl
import base64
import ipaddress
import time
import platform
import shutil
import shlex
import sys
import threading
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime

from dotenv import load_dotenv

# Load project-local production settings before modules resolve writable paths.
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"), override=False)

from webcore import (WebApp, render_template, request, redirect, url_for,
                     session, flash, jsonify, send_file, abort, secure_filename)
from werkzeug.security import check_password_hash
from cryptography.fernet import Fernet
from PIL import Image, UnidentifiedImageError

import database as db
from auth import login_required, role_required, current_user
import visio_export
import paths
import backup_manager
import raid_calculator
from workspace_navigation import workspace_section
from ai_engine import InfrastructureAgent, ollama_status
import search_service
from api_v2.main import router as agentic_router
from linux_health_api import router as linux_health_router
from monitoring_connectors import probe as probe_monitoring, CONNECTORS as MONITORING_CONNECTORS
import operations_v20 as ops20
import automation_center as automation
import asset_intelligence as intelligence

try:
    from openpyxl import Workbook
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

RESOURCE_DIR = paths.resource_dir()   # bundled templates/static (read-only)
BASE_DIR = paths.data_dir()           # writable application data
SECRET_FILE = os.path.join(BASE_DIR, "instance", "secret.key")
STARTED_AT = time.time()
APP_VERSION = "28.2.4"

app = WebApp(
    __name__,
    template_folder=os.path.join(RESOURCE_DIR, "templates"),
    static_folder=os.path.join(RESOURCE_DIR, "static"),
)
# ISO images are large; allow big uploads (default 16GB, override via env var).
MAX_CONTENT_LENGTH = int(os.environ.get("FHW_ASSET_MAX_UPLOAD_MB", "16384")) * 1024 * 1024

# AI-Hub / Knowledge module
KNOWLEDGE_DIR = os.path.join(BASE_DIR, "knowledge")
os.makedirs(KNOWLEDGE_DIR, exist_ok=True)
PROFILE_IMAGE_DIR = os.path.join(BASE_DIR, "profile_images")
os.makedirs(PROFILE_IMAGE_DIR, exist_ok=True)
PROFILE_IMAGE_MAX_BYTES = 2 * 1024 * 1024
KNOWLEDGE_CATEGORIES = {
    "server": "Server",
    "storage": "Storage",
    "sanswitch": "SAN Switch",
}
KNOWLEDGE_EXTENSIONS = {".pdf", ".doc", ".docx"}


def _load_secret():
    """Load a stable signing/encryption secret without shipping one in source control."""
    os.makedirs(os.path.dirname(SECRET_FILE), exist_ok=True)
    env_secret = os.environ.get("FHW_SECRET_KEY", "").strip()
    if env_secret:
        if len(env_secret) < 32:
            raise RuntimeError("FHW_SECRET_KEY must contain at least 32 characters.")
        return env_secret
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "r", encoding="utf-8") as handle:
            key = handle.read().strip()
        if len(key) < 32:
            raise RuntimeError("The persisted application secret is too short. Restore the original secret or set FHW_SECRET_KEY.")
        try:
            os.chmod(SECRET_FILE, 0o600)
        except OSError:
            pass
        return key
    key = secrets.token_urlsafe(48)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(SECRET_FILE, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(key)
    return key


app.secret_key = _load_secret()
app.fastapi.include_router(agentic_router)
app.fastapi.include_router(linux_health_router)
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
app.config["AI_REQUESTS_PER_MINUTE"] = int(os.environ.get("FHW_AI_REQUESTS_PER_MINUTE", "20"))

def _credential_cipher():
    import hashlib, base64 as _b64
    return Fernet(_b64.urlsafe_b64encode(hashlib.sha256(app.secret_key.encode()).digest()))

def _encrypt_secret(value): return _credential_cipher().encrypt(value.encode()).decode()
def _decrypt_secret(value): return _credential_cipher().decrypt(value.encode()).decode()
# Honor forwarding headers only when explicitly running behind a trusted proxy.
TRUST_PROXY = os.environ.get("FHW_ASSET_TRUST_PROXY", "0") not in ("0", "false", "False")
SESSION_IDLE_TIMEOUT = max(300, int(os.environ.get("FHW_SESSION_IDLE_SECONDS", "1800")))
LOGIN_MAX_FAILURES = max(3, int(os.environ.get("FHW_LOGIN_MAX_FAILURES", "5")))
LOGIN_WINDOW_SECONDS = max(60, int(os.environ.get("FHW_LOGIN_WINDOW_SECONDS", "900")))
LOGIN_LOCK_SECONDS = max(60, int(os.environ.get("FHW_LOGIN_LOCK_SECONDS", "900")))
PASSWORD_MIN_LENGTH = max(10, int(os.environ.get("FHW_PASSWORD_MIN_LENGTH", "10")))
DOCUMENT_MAX_BYTES = max(1, int(os.environ.get("FHW_DOCUMENT_MAX_UPLOAD_MB", "64"))) * 1024 * 1024
IMPORT_MAX_BYTES = max(1, int(os.environ.get("FHW_IMPORT_MAX_UPLOAD_MB", "32"))) * 1024 * 1024
VDX_MAX_BYTES = max(1, int(os.environ.get("FHW_VDX_MAX_UPLOAD_MB", "32"))) * 1024 * 1024
_login_attempts = {}
_login_attempts_lock = threading.Lock()


def _request_ip():
    remote = request.remote_addr or "unknown"
    if TRUST_PROXY:
        forwarded = (request.headers.get("x-forwarded-for") or "").split(",", 1)[0].strip()
        try:
            if forwarded:
                ipaddress.ip_address(forwarded)
                return forwarded
        except ValueError:
            pass
    return remote


def _request_is_https():
    if request.is_secure:
        return True
    return TRUST_PROXY and (request.headers.get("x-forwarded-proto") or "").split(",", 1)[0].strip().lower() == "https"


def _safe_local_redirect(value, fallback):
    value = (value or "").strip()
    if value.startswith("/") and not value.startswith("//") and "\\" not in value:
        return value
    return fallback


def _login_key(username):
    return f"{_request_ip()}|{(username or '').strip().lower()[:128]}"


def _login_locked(key):
    now = time.time()
    with _login_attempts_lock:
        entry = _login_attempts.get(key, {"failures": [], "locked_until": 0})
        if entry.get("locked_until", 0) > now:
            return True
        failures = [ts for ts in entry.get("failures", []) if now - ts <= LOGIN_WINDOW_SECONDS]
        if failures:
            entry["failures"] = failures
            _login_attempts[key] = entry
        else:
            _login_attempts.pop(key, None)
        return False


def _record_login_failure(key):
    now = time.time()
    with _login_attempts_lock:
        entry = _login_attempts.setdefault(key, {"failures": [], "locked_until": 0})
        failures = [ts for ts in entry.get("failures", []) if now - ts <= LOGIN_WINDOW_SECONDS]
        failures.append(now)
        entry["failures"] = failures
        if len(failures) >= LOGIN_MAX_FAILURES:
            entry["locked_until"] = now + LOGIN_LOCK_SECONDS


def _clear_login_failures(key):
    with _login_attempts_lock:
        _login_attempts.pop(key, None)


def _validate_new_password(password):
    if not isinstance(password, str) or len(password) < PASSWORD_MIN_LENGTH:
        raise ValueError(f"Password must contain at least {PASSWORD_MIN_LENGTH} characters.")
    if len(password) > 128:
        raise ValueError("Password must contain no more than 128 characters.")
    if password.lower() in {"admin123", "password", "password123", "changeme", "qwerty123"}:
        raise ValueError("Choose a less predictable password.")
    return password


def _read_upload_limited(upload, limit_bytes):
    upload.seek(0)
    chunks, total = [], 0
    while True:
        chunk = upload.read(min(1024 * 1024, limit_bytes + 1 - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
        if total > limit_bytes:
            raise ValueError(f"Upload exceeds the {max(1, limit_bytes // (1024 * 1024))} MB limit.")
    upload.seek(0)
    return b"".join(chunks)


def _validate_file_signature(filename, data):
    ext = os.path.splitext(filename or "")[1].lower()
    if not data:
        raise ValueError("The uploaded file is empty.")
    zip_ext = {".docx", ".xlsx", ".vsdx", ".zip"}
    ole_ext = {".doc", ".xls"}
    if ext in zip_ext:
        if not data.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")):
            raise ValueError(f"The uploaded {ext} file does not have a valid ZIP/Office container signature.")
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                infos = archive.infolist()
                if len(infos) > 10000:
                    raise ValueError("The uploaded archive contains too many entries.")
                total_uncompressed = sum(max(0, info.file_size) for info in infos)
                if total_uncompressed > 512 * 1024 * 1024:
                    raise ValueError("The uploaded archive expands beyond the allowed safety limit.")
                names = [info.filename.replace("\\", "/") for info in infos]
                if any(name.startswith("/") or name.startswith("../") or "/../" in f"/{name}" for name in names):
                    raise ValueError("The uploaded archive contains unsafe paths.")
                expected = {".docx": "word/", ".xlsx": "xl/", ".vsdx": "visio/"}.get(ext)
                if expected and not any(name.startswith(expected) for name in names):
                    raise ValueError(f"The uploaded {ext} file is not a valid Office/Visio package.")
        except zipfile.BadZipFile as exc:
            raise ValueError("The uploaded ZIP/Office container is corrupt.") from exc
    if ext in ole_ext and not data.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        raise ValueError(f"The uploaded {ext} file does not have a valid legacy Office signature.")
    if ext == ".pdf" and not data.lstrip().startswith(b"%PDF-"):
        raise ValueError("The uploaded PDF signature is invalid.")
    if ext in {".jpg", ".jpeg"} and not data.startswith(b"\xff\xd8\xff"):
        raise ValueError("The uploaded JPEG signature is invalid.")
    if ext == ".png" and not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("The uploaded PNG signature is invalid.")
    if ext in {".csv", ".txt", ".vdx"} and b"\x00" in data[:65536]:
        raise ValueError("The uploaded text/XML file contains unexpected binary data.")
    return ext


def _save_upload_limited(upload, destination, limit_bytes, validate_signature=True):
    data = _read_upload_limited(upload, limit_bytes)
    if validate_signature:
        _validate_file_signature(upload.filename, data)
    tmp = destination + ".part-" + uuid.uuid4().hex
    try:
        with open(tmp, "wb") as handle:
            handle.write(data)
        os.replace(tmp, destination)
    finally:
        if os.path.exists(tmp):
            try: os.remove(tmp)
            except OSError: pass
    return len(data)


def _sanitize_svg(svg):
    """Strip active/external SVG content before embedding a converted VSDX preview."""
    try:
        root = ET.fromstring(svg)
    except ET.ParseError:
        raise ValueError("The converted diagram contains invalid SVG.")
    forbidden = {"script", "foreignObject", "iframe", "object", "embed", "audio", "video"}
    def local(tag): return tag.rsplit("}", 1)[-1]
    def clean(node):
        for child in list(node):
            if local(child.tag) in forbidden:
                node.remove(child)
            else:
                clean(child)
        for key in list(node.attrib):
            name = local(key).lower()
            value = str(node.attrib.get(key, "")).strip().lower()
            if name.startswith("on") or name in {"href", "src"} and value and not value.startswith("#"):
                node.attrib.pop(key, None)
            elif name == "style" and ("url(" in value or "expression(" in value):
                node.attrib.pop(key, None)
    clean(root)
    return ET.tostring(root, encoding="unicode")

# Initialize/migrate the database with a useful startup error.
try:
    db.init_db()
    ops20.ensure_schema(db)
except Exception as exc:
    _startup_error_placeholder = None
    try:
        os.makedirs(BASE_DIR, exist_ok=True)
        with open(os.path.join(paths.logs_dir(), "startup.log"), "a", encoding="utf-8") as f:
            import traceback
            f.write("\n--- database initialization failure %s ---\n" % datetime.now().isoformat())
            traceback.print_exc(file=f)
    except Exception:
        pass
    raise


@app.errorhandler(500)
def internal_server_error(error):
    # Keep the browser response friendly while writing the full traceback for
    # diagnosis.
    try:
        import traceback
        log_path = os.path.join(paths.logs_dir(), "server_error.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("\n--- HTTP 500 %s ---\n" % datetime.now().isoformat())
            traceback.print_exc(file=f)
    except Exception:
        log_path = "server_error.log"
    return render_template("error.html", log_path=log_path), 500


@app.template_filter("todict")
def todict_filter(row):
    return dict(row) if row is not None else {}


from i18n import locale as ui_locale, translate
app.jinja_env.filters["tr"] = translate

@app.route("/language", methods=["POST"])
def set_language():
    lang = request.form.get("language", "en")
    if lang not in ("en", "fa"):
        abort(400)
    response = redirect(_safe_local_redirect(request.form.get("next"), url_for("hardware_hub") if current_user() else url_for("login")))
    response.set_cookie("fhw_language", lang, max_age=31536000, httponly=True, samesite="lax", secure=request.is_secure)
    return response

@app.context_processor
def inject_globals():
    if current_user():
        token = session.get("_csrf_token") or session.get("search_csrf") or secrets.token_urlsafe(32)
        session["_csrf_token"] = token
        session["search_csrf"] = token
    return {"_": translate, "ui_language": ui_locale(), "ui_direction": "rtl" if ui_locale() == "fa" else "ltr", "SCHEMAS": db.SCHEMAS, "current_user": current_user(), "ROLE_LEVEL": db.ROLE_LEVEL,
            "db_sub_files": db.list_sub_object_files, "APP_VERSION": APP_VERSION,
            "can_use_ai": module_allowed("ai_assistant"), "active_workspace": workspace_section(request.path)}


@app.before_request
def enforce_session_security():
    username = session.get("username")
    if not username:
        return None
    now = int(time.time())
    try:
        last_activity = int(session.get("last_activity") or 0)
    except (TypeError, ValueError):
        last_activity = 0
    if last_activity and now - last_activity > SESSION_IDLE_TIMEOUT:
        db.remove_presence(username, session.get("presence_id"))
        db.log_action(username, "session_timeout", f"ip={_request_ip()}")
        session.clear()
        if request.path.startswith("/api/"):
            return jsonify({"error": "session_expired"}), 401
        flash("Your session expired. Please sign in again.", "warning")
        return redirect(url_for("login", next=request.path))
    session["last_activity"] = now
    sid = session.get("presence_id")
    if not sid:
        sid = secrets.token_urlsafe(16)
        session["presence_id"] = sid
    db.touch_presence(username, sid, _request_ip())
    return None


@app.after_request
def apply_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; "
        "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
        "font-src 'self' data:; connect-src 'self'; frame-src 'self'; media-src 'self' blob:"
    )
    if session.get("username"):
        response.headers.setdefault("Cache-Control", "no-store, private")
        response.headers.setdefault("Pragma", "no-cache")
    if _request_is_https():
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.route("/api/online-users")
@login_required
def online_users_api():
    users = db.online_users()
    return jsonify({"count": len(users), "users": [dict(u) for u in users]})


@app.route("/healthz")
def healthz():
    """Small readiness endpoint for containers and reverse proxies."""
    try:
        conn = db.get_conn()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        payload = ops20.health_payload(db)
        payload["control_plane_version"] = payload.get("version", ops20.VERSION)
        payload["version"] = APP_VERSION
        payload["build"] = APP_VERSION + "-automation-enterprise"
        payload["database"] = "ready"
        return jsonify(payload)
    except Exception:
        return jsonify({"status": "error", "service": "FarbodAIHub", "version": APP_VERSION}), 503

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        key = _login_key(username)
        if _login_locked(key):
            db.log_action(username or None, "login_blocked", f"ip={_request_ip()}")
            flash("Too many failed sign-in attempts. Try again later.", "danger")
            return render_template("login.html"), 429
        user = db.get_user(username)
        if user and user["active"] and check_password_hash(user["password_hash"], password):
            _clear_login_failures(key)
            session.clear()
            session["username"] = username
            session["presence_id"] = secrets.token_urlsafe(16)
            session["last_activity"] = int(time.time())
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
            session["search_csrf"] = token
            db.touch_presence(username, session["presence_id"], _request_ip())
            db.log_action(username, "login", f"ip={_request_ip()}")
            return redirect(_safe_local_redirect(request.args.get("next"), url_for("hardware_hub")))
        _record_login_failure(key)
        db.log_action(username or None, "login_failed", f"ip={_request_ip()}")
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    username = session.get("username")
    if username:
        db.remove_presence(username, session.get("presence_id"))
        db.log_action(username, "logout", f"ip={_request_ip()}")
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# AI-Hub / independent module authentication
# ---------------------------------------------------------------------------

MODULES = {
    "warehouse": {"title": "Warehouse", "icon": "bi-box-seam", "description": "Stock codes, receipts, issues and movement history."},
    "asset_manager": {"title": "Farbod AI-Hub", "icon": "bi-hdd-stack-fill",
                      "description": "Inventory, assets, SAN, storage and data-center management."},
    "knowledge": {"title": "Knowledge", "icon": "bi-book-half",
                  "description": "Technical knowledge base and technical documents."},
    "equipment_profile": {"title": "Equipment", "icon": "bi-cpu-fill",
                          "description": "Equipment banks, subcategories and technical documents."},
    "ai_assistant": {"title": "AI Assistant", "icon": "bi-stars",
                     "description": "Context-aware infrastructure search and analysis workspace."},
    "monitoring": {"title": "Hardware Monitoring", "icon": "bi-activity",
                   "description": "NOC-style inventory health, status and alert workspace."},
    "operations": {"title": "Autonomous Operations", "icon": "bi-diagram-2-fill",
                   "description": "Human-in-the-loop agents, connectors, jobs and approvals."},
    "linux_health": {"title": "Linux Health", "icon": "bi-terminal",
                     "description": "Read-only Linux and SAN host diagnostics."},
    "settings": {"title": "Settings", "icon": "bi-sliders2",
                 "description": "System and AI configuration."},
}
ROLE_MODULES = {
    "admin": set(MODULES),
    "manager": {"warehouse", "asset_manager", "knowledge", "equipment_profile", "ai_assistant", "monitoring", "operations", "linux_health"},
    "operator": {"warehouse", "asset_manager", "knowledge", "ai_assistant", "monitoring", "operations", "linux_health"},
}

def module_allowed(module_key):
    user=current_user()
    return bool(user and module_key in ROLE_MODULES.get(user["role"], set()))

def module_required(module_key):
    def decorator(view):
        from functools import wraps
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user():
                return redirect(url_for("login", next=request.path))
            key=kwargs.get("module_key") if module_key=="__dynamic__" else module_key
            if key not in MODULES or not module_allowed(key):
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


from warehouse import register_routes as register_warehouse
register_warehouse(app, module_required)

# ---------------------------------------------------------------------------
# v20 Enterprise Control Plane
# ---------------------------------------------------------------------------

def _safe_parameters(raw):
    try:
        values = json.loads(raw or "[]")
        if not isinstance(values, list): return []
        return [{"name": str(x.get("name", ""))[:80], "value": str(x.get("value", ""))[:500]} for x in values if isinstance(x, dict) and (x.get("name") or x.get("value"))][:50]
    except Exception:
        return []

def _require_v20_csrf():
    if not secrets.compare_digest(request.form.get("csrf", ""), session.get("search_csrf", "missing")):
        abort(403)

@app.route("/operations")
@module_required("operations")
def operations_center():
    return render_template(
        "operations_v20.html",
        snapshot=ops20.platform_snapshot(db),
        jobs=ops20.list_jobs(db, 8),
        connectors=ops20.list_connectors(db),
        agents=ops20.AGENTS,
    )


@app.route("/operations/agents")
@module_required("operations")
def agent_center_v20():
    return render_template("agents_v20.html", agents=ops20.AGENTS, jobs=ops20.list_jobs(db, 50))


@app.route("/operations/connectors", methods=["GET", "POST"])
@module_required("operations")
def connectors_v20():
    if request.method == "POST":
        _require_v20_csrf()
        if db.ROLE_LEVEL.get(current_user()["role"], 0) < db.ROLE_LEVEL["manager"]:
            abort(403)
        try:
            ops20.add_connector(
                db,
                request.form.get("name", ""),
                request.form.get("connector_type", ""),
                request.form.get("endpoint", ""),
                current_user()["username"],
            )
            db.log_action(current_user()["username"], "v20_connector_create", request.form.get("name", ""))
            flash("Connector registered in read-only mode.", "success")
        except Exception as exc:
            flash(f"Could not register connector: {exc}", "danger")
        return redirect(url_for("connectors_v20"))
    return render_template(
        "connectors_v20.html",
        connector_types=ops20.CONNECTOR_TYPES,
        connectors=ops20.list_connectors(db),
    )


@app.route("/operations/connectors/<int:connector_id>/discover", methods=["POST"])
@module_required("operations")
def connector_discover_v20(connector_id):
    _require_v20_csrf()
    try:
        job_id = ops20.mark_connector_sync(db, connector_id, current_user()["username"])
        db.log_action(current_user()["username"], "v20_discovery_queued", f"job#{job_id}")
        flash(f"Read-only discovery job #{job_id} queued.", "success")
    except Exception as exc:
        flash(f"Discovery could not be queued: {exc}", "danger")
    return redirect(url_for("connectors_v20"))


@app.route("/operations/jobs", methods=["GET", "POST"])
@module_required("operations")
def jobs_v20():
    if request.method == "POST":
        _require_v20_csrf()
        try:
            job_id = ops20.create_job(
                db,
                request.form.get("title", "Untitled operation"),
                request.form.get("agent_key", "health"),
                request.form.get("action", "analyze"),
                request.form.get("target", "Infrastructure"),
                request.form.get("risk", "medium"),
                current_user()["username"],
                ["Operator request", "Inventory context", "Approval policy", {"parameters": _safe_parameters(request.form.get("parameters_json", "[]"))}],
            )
            db.log_action(current_user()["username"], "v20_job_created", f"job#{job_id}")
            flash(f"Operation #{job_id} created. Approval policy was applied automatically.", "success")
        except Exception as exc:
            flash(f"Could not create operation: {exc}", "danger")
        return redirect(url_for("jobs_v20"))
    return render_template("jobs_v20.html", jobs=ops20.list_jobs(db), agents=ops20.AGENTS)


@app.route("/operations/jobs/<int:job_id>/<transition>", methods=["POST"])
@module_required("operations")
def job_transition_v20(job_id, transition):
    _require_v20_csrf()
    if transition not in {"approve", "cancel"}:
        abort(404)
    try:
        is_admin = current_user()["role"] == "admin"
        ops20.transition_job(db, job_id, transition, current_user()["username"], is_admin=is_admin)
        db.log_action(current_user()["username"], f"v20_job_{transition}", f"job#{job_id}")
        flash(f"Operation #{job_id} updated.", "success")
    except PermissionError as exc:
        flash(str(exc), "danger")
    except Exception as exc:
        flash(f"Operation could not be updated: {exc}", "warning")
    return redirect(url_for("jobs_v20"))


@app.route("/operations/digital-twin")
@module_required("operations")
def digital_twin_v20():
    return render_template("digital_twin_v20.html", snapshot=ops20.platform_snapshot(db))


def _parse_u_position(value):
    import re
    match = re.search(r"(\d+)", str(value or ""))
    return int(match.group(1)) if match else None

def _rack_asset_span(table, row):
    # Use the recorded physical height before model defaults.
    if "rack_units" in row.keys() and row["rack_units"]:
        height = _parse_u_position(row["rack_units"])
        if height and 1 <= height <= 60:
            return height
    model = str(row["model"] if "model" in row.keys() else "").lower()
    if table == "servers":
        if any(x in model for x in ("dl580", "dl560")): return 4
        if "dl380" in model: return 2
        return 2
    if table == "storage": return 2
    return 1

@app.route("/operations/digital-twin/3d")
@module_required("operations")
def datacenter_3d_v21():
    rack_rows = db.list_assets("racks")
    asset_tables = [t for t in ("servers", "storage", "san_switches", "network", "ups", "hpe_synergy_servers") if t in db.SCHEMAS]
    assets = []
    for table in asset_tables:
        spec = db.SCHEMAS[table]
        for row in db.list_assets(table):
            rack = str(row["rack"] if "rack" in row.keys() else "").strip()
            if not rack: continue
            label = db.asset_label(table, row)
            assets.append({"table":table,"id":row["id"],"rack":rack,"datacenter":str(row["datacenter"] if "datacenter" in row.keys() else ""),"room":str(row["room"] if "room" in row.keys() else ""),"u":_parse_u_position(row["u_position"] if "u_position" in row.keys() else ""),"span":_rack_asset_span(table,row),"label":label,"model":str(row["model"] if "model" in row.keys() else ""),"status":str(row["status"] if "status" in row.keys() else "Unknown"),"health":_asset_health(row),"icon":spec.get("icon","bi-box")})
    racks=[]; known=set(); placed=0; critical=0; free_u=0
    for rr in rack_rows:
        name=str(rr["rack_name"] or rr["rack_number"] or f"Rack {rr['id']}").strip(); number=str(rr["rack_number"] or "").strip()
        size=_parse_u_position(rr["rack_size_u"]) or 42; size=max(1,min(size,60))
        aliases={x.lower() for x in (name,number) if x}; known |= aliases
        matching=[a for a in assets if a["rack"].lower() in aliases and (not a["datacenter"] or not rr["datacenter"] or a["datacenter"]==rr["datacenter"])]
        starts={a["u"]:a for a in matching if a["u"] and 1<=a["u"]<=size}
        used=sum(min(a["span"],size-a["u"]+1) for a in matching if a["u"] and 1<=a["u"]<=size)
        placed += len(starts); critical += sum(a["health"]=="critical" for a in matching); free_u += max(0,size-used)
        racks.append({"name":name,"size":size,"datacenter":str(rr["datacenter"] or ""),"room":str(rr["room"] or ""),"power":str(rr["power"] or ""),"used_u":used,"units":[{"number":u,"asset":starts.get(u)} for u in range(1,size+1)],"asset_search":" ".join(a["label"]+" "+a["model"] for a in matching)})
    unplaced=[a for a in assets if a["rack"].lower() in known and not a["u"]]
    datacenters=sorted({r["datacenter"] for r in racks if r["datacenter"]}); rooms=sorted({r["room"] for r in racks if r["room"]})
    return render_template("datacenter_3d_v21.html",racks=racks,unplaced=unplaced,datacenters=datacenters,rooms=rooms,placed_count=placed,critical_count=critical,free_u=free_u)


def _v22_estimated_power(table, row):
    """Offline planning estimate only; never presented as live telemetry."""
    model = str(row["model"] if "model" in row.keys() else "").lower()
    if table in ("servers", "hpe_synergy_servers"):
        if "dl580" in model: return 1800
        if "dl560" in model: return 1400
        if "dl380" in model: return 900
        return 750
    if table == "storage": return 1200
    if table == "san_switches": return 350
    if table == "network": return 450
    return 300

@app.route("/design-studio")
@module_required("operations")
def design_studio_v22():
    rack_rows = db.list_assets("racks")
    asset_tables = [t for t in ("servers", "storage", "san_switches", "network", "ups", "hpe_synergy_servers") if t in db.SCHEMAS]
    assets=[]
    for table in asset_tables:
        spec=db.SCHEMAS[table]
        for row in db.list_assets(table):
            rack=str(row["rack"] if "rack" in row.keys() else "").strip()
            assets.append({
                "table":table,"id":row["id"],"label":db.asset_label(table,row),
                "model":str(row["model"] if "model" in row.keys() else ""),
                "rack":rack,"u":_parse_u_position(row["u_position"] if "u_position" in row.keys() else ""),
                "span":_rack_asset_span(table,row),"power_w":_v22_estimated_power(table,row),
                "icon":spec.get("icon","bi-box"),"health":_asset_health(row)
            })
    racks=[]
    for rr in rack_rows:
        name=str(rr["rack_name"] or rr["rack_number"] or f"Rack {rr['id']}").strip()
        number=str(rr["rack_number"] or "").strip(); aliases={x.lower() for x in (name,number) if x}
        size=max(1,min(_parse_u_position(rr["rack_size_u"]) or 42,60))
        matched=[a for a in assets if a["rack"].lower() in aliases]
        used=sum(min(a["span"],size-a["u"]+1) for a in matched if a["u"] and 1<=a["u"]<=size)
        power=sum(a["power_w"] for a in matched)
        racks.append({"id":rr["id"],"name":name,"number":number,"size":size,"used_u":used,"free_u":max(0,size-used),
                      "datacenter":str(rr["datacenter"] or ""),"room":str(rr["room"] or ""),"design_power":str(rr["power"] or ""),
                      "estimated_power_w":power,"asset_count":len(matched)})
    cables=[]
    if "cables" in db.SCHEMAS:
        for c in db.list_assets("cables"):
            cables.append({"id":c["id"],"type":str(c["cable_type"] or ""),"source":str(c["source_device"] or ""),
                           "source_port":str(c["source_port"] or ""),"destination":str(c["destination_device"] or ""),
                           "destination_port":str(c["destination_port"] or ""),"label":str(c["cable_label"] or ""),"status":str(c["status"] or "")})
    return render_template("design_studio_v22.html",racks=racks,assets=assets,cables=cables,
                           total_u=sum(r["size"] for r in racks),used_u=sum(r["used_u"] for r in racks),
                           total_power=sum(r["estimated_power_w"] for r in racks))

@app.route("/api/v20/control-plane")
@module_required("operations")
def api_control_plane_v20():
    payload = ops20.health_payload(db)
    payload["timestamp"] = datetime.now().isoformat()
    return jsonify(payload)

@app.route("/linux-health")
@module_required("linux_health")
def linux_health():
    from linux_health_service import diagnostic_options
    return render_template("linux_health.html", diagnostic_options=diagnostic_options())

@app.route("/linux-health/command-library")
@module_required("linux_health")
def linux_command_library():
    return render_template("linux_command_library.html")

@app.route("/raid-calculator", methods=["GET", "POST"])
@login_required
def raid_calculator_page():
    values = dict(level="5", disks="8", capacity="1.92", unit="TB", groups="2", spares="0")
    result, error = None, None
    if request.method == "POST":
        values = {key: request.form.get(key, default) for key, default in values.items()}
        try:
            result = raid_calculator.calculate(**values)
        except ValueError as exc:
            error = str(exc)
    return render_template("raid_calculator.html", values=values, result=result, error=error,
                           levels=raid_calculator.LEVELS)


@app.route("/hardware-hub")
@login_required
def hardware_hub():
    summary, _ = _status_summary()
    devices = db.list_monitoring_devices()
    connected = sum(1 for d in devices if str(d["status"] or "").lower() in
                    {"ok", "online", "healthy", "enabled"})
    coverage = search_service.status(_search_sources()) if _search_sources() else {}
    knowledge_count = coverage.get("documents") or 0
    return render_template("hardware_hub.html", modules=MODULES,
                           allowed_modules=ROLE_MODULES.get(current_user()["role"], set()),
                           summary=summary, monitored=len(devices), connected=connected,
                           knowledge_count=knowledge_count, hub_shortcuts=asset_workflows.shortcuts(module_allowed))

@app.route("/module-login/<module_key>", methods=["GET", "POST"])
@login_required
def module_login(module_key):
    if module_key not in MODULES or not module_allowed(module_key): abort(403)
    target = (url_for("warehouse_home") if module_key=="warehouse" else
              url_for("knowledge_home") if module_key=="knowledge" else
              url_for("dashboard") if module_key=="asset_manager" else
              url_for("equipment_profile") if module_key=="equipment_profile" else
              url_for("ai_assistant") if module_key=="ai_assistant" else
              url_for("monitoring") if module_key=="monitoring" else url_for("settings"))
    return redirect(target)

@app.route("/module-logout/<module_key>")
@login_required
def module_logout(module_key):
    return redirect(url_for("hardware_hub"))

@app.route("/equipment")
@module_required("equipment_profile")
def equipment_profile():
    db.ensure_equipment_fields()
    banks=db.list_equipment_banks()
    selected_id=request.args.get("bank", type=int)
    selected_bank=db.get_equipment_bank(selected_id) if selected_id else (banks[0] if banks else None)
    subs=db.list_equipment_subcategories(selected_bank["id"]) if selected_bank else []
    selected_sub_id=request.args.get("sub", type=int)
    selected_sub=db.get_equipment_subcategory(selected_sub_id) if selected_sub_id else (subs[0] if subs else None)
    files=db.list_equipment_files(selected_sub["id"]) if selected_sub else []
    records=db.list_equipment_records(selected_sub["id"]) if selected_sub else []
    edit_record=db.get_equipment_record(request.args.get("edit",type=int)) if request.args.get("edit",type=int) else None
    if edit_record and (not selected_sub or edit_record["subcategory_id"] != selected_sub["id"]): edit_record=None
    return render_template("equipment.html", banks=banks, selected_bank=selected_bank, subs=subs, selected_sub=selected_sub, files=files, records=records, edit_record=edit_record, equipment_schemas=db.SCHEMAS, equipment_fields=db.EQUIPMENT_RECORD_FIELDS, lookups={f[3]:db.get_lookup(f[3]) for spec in db.SCHEMAS.values() for f in spec["fields"] if f[3]})

@app.route("/equipment/bank", methods=["POST"])
@module_required("equipment_profile")
def equipment_bank_create():
    name=request.form.get("name","").strip()
    if not name: flash("Bank Name is required.","danger")
    else:
        try: db.create_equipment_bank(name); flash("Bank added successfully.","success")
        except Exception: flash("Bank already exists.","warning")
    return redirect(url_for("equipment_profile"))

@app.route("/equipment/bank/<int:bank_id>/delete", methods=["POST"])
@module_required("equipment_profile")
def equipment_bank_delete(bank_id):
    bank=db.get_equipment_bank(bank_id)
    if not bank:
        abort(404)
    stored_files=db.delete_equipment_bank(bank_id)
    for stored in stored_files:
        try:
            os.remove(os.path.join(EQUIPMENT_FILE_DIR, stored))
        except OSError:
            pass
    db.log_action(current_user()["username"], "equipment_bank_delete", bank["name"])
    flash(f'Bank "{bank["name"]}" and its subcategories/files were deleted.', "success")
    return redirect(url_for("equipment_profile"))

@app.route("/equipment/subcategory", methods=["POST"])
@module_required("equipment_profile")
def equipment_subcategory_create():
    bank_id=request.form.get("bank_id",type=int); name=request.form.get("name","").strip()
    if bank_id and name:
        try: db.create_equipment_subcategory(bank_id,name); flash("Subcategory added.","success")
        except Exception: flash("Subcategory already exists.","warning")
    return redirect(url_for("equipment_profile",bank=bank_id))

@app.route("/equipment/subcategory/<int:sub_id>/delete", methods=["POST"])
@module_required("equipment_profile")
def equipment_subcategory_delete(sub_id):
    sub=db.get_equipment_subcategory(sub_id)
    if not sub: abort(404)
    files=db.delete_equipment_subcategory(sub_id)
    for stored in files:
        target=os.path.realpath(os.path.join(EQUIPMENT_FILE_DIR,stored))
        if os.path.commonpath([os.path.realpath(EQUIPMENT_FILE_DIR),target]) == os.path.realpath(EQUIPMENT_FILE_DIR):
            try: os.remove(target)
            except FileNotFoundError: pass
            except OSError: app.logger.warning("Could not remove deleted equipment attachment")
    db.log_action(current_user()["username"],"equipment_subcategory_delete",sub["name"])
    flash("Site / subcategory and its equipment profiles and documents deleted.","success")
    return redirect(url_for("equipment_profile",bank=sub["bank_id"]))

@app.route("/equipment/record", methods=["POST"])
@module_required("equipment_profile")
def equipment_record_save():
    sub_id=request.form.get("subcategory_id",type=int); sub=db.get_equipment_subcategory(sub_id) if sub_id else None
    if not sub: abort(404)
    rid=request.form.get("record_id",type=int)
    try:
        db.save_equipment_record(sub_id,request.form,rid)
        db.log_action(current_user()["username"],"equipment_record_save",request.form.get("name",""))
        flash("Equipment profile saved.","success")
    except ValueError as exc: flash(str(exc),"danger")
    return redirect(url_for("equipment_profile",bank=sub["bank_id"],sub=sub_id))

@app.route("/equipment/record/<int:record_id>/delete", methods=["POST"])
@module_required("equipment_profile")
def equipment_record_delete(record_id):
    row=db.get_equipment_record(record_id)
    if not row: abort(404)
    sub=db.get_equipment_subcategory(row["subcategory_id"])
    db.delete_equipment_record(record_id)
    db.log_action(current_user()["username"],"equipment_record_delete",row["name"])
    return redirect(url_for("equipment_profile",bank=sub["bank_id"],sub=sub["id"]))

@app.route("/equipment/records/<int:sub_id>.csv")
@module_required("equipment_profile")
def equipment_records_export(sub_id):
    db.ensure_equipment_fields()
    sub=db.get_equipment_subcategory(sub_id)
    if not sub: abort(404)
    output=io.StringIO(); writer=csv.DictWriter(output,fieldnames=list(db.EQUIPMENT_RECORD_FIELDS)); writer.writeheader()
    for row in db.list_equipment_records(sub_id): writer.writerow({k:row[k] or "" for k in db.EQUIPMENT_RECORD_FIELDS})
    return send_file(io.BytesIO(output.getvalue().encode("utf-8-sig")),mimetype="text/csv; charset=utf-8",as_attachment=True,download_name=f"equipment-{secure_filename(sub['name']) or sub_id}.csv")

@app.route("/equipment/records/import", methods=["POST"])
@module_required("equipment_profile")
def equipment_records_import():
    db.ensure_equipment_fields()
    sub_id=request.form.get("subcategory_id",type=int); sub=db.get_equipment_subcategory(sub_id) if sub_id else None; f=request.files.get("file")
    if not sub or not f or not f.filename: abort(400)
    try:
        ext=os.path.splitext(f.filename)[1].lower()
        if ext==".csv":
            text=f.stream.read(8*1024*1024).decode("utf-8-sig"); rows=list(csv.DictReader(io.StringIO(text)))
        elif ext in (".xlsx",".xlsm") and EXCEL_AVAILABLE:
            from openpyxl import load_workbook
            wb=load_workbook(f,read_only=True,data_only=True); ws=wb.active; values=ws.iter_rows(values_only=True); headers=[str(x or "").strip().lower() for x in next(values)]
            rows=[dict(zip(headers,row)) for row in values]; wb.close()
        else: raise ValueError("Choose a CSV or XLSX file.")
        aliases={"serial":"serial_number","serial number":"serial_number","asset tag":"asset_tag","brand":"manufacturer","description":"specifications"}
        count=0
        for raw in rows:
            normalized={aliases.get(str(k or "").strip().lower(),str(k or "").strip().lower().replace(" ","_")):v for k,v in raw.items()}
            vals={k:str(normalized.get(k.lower().replace(" ","_"),"") or "") for k in db.EQUIPMENT_RECORD_FIELDS}
            if vals["name"].strip(): db.save_equipment_record(sub_id,vals); count+=1
        flash(f"Imported {count} equipment profile(s).","success")
    except Exception as exc:
        flash(f"Import failed: {exc}","danger")
    return redirect(url_for("equipment_profile",bank=sub["bank_id"],sub=sub_id))

EQUIPMENT_FILE_EXTENSIONS={".xlsx":"Excel", ".xls":"Excel", ".pdf":"PDF", ".docx":"Word", ".doc":"Word", ".csv":"CSV", ".txt":"Text", ".png":"Image", ".jpg":"Image", ".jpeg":"Image", ".zip":"Archive"}
EQUIPMENT_FILE_DIR=os.path.join(paths.data_dir(),"equipment_files")
os.makedirs(EQUIPMENT_FILE_DIR,exist_ok=True)

@app.route("/equipment/file", methods=["POST"])
@module_required("equipment_profile")
def equipment_file_upload():
    sub_id=request.form.get("subcategory_id",type=int); f=request.files.get("file")
    sub=db.get_equipment_subcategory(sub_id) if sub_id else None
    if not sub or not f or not f.filename:
        flash("Select a subcategory and file.","danger")
        return redirect(url_for("equipment_profile"))
    ext=os.path.splitext(f.filename)[1].lower()
    if ext not in EQUIPMENT_FILE_EXTENSIONS:
        flash("Only Excel, PDF and Word files are accepted.","danger")
        return redirect(url_for("equipment_profile",sub=sub_id))
    original=f.filename; safe=secure_filename(original) or "document"+ext
    stored=uuid.uuid4().hex+"_"+safe; path=os.path.join(EQUIPMENT_FILE_DIR,stored)
    try:
        _save_upload_limited(f, path, DOCUMENT_MAX_BYTES)
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("equipment_profile", bank=sub["bank_id"], sub=sub_id))
    description=request.form.get("description", "").strip()
    if not description:
        try: os.remove(path)
        except OSError: pass
        flash("Description is required for every upload.","danger")
        return redirect(url_for("equipment_profile",bank=sub["bank_id"],sub=sub_id))
    db.add_equipment_file(sub_id,original,stored,EQUIPMENT_FILE_EXTENSIONS[ext],os.path.getsize(path),current_user()["username"],description)
    db.log_action(current_user()["username"],"equipment_file_upload",original)
    flash("File uploaded successfully.","success")
    return redirect(url_for("equipment_profile",bank=sub["bank_id"],sub=sub_id))

@app.route("/equipment/file/<int:file_id>")
@module_required("equipment_profile")
def equipment_file_view(file_id):
    row=db.get_equipment_file(file_id)
    if not row: abort(404)
    path=os.path.join(EQUIPMENT_FILE_DIR,row["stored_name"])
    if not os.path.exists(path): abort(404)
    base_url = url_for('equipment_file_view', file_id=file_id)
    if request.args.get('raw') == '1' or request.args.get('download') == '1':
        return _inline_document(send_file(path, as_attachment=request.args.get('download') == '1', download_name=row['original_name']))
    return _document_preview(row, path, base_url+'?raw=1', base_url+'?download=1', url_for('equipment_profile'))

def _inline_document(response):
    # Allow authenticated previews only within this application's own origin.
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['Content-Security-Policy'] = "default-src 'self'; frame-ancestors 'self'; object-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self' 'unsafe-inline'"
    return response


def _document_preview(row, path, raw_url, download_url, back_url):
    from file_preview import workbook_page, word_content
    ext = os.path.splitext(row['original_name'])[1].lower()
    kind = 'unsupported'; preview = None; blocks = []; error = None; text_content = ''
    try:
        if ext in ('.xlsx', '.xls', '.csv'):
            kind = 'spreadsheet'
            preview = workbook_page(path, request.args.get('sheet', 0, type=int), request.args.get('page', 1, type=int))
        elif ext == '.docx':
            kind = 'word'; blocks = word_content(path)
        elif ext == '.pdf': kind = 'pdf'
        elif ext in ('.png', '.jpg', '.jpeg'): kind = 'image'
        elif ext == '.txt':
            kind = 'text'
            with open(path, encoding='utf-8', errors='replace') as handle: text_content = handle.read(250000)
    except Exception:
        error = 'Could not preview this file. Download the original to inspect it.'
    return render_template('file_preview.html', file=row, kind=kind, preview=preview,
        blocks=blocks, preview_error=error, text_content=text_content, raw_url=raw_url,
        download_url=download_url, back_url=back_url)


BANK_CONNECTION_DIR=os.path.join(paths.data_dir(),"bank_connection_info")
os.makedirs(BANK_CONNECTION_DIR,exist_ok=True)

@app.route("/equipment/bank-connection", methods=["GET", "POST"])
@module_required("equipment_profile")
def bank_connection_info():
    if request.method == "POST":
        f=request.files.get("file"); description=request.form.get("description","").strip()
        if not f or not f.filename: flash("Please choose a file to upload.","danger")
        elif not description: flash("Description is required for every upload.","danger")
        else:
            ext=os.path.splitext(f.filename)[1].lower()
            if ext not in EQUIPMENT_FILE_EXTENSIONS: flash("Unsupported file type.","danger")
            else:
                original=f.filename; safe=secure_filename(original) or ("document"+ext)
                stored=uuid.uuid4().hex+"_"+safe; path=os.path.join(BANK_CONNECTION_DIR,stored)
                try:
                    _save_upload_limited(f, path, DOCUMENT_MAX_BYTES)
                except ValueError as exc:
                    flash(str(exc), "danger")
                    return redirect(url_for("bank_connection_info"))
                db.add_bank_connection_file(original,stored,EQUIPMENT_FILE_EXTENSIONS[ext],os.path.getsize(path),current_user()["username"],description)
                db.log_action(current_user()["username"],"bank_connection_file_upload",original); flash("Bank Connection Info file uploaded successfully.","success")
        return redirect(url_for("bank_connection_info"))
    return render_template("bank_connection.html",files=db.list_bank_connection_files())

@app.route("/equipment/bank-connection/file/<int:file_id>")
@module_required("equipment_profile")
def bank_connection_file_view(file_id):
    row=db.get_bank_connection_file(file_id)
    if not row: abort(404)
    path=os.path.join(BANK_CONNECTION_DIR,row["stored_name"])
    if not os.path.exists(path): abort(404)
    base_url = url_for('bank_connection_file_view', file_id=file_id)
    if request.args.get('raw') == '1' or request.args.get('download') == '1':
        return _inline_document(send_file(path, as_attachment=request.args.get('download') == '1', download_name=row['original_name']))
    return _document_preview(row, path, base_url+'?raw=1', base_url+'?download=1', url_for('bank_connection_info'))

@app.route("/settings")
@module_required("settings")
def settings():
    return render_template("settings.html", ai_settings=db.get_ai_settings())

@app.route("/settings/ai", methods=["POST"])
@role_required("admin")
def ai_settings_update():
    if not secrets.compare_digest(request.form.get("csrf", ""), session.get("search_csrf", "missing")):
        abort(403)
    provider = request.form.get("provider", "local").lower()
    answer_mode = request.form.get("answer_mode", "grounded").lower()
    ollama_url = request.form.get("ollama_url", "").strip().rstrip("/")
    ollama_model = request.form.get("ollama_model", "").strip()
    try:
        if provider not in ("local", "ollama"):
            raise ValueError("Unknown AI provider.")
        if answer_mode not in ("grounded", "hybrid"):
            raise ValueError("Unknown answer mode.")
        parsed = urlparse(ollama_url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Enter a valid Ollama HTTP(S) URL without embedded credentials.")
        if not ollama_model or len(ollama_model) > 120:
            raise ValueError("Enter a valid model name.")
        temperature = float(request.form.get("temperature", "0.1"))
        max_tokens = int(request.form.get("max_tokens", "1200"))
        timeout_seconds = int(request.form.get("timeout_seconds", "90"))
        if not 0 <= temperature <= 1:
            raise ValueError("Temperature must be between 0 and 1.")
        if not 128 <= max_tokens <= 8192:
            raise ValueError("Maximum output tokens must be between 128 and 8192.")
        if not 5 <= timeout_seconds <= 600:
            raise ValueError("Timeout must be between 5 and 600 seconds.")
        db.update_ai_settings(provider, ollama_url, ollama_model, answer_mode,
                              temperature, max_tokens, timeout_seconds,
                              current_user()["username"])
        db.log_action(current_user()["username"], "ai_settings_update",
                      f"provider={provider}; model={ollama_model}; mode={answer_mode}")
        flash("AI settings saved.", "success")
    except (ValueError, TypeError) as exc:
        flash(str(exc), "danger")
    return redirect(url_for("settings") + "#ai-settings")

@app.route("/module-users/<module_key>", methods=["GET", "POST"])
@role_required("admin")
def module_users(module_key):
    if module_key not in MODULES: abort(404)
    if request.method == "POST":
        action=request.form.get("action"); username=request.form.get("username","").strip(); password=request.form.get("password","")
        try:
            if action=="create":
                if len(username)<2: raise ValueError("Username must contain at least 2 characters.")
                _validate_new_password(password)
                db.create_module_user(module_key,username,password)
            elif action=="update":
                if password: _validate_new_password(password)
                db.update_module_user(int(request.form["user_id"]),module_key,username,password or None,1 if request.form.get("active") else 0)
            elif action=="delete":
                if len(db.list_module_users(module_key))<=1: raise ValueError("At least one user must remain.")
                db.delete_module_user(int(request.form["user_id"]),module_key)
            flash("User operation completed successfully.","success")
        except Exception as e: flash(str(e),"danger")
        return redirect(url_for("module_users",module_key=module_key))
    return render_template("module_users.html",module=MODULES[module_key],module_key=module_key,users=db.list_module_users(module_key),current=session.get("module_auth_users",{}).get(module_key,""))

@app.route("/module-users/<module_key>/change-password", methods=["POST"])
@role_required("admin")
def module_change_password(module_key):
    current=session.get("module_auth_users",{}).get(module_key); user=db.get_module_user(module_key,current) if current else None; pw=request.form.get("new_password","")
    if not user or pw!=request.form.get("confirm_password",""):
        flash("Password confirmation does not match.","danger")
    else:
        try:
            _validate_new_password(pw)
        except ValueError as exc:
            flash(str(exc),"danger")
            return redirect(url_for("module_users",module_key=module_key))
        db.update_module_user(user["id"],module_key,user["username"],pw,user["active"]); flash("Password changed successfully.","success")
    return redirect(url_for("module_users",module_key=module_key))

@app.route("/knowledge")
@module_required("knowledge")
def knowledge_home():
    return render_template("knowledge.html",
                           categories=KNOWLEDGE_CATEGORIES,
                           active_category=request.args.get("category", "server"),
                           files=db.list_knowledge_files(request.args.get("category", "server"))
                           if request.args.get("category", "server") in KNOWLEDGE_CATEGORIES else [])


@app.route("/knowledge/upload", methods=["POST"])
@module_required("knowledge")
def knowledge_upload():
    batch_request = request.headers.get("X-Knowledge-Batch") == "1"
    category = request.form.get("category", "")
    description = request.form.get("description", "").strip()
    uploads = [f for f in request.files.getlist("file") if f and f.filename]
    if category not in KNOWLEDGE_CATEGORIES:
        if batch_request:
            return jsonify(error="Invalid Knowledge category."), 400
        flash("Invalid Knowledge category.", "danger")
        return redirect(url_for("knowledge_home"))
    if not uploads or not description:
        if batch_request:
            return jsonify(error="Select files and enter a description."), 400
        flash("Select files and enter a description.", "warning")
        return redirect(url_for("knowledge_home", category=category))
    saved, rejected, outcomes = 0, 0, []
    for uploaded in uploads:
        ext = os.path.splitext(uploaded.filename)[1].lower()
        if ext not in KNOWLEDGE_EXTENSIONS:
            rejected += 1
            outcomes.append({"name": uploaded.filename, "status": "skipped", "message": "Unsupported file type."})
            continue
        stored = f"{uuid.uuid4().hex}{ext}"
        dest = os.path.join(KNOWLEDGE_DIR, stored)
        media = "application/pdf" if ext == ".pdf" else "application/vnd.openxmlformats-officedocument.wordprocessingml.document" if ext == ".docx" else "application/msword" if ext == ".doc" else "application/zip"
        try:
            _save_upload_limited(uploaded, dest, DOCUMENT_MAX_BYTES)
            db.add_knowledge_file(category, secure_filename(uploaded.filename) or ("document" + ext),
                                  stored, description, os.path.getsize(dest), media, current_user()["username"])
        except ValueError:
            rejected += 1
            outcomes.append({"name": uploaded.filename, "status": "skipped", "message": "File exceeds the upload limit or is invalid."})
            if os.path.exists(dest):
                try: os.remove(dest)
                except OSError: pass
            continue
        except Exception:
            if os.path.exists(dest): os.remove(dest)
            raise
        saved += 1
        outcomes.append({"name": uploaded.filename, "status": "saved"})
        db.log_action(current_user()["username"], "knowledge_upload", f"{category}: {uploaded.filename}")
    if batch_request:
        return jsonify(saved=saved, rejected=rejected, results=outcomes)
    flash(f"{saved} document(s) uploaded; {rejected} unsupported file(s) skipped.", "success" if saved else "warning")
    return redirect(url_for("knowledge_home", category=category))


@app.route("/knowledge/file/<int:file_id>/delete", methods=["POST"])
@module_required("knowledge")
def knowledge_delete(file_id):
    row = db.delete_knowledge_file(file_id)
    if not row: abort(404)
    path = os.path.join(KNOWLEDGE_DIR, row["stored_name"])
    if os.path.isfile(path): os.remove(path)
    db.log_action(current_user()["username"], "knowledge_delete", f"{row['category']}: {row['original_name']} (file #{file_id})")
    flash("Document deleted.", "success")
    return redirect(url_for("knowledge_home", category=row["category"]))


@app.route("/knowledge/bulk-delete", methods=["POST"])
@module_required("knowledge")
def knowledge_bulk_delete():
    category = request.form.get("category", "")
    if category not in KNOWLEDGE_CATEGORIES:
        abort(400)
    ids = []
    for raw in request.form.getlist("file_ids")[:500]:
        try:
            value = int(raw)
            if value > 0 and value not in ids:
                ids.append(value)
        except (TypeError, ValueError):
            continue
    removed = 0
    for file_id in ids:
        row = db.get_knowledge_file(file_id)
        # The selected list is category-scoped; reject cross-category IDs.
        if not row or row["category"] != category:
            continue
        path = os.path.join(KNOWLEDGE_DIR, row["stored_name"])
        deleted = db.delete_knowledge_file(file_id)
        if deleted:
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except OSError:
                pass
            db.log_action(current_user()["username"], "knowledge_bulk_delete", f"{category}: {row['original_name']} (file #{file_id})")
            removed += 1
    flash(f"{removed} document(s) deleted.", "success" if removed else "warning")
    return redirect(url_for("knowledge_home", category=category))


@app.route("/knowledge/file/<int:file_id>")
@module_required("knowledge")
def knowledge_file(file_id):
    row = db.get_knowledge_file(file_id)
    if not row:
        abort(404)
    path = os.path.join(KNOWLEDGE_DIR, row["stored_name"])
    if not os.path.isfile(path):
        abort(404)
    raw_url = url_for('knowledge_raw', file_id=file_id)
    return _document_preview(row, path, raw_url, raw_url+'?download=1', url_for('knowledge_home', category=row['category']))


@app.route("/knowledge/raw/<int:file_id>")
@module_required("knowledge")
def knowledge_raw(file_id):
    row = db.get_knowledge_file(file_id)
    if not row:
        abort(404)
    path = os.path.join(KNOWLEDGE_DIR, row["stored_name"])
    if not os.path.isfile(path):
        abort(404)
    return _inline_document(send_file(path, mimetype=row["media_type"], as_attachment=request.args.get('download') == '1',
                     download_name=row["original_name"]))


@app.route("/knowledge/docx/<int:file_id>")
@module_required("knowledge")
def knowledge_docx(file_id):
    row = db.get_knowledge_file(file_id)
    if not row or not row["original_name"].lower().endswith(".docx"):
        abort(404)
    path = os.path.join(KNOWLEDGE_DIR, row["stored_name"])
    try:
        from docx import Document
        doc = Document(path)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    except Exception as exc:
        flash(f"Could not render Word document: {exc}", "danger")
        return redirect(url_for("knowledge_file", file_id=file_id))
    return _inline_document(render_template("docx_viewer.html", file=row, paragraphs=paragraphs))


@app.route("/")
def root():
    return redirect(url_for("hardware_hub"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

def _human_size(num_bytes):
    try:
        num_bytes = float(num_bytes or 0)
    except (TypeError, ValueError):
        return "-"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num_bytes < 1024 or unit == "TB":
            return f"{num_bytes:.1f} {unit}" if unit != "B" else f"{int(num_bytes)} {unit}"
        num_bytes /= 1024


app.jinja_env.filters["filesize"] = _human_size



def _status_summary():
    summary={"total":0,"healthy":0,"warning":0,"critical":0,"unknown":0}
    items=[]
    for table,spec in db.SCHEMAS.items():
        for row in db.list_assets(table):
            d=dict(row); summary["total"]+=1
            raw=str(d.get("status") or "").lower()
            if any(x in raw for x in ("fault","critical","down","failed")): bucket="critical"
            elif any(x in raw for x in ("warn","maintenance","standby")): bucket="warning"
            elif raw.strip() in {"active", "healthy", "resolved", "online", "operational", "ok"}: bucket="healthy"
            else: bucket="unknown"
            summary[bucket]+=1
            items.append({"table":table,"type":spec["label"],"id":d.get("id"),"name":db.asset_label(table,row),"status":d.get("status") or "Unknown","ip":d.get("management_ip") or d.get("ilo_ip") or "-","bucket":bucket})
    return summary,items

def _probe_monitoring(device):
    return probe_monitoring(device, _decrypt_secret(device["password_enc"]))

def _monitoring_agent_report(device, result):
    status=str(result.get("status") or "Unknown")
    low=status.lower()
    severity="Critical" if any(x in low for x in ("critical","failed","fault","down")) else ("Warning" if any(x in low for x in ("warning","degraded","minor")) else "Healthy")
    findings=[]
    if result.get("firmware"): findings.append(f"Reported firmware/BIOS: {result['firmware']}")
    if result.get("model"): findings.append(f"Detected model: {result['model']}")
    if result.get("serial_number"): findings.append(f"Serial/service identifier: {result['serial_number']}")
    findings.append(f"Live endpoint state: {status}")
    action=("Immediate administrator review is recommended; inspect hardware event logs and component health." if severity=="Critical" else "Review warnings and firmware baselines before maintenance." if severity=="Warning" else "No live health fault was reported by this endpoint. Continue normal monitoring.")
    return {"severity":severity,"findings":findings,"action":action,"details":result.get("details") or {}}

@app.route("/monitoring", methods=["GET","POST"])
@module_required("monitoring")
def monitoring():
    if request.method=="POST":
        name=request.form.get("name","").strip(); ip=request.form.get("management_ip","").strip(); user=request.form.get("username","").strip(); password=request.form.get("password","")
        try:
            ipaddress.ip_address(ip)
            if not all((name,ip,user,password)): raise ValueError("All fields are required.")
            did=db.create_monitoring_device(name,request.form.get("device_type","HPE iLO (Redfish)"),ip,user,_encrypt_secret(password),bool(request.form.get("verify_ssl")),current_user()["username"])
            flash("Monitoring target added. Use Test / Refresh for a live connector query.","success")
        except Exception as exc: flash("Could not add device: "+str(exc),"danger")
        return redirect(url_for("monitoring"))
    summary,items=_status_summary(); devices=db.list_monitoring_devices()
    return render_template("monitoring.html",summary=summary,items=items[:250],devices=devices,connector_names=list(MONITORING_CONNECTORS.keys()))

@app.route("/monitoring/<int:device_id>/probe",methods=["POST"])
@module_required("monitoring")
def monitoring_probe(device_id):
    d=db.get_monitoring_device(device_id)
    if not d: abort(404)
    try:
        result=_probe_monitoring(d); persist={k:v for k,v in result.items() if k != "details"}; db.update_monitoring_device_status(device_id,**persist); flash(f'{d["name"]}: live connection successful.',"success")
    except Exception as exc:
        db.update_monitoring_device_status(device_id,status="Connection Error",last_error=str(exc)[:500],last_seen=datetime.now().isoformat()); flash(f'{d["name"]}: connection failed — {exc}',"warning")
    return redirect(url_for("monitoring"))

@app.route("/monitoring/<int:device_id>/agent",methods=["POST"])
@module_required("monitoring")
def monitoring_agent(device_id):
    d=db.get_monitoring_device(device_id)
    if not d: abort(404)
    try:
        result=_probe_monitoring(d)
        persist={k:v for k,v in result.items() if k != "details"}
        db.update_monitoring_device_status(device_id,**persist)
        report=_monitoring_agent_report(d,result)
        return render_template("monitoring_agent.html",device=d,result=result,report=report)
    except Exception as exc:
        db.update_monitoring_device_status(device_id,status="Connection Error",last_error=str(exc)[:500],last_seen=datetime.now().isoformat())
        return render_template("monitoring_agent.html",device=d,result=None,report=None,error=str(exc)), 502

@app.route("/monitoring/<int:device_id>/delete",methods=["POST"])
@module_required("monitoring")
def monitoring_delete(device_id):
    db.delete_monitoring_device(device_id); flash("Monitoring target removed.","success"); return redirect(url_for("monitoring"))

def _search_sources():
    return [source for source, module in search_service.SOURCE_MODULES.items() if module_allowed(module)]

def _file_search(q):
    return search_service.files(q, _search_sources())

def _assistant_result(q, conversation_id=None, mode="auto"):
    started = time.monotonic()
    username = current_user()["username"]
    if conversation_id:
        conversation = db.get_ai_conversation(conversation_id, username)
        if not conversation:
            raise ValueError("Conversation not found")
    else:
        conversation_id = db.create_ai_conversation(username, q)
    history = [dict(row) for row in db.list_ai_messages(conversation_id, username)]
    raid_turn = raid_calculator.dialog(q, db.get_ai_raid_state(conversation_id, username))
    if raid_turn is not None:
        answer, next_state, calculation = raid_turn
        result = raid_calculator.assistant_payload(answer, next_state, calculation)
        db.add_ai_exchange(conversation_id, username, q, result["answer"], result["provider"], raid_state=next_state)
    elif module_allowed("asset_manager") and (inventory_answer := __import__('asset_intelligence').assistant_answer(q)):
        result = raid_calculator.assistant_payload(inventory_answer, None, None)
        result.pop('raid', None)
        result['provider'] = 'Recorded inventory analysis'
        db.add_ai_exchange(conversation_id, username, q, result['answer'], result['provider'])
    else:
        config = db.get_ai_settings()
        result = InfrastructureAgent(
            search_service.assets if module_allowed("asset_manager") else lambda q: [],
            _file_search, config=config,
            port_search=__import__("port_map").answer_query if module_allowed("asset_manager") else None
        ).run(q, history, mode=mode)
        db.add_ai_exchange(conversation_id, username, q, result["answer"], result["provider"])
    result["conversation_id"] = conversation_id
    result["history"] = [dict(row) for row in db.list_ai_messages(conversation_id, username)]
    result["coverage"] = search_service.status(_search_sources())
    db.log_action(username, "ai_query", json.dumps({"provider": result["provider"],
        "assets": len(result["assets"]), "passages": len(result["files"]),
        "duration_ms": round((time.monotonic() - started) * 1000),
        "fallback": bool(result.get("warning"))}))
    return result

def _admit_ai_request(username):
    """Atomic sliding-window limit shared by all WSGI workers; never stores prompts."""
    conn = db.get_conn()
    now = time.time()
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("DELETE FROM ai_request_limits WHERE requested_at < ?", (now - 60,))
        count = conn.execute("SELECT COUNT(*) FROM ai_request_limits WHERE username=?", (username,)).fetchone()[0]
        if count >= app.config.get("AI_REQUESTS_PER_MINUTE", 20):
            conn.rollback()
            return False
        conn.execute("INSERT INTO ai_request_limits VALUES (?, ?)", (username, now))
        conn.commit()
        return True
    finally:
        conn.close()

@app.route("/diagnostics")
@role_required("admin")
def diagnostics():
    return render_template("diagnostics.html", ai_config=db.get_ai_settings())

@app.route("/api/diagnostics")
@role_required("admin")
def diagnostics_data():
    conn = db.get_conn()
    try:
        database_ok = conn.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    finally:
        conn.close()
    config = db.get_ai_settings()
    model = ollama_status(config) if config["provider"] == "ollama" else {"disabled": True, "online": False}
    return jsonify(version=APP_VERSION, database_ok=database_ok,
        index=search_service.status(_search_sources()), model=model,
        provider=config["provider"], answer_mode=config["answer_mode"],
        request_limit=app.config.get("AI_REQUESTS_PER_MINUTE", 20),
        device_actions=False, transport_secure=request.is_secure)


def _runtime_snapshot():
    """Return admin-safe process and storage telemetry without secrets."""
    db_path = os.path.join(BASE_DIR, "instance", "dcam.db")
    disk = shutil.disk_usage(BASE_DIR)
    return {
        "version": APP_VERSION,
        "service": "Farbod AI-Hub",
        "pid": os.getpid(),
        "uptime_seconds": int(time.time() - STARTED_AT),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "deployment": "Docker" if os.path.exists("/.dockerenv") else "Native",
        "container_hostname": os.environ.get("HOSTNAME", "") if os.path.exists("/.dockerenv") else "",
        "host": HOST,
        "port": PORT,
        "https_direct": USE_SSL,
        "trusted_proxy": TRUST_PROXY,
        "data_directory": BASE_DIR,
        "logs_directory": paths.logs_dir(),
        "backup_directory": paths.backup_dir(),
        "database_bytes": os.path.getsize(db_path) if os.path.exists(db_path) else 0,
        "disk_free_bytes": disk.free,
        "disk_total_bytes": disk.total,
        "ollama_provider": db.get_ai_settings()["provider"],
    }


@app.route("/runtime")
@role_required("admin")
def runtime_status_page():
    return render_template("runtime.html")


@app.route("/api/runtime-status")
@role_required("admin")
def runtime_status_api():
    return jsonify(_runtime_snapshot())


@app.route("/runtime/logs/<kind>")
@role_required("admin")
def runtime_log_download(kind):
    allowed = {
        "service": os.path.join(paths.logs_dir(), "service.log"),
        "error": os.path.join(paths.logs_dir(), "service-error.log"),
        "application": os.path.join(paths.logs_dir(), "server_error.log"),
        "backup": os.path.join(paths.logs_dir(), "backup.log"),
    }
    path = allowed.get(kind)
    if not path or not os.path.isfile(path):
        abort(404)
    db.log_action(current_user()["username"], "runtime_log_download", kind)
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="text/plain")


def _backup_archive_path(filename):
    name = os.path.basename(str(filename or ""))
    if name != filename or not name.endswith(".zip") or not name.startswith("FarbodAIHub_Backup_"):
        abort(404)
    settings = backup_manager.load_settings()
    root = os.path.realpath(settings["directory"])
    candidate = os.path.realpath(os.path.join(root, name))
    if os.path.dirname(candidate) != root or not os.path.isfile(candidate):
        abort(404)
    return candidate


@app.route("/backups")
@role_required("admin")
def backups_page():
    settings = backup_manager.load_settings()
    os.makedirs(settings["directory"], exist_ok=True)
    backups = []
    for candidate in sorted(__import__("glob").glob(os.path.join(settings["directory"], "FarbodAIHub_Backup_*.zip")), reverse=True):
        if os.path.isfile(candidate):
            stat = os.stat(candidate)
            backups.append({"name": os.path.basename(candidate), "size": stat.st_size,
                            "modified": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="minutes")})
    return render_template("backups.html", settings=settings, backups=backups,
                           backup_status=backup_manager.load_status())


@app.route("/backups/settings", methods=["POST"])
@role_required("admin")
def backup_settings_update():
    _require_v20_csrf()
    schedule = request.form.get("schedule", "daily")
    if schedule not in {"manual", "daily", "weekly"}:
        abort(400)
    try:
        retention = int(request.form.get("retention", "14"))
        weekday = int(request.form.get("weekday", "6"))
    except ValueError:
        abort(400)
    if not 1 <= retention <= 365 or not 0 <= weekday <= 6:
        abort(400)
    time_value = request.form.get("time", "02:00")
    try:
        datetime.strptime(time_value, "%H:%M")
    except ValueError:
        abort(400)
    directory_input = request.form.get("directory", "").strip()
    if not directory_input or len(directory_input) > 512:
        abort(400)
    directory = os.path.abspath(os.path.expandvars(os.path.expanduser(directory_input)))
    try:
        os.makedirs(directory, exist_ok=True)
        probe = os.path.join(directory, ".fhw-write-check")
        with open(probe, "w", encoding="utf-8") as stream:
            stream.write("ok")
        os.unlink(probe)
        settings = backup_manager.save_settings({
            "enabled": request.form.get("enabled") == "on", "schedule": schedule,
            "time": time_value, "weekday": weekday, "retention": retention,
            "include_iso": request.form.get("include_iso") == "on", "directory": directory,
        })
    except (OSError, ValueError) as exc:
        flash(f"Backup settings were not saved: {exc}", "danger")
        return redirect(url_for("backups_page"))
    db.log_action(current_user()["username"], "backup_settings_update",
                  json.dumps({"schedule": settings["schedule"], "retention": settings["retention"],
                              "include_iso": settings["include_iso"]}))
    flash("Backup settings saved.", "success")
    return redirect(url_for("backups_page"))


@app.route("/backups/run", methods=["POST"])
@role_required("admin")
def backup_run_now():
    _require_v20_csrf()
    settings = backup_manager.load_settings()
    env = os.environ.copy()
    env.update({"FHW_BACKUP_DIR": settings["directory"],
                "FHW_BACKUP_RETENTION": str(settings["retention"]),
                "FHW_BACKUP_INCLUDE_ISO": "1" if settings["include_iso"] else "0"})
    try:
        import subprocess
        result = subprocess.run([sys.executable, os.path.join(RESOURCE_DIR, "scripts", "backup_data.py")],
                                cwd=RESOURCE_DIR, env=env, capture_output=True, text=True, timeout=24 * 3600)
        ok = result.returncode == 0
        message = (result.stdout or result.stderr).strip()[-2000:]
        prior = backup_manager.load_status()
        backup_manager.save_status({**prior, "result": "success" if ok else "error", "message": message,
                                    "last_attempt_at": datetime.now().astimezone().isoformat(),
                                    "last_success_at": datetime.now().astimezone().isoformat() if ok else prior.get("last_success_at")})
        db.log_action(current_user()["username"], "backup_created" if ok else "backup_failed", message[:500])
        flash("Backup created and verified." if ok else f"Backup failed: {message}", "success" if ok else "danger")
    except Exception as exc:
        prior = backup_manager.load_status()
        backup_manager.save_status({**prior, "result": "error", "message": str(exc)[:2000],
                                    "last_attempt_at": datetime.now().astimezone().isoformat()})
        flash(f"Backup failed: {exc}", "danger")
    return redirect(url_for("backups_page"))


@app.route("/backups/download/<filename>")
@role_required("admin")
def backup_download(filename):
    path = _backup_archive_path(filename)
    db.log_action(current_user()["username"], "backup_downloaded", os.path.basename(path))
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/zip")


@app.route("/backups/prepare-restore/<filename>", methods=["POST"])
@role_required("admin")
def backup_prepare_restore(filename):
    _require_v20_csrf()
    path = _backup_archive_path(filename)
    try:
        with zipfile.ZipFile(path, "r") as archive:
            bad_member = archive.testzip()
            names = archive.namelist()
            if bad_member or "backup-manifest.json" not in names or "instance/dcam.db" not in names:
                raise ValueError("This archive is incomplete or failed its integrity check.")
            manifest = json.loads(archive.read("backup-manifest.json"))
            allowed = ("instance/isos/", "knowledge/", "equipment_files/", "bank_connection_info/",
                       "subobject_files/", "profile_images/")
            for info in archive.infolist():
                name = info.filename
                exact = name in {"backup-manifest.json", "instance/dcam.db", "instance/secret.key"}
                if name.startswith("/") or ".." in name.split("/") or not (exact or name.startswith(allowed)):
                    raise ValueError("The archive contains an unexpected path.")
                if info.file_size > 8 * 1024 * 1024 * 1024:
                    raise ValueError("The archive contains a file larger than the 8 GB restore limit.")
        db.log_action(current_user()["username"], "backup_restore_prepared", os.path.basename(path))
        if os.path.exists("/.dockerenv"):
            backup_in_container = os.path.join(backup_manager.load_settings()["directory"], os.path.basename(path))
            command = "docker compose run --rm --no-deps app python /app/scripts/restore_backup.py --backup " + shlex.quote(backup_in_container) + " --data-dir /data"
        else:
            command = "python3 scripts/restore_backup.py --backup " + shlex.quote(path) + " --data-dir " + shlex.quote(BASE_DIR)
        return render_template("backup_restore_prepared.html", filename=os.path.basename(path), manifest=manifest,
                               restore_command=command)
    except (OSError, zipfile.BadZipFile, json.JSONDecodeError, ValueError) as exc:
        flash(f"Restore validation failed: {exc}", "danger")
        return redirect(url_for("backups_page"))

@app.after_request
def _refresh_document_index(response):
    if request.method == "POST" and response.status_code < 400 and request.endpoint in {
        "knowledge_upload", "equipment_file_upload", "bank_connection_info", "sub_object_file_upload",
        "equipment_bank_delete", "sub_object_delete"}:
        search_service.start_sync()
    return response

@app.route("/ai-assistant", methods=["GET","POST"])
@module_required("ai_assistant")
def ai_assistant():
    q=(request.values.get("q") or "").strip()[:2000]
    session.setdefault("search_csrf", secrets.token_hex(32))
    search_service.start_sync()
    username = current_user()["username"]
    conversation_id = request.args.get("conversation", type=int)
    conversation = db.get_ai_conversation(conversation_id, username) if conversation_id else None
    messages = [dict(row) for row in db.list_ai_messages(conversation_id, username)] if conversation else []
    config = db.get_ai_settings()
    return render_template("ai_assistant.html", q=q, sources=_search_sources(),
                           ollama=config["provider"] == "ollama", ai_config=config,
                           conversations=db.list_ai_conversations(username),
                           conversation=conversation, messages=messages)

@app.route("/ai-assistant/query", methods=["POST"])
@module_required("ai_assistant")
def assistant_query():
    if not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session.get("search_csrf", "missing")):
        abort(403)
    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify(error="Send a JSON object containing q."), 400
    q = payload.get("q", "")
    if not isinstance(q, str) or not q.strip() or len(q) > 2000:
        return jsonify(error="Enter a question between 1 and 2,000 characters."), 400
    conversation_id = payload.get("conversation_id")
    if conversation_id is not None:
        try:
            conversation_id = int(conversation_id)
        except (TypeError, ValueError):
            return jsonify(error="Invalid conversation."), 400
    if not _admit_ai_request(current_user()["username"]):
        db.log_action(current_user()["username"], "ai_rate_limited", "Request limit exceeded")
        return jsonify(error="Too many AI requests. Please retry in one minute."), 429, {"Retry-After": "60"}
    try:
        mode = payload.get("mode", "auto")
        if mode not in {"auto", "ask", "diagnose", "capacity", "runbook"}:
            return jsonify(error="Invalid assistant mode."), 400
        return jsonify(_assistant_result(q.strip(), conversation_id, mode))
    except ValueError as exc:
        return jsonify(error=str(exc)), 404
    except Exception:
        app.logger.exception("Assistant search failed")
        db.log_action(current_user()["username"], "ai_query_failed", "See application logs; prompt omitted")
        return jsonify(error="Search could not finish. Check document coverage and retry."), 500

@app.route("/ai-assistant/index-status")
@module_required("ai_assistant")
def assistant_index_status():
    return jsonify(search_service.status(_search_sources()))

@app.route("/ai-assistant/reindex", methods=["POST"])
@module_required("ai_assistant")
def assistant_reindex():
    if current_user()["role"] != "admin": abort(403)
    if not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session.get("search_csrf", "missing")):
        abort(403)
    return jsonify(started=search_service.start_sync(force=True))

@app.route("/ai-assistant/model-status")
@module_required("ai_assistant")
def assistant_model_status():
    config = db.get_ai_settings()
    if config["provider"] != "ollama":
        return jsonify(online=False, disabled=True, models=[], configured_model=config["ollama_model"])
    return jsonify(ollama_status(config))

@app.route("/ai-assistant/conversation/<int:conversation_id>/delete", methods=["POST"])
@module_required("ai_assistant")
def assistant_conversation_delete(conversation_id):
    if not secrets.compare_digest(request.form.get("csrf", ""), session.get("search_csrf", "missing")):
        abort(403)
    db.delete_ai_conversation(conversation_id, current_user()["username"])
    flash("Conversation deleted.", "success")
    return redirect(url_for("ai_assistant"))

@app.route("/ai-assistant/conversation/<int:conversation_id>/feedback", methods=["POST"])
@module_required("ai_assistant")
def assistant_feedback(conversation_id):
    if not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session.get("search_csrf", "missing")):
        abort(403)
    payload = request.get_json(silent=True) or {}
    rating = payload.get("rating")
    if rating not in (-1, 1):
        return jsonify(error="Rating must be helpful or not helpful."), 400
    try:
        db.save_ai_feedback(conversation_id, current_user()["username"], rating, payload.get("comment", ""))
    except ValueError as exc:
        return jsonify(error=str(exc)), 404
    return jsonify(saved=True)

@app.route("/file-search")
@login_required
def file_search():
    return redirect(url_for("ai_assistant", q=request.args.get("q", "").strip()[:2000]))

@app.route("/dashboard")
@login_required
def dashboard():
    counts = {}
    for table in db.SCHEMAS:
        counts[table] = len(db.list_assets(table))
    isos = db.list_iso_files()
    summary, _ = _status_summary()
    devices = db.list_monitoring_devices()
    recent_activity = db.list_system_logs(6)
    return render_template("dashboard.html", counts=counts, isos=isos,
                           summary=summary, monitoring_devices=devices,
                           recent_activity=recent_activity,
                           coverage=search_service.status(_search_sources()), ai_config=db.get_ai_settings())


@app.route("/search")
@login_required
def global_search():
    q = request.args.get("q", "").strip()
    if module_allowed("ai_assistant"):
        return redirect(url_for("ai_assistant", q=q))
    results = db.search_all_assets(q) if q else []
    iso_results = []
    if q:
        like = f"%{q}%"
        conn = db.get_conn()
        iso_results = conn.execute(
            "SELECT * FROM iso_files WHERE original_name LIKE ? OR notes LIKE ? ORDER BY id DESC LIMIT 50",
            (like, like)).fetchall()
        conn.close()
    return render_template("search.html", q=q, results=results, iso_results=iso_results)


# ---------------------------------------------------------------------------
# ISO file library (shown as an "ISO File" card on the dashboard)
# ---------------------------------------------------------------------------

@app.route("/isos/upload", methods=["POST"])
@role_required("editor")
def iso_upload():
    file = request.files.get("file")
    if not file or not file.filename:
        flash("Please choose a file to upload.", "danger")
        return redirect(url_for("dashboard"))

    original_name = file.filename
    ext = os.path.splitext(original_name)[1].lower()
    if ext not in (".iso", ".vsdx"):
        flash("Only .iso and .vsdx files are accepted.", "danger")
        return redirect(url_for("dashboard"))

    media_type = "vsdx" if ext == ".vsdx" else "iso"
    safe_base = secure_filename(original_name) or ("diagram.vsdx" if media_type == "vsdx" else "image.iso")
    stored_name = f"{uuid.uuid4().hex}_{safe_base}"
    dest_path = os.path.join(paths.iso_dir(), stored_name)

    if media_type == "vsdx":
        try:
            size_bytes = _save_upload_limited(file, dest_path, DOCUMENT_MAX_BYTES)
        except ValueError as exc:
            flash(str(exc), "danger")
            return redirect(url_for("dashboard"))
    else:
        file.save(dest_path)  # ISO images can be multi-GB, so keep streaming to disk.
        size_bytes = os.path.getsize(dest_path)

    db.add_iso_file(original_name, stored_name, size_bytes,
                     request.form.get("notes", "").strip(),
                     current_user()["username"], media_type=media_type)
    db.log_action(current_user()["username"], "media_upload", f"{media_type}:{original_name}")
    flash(f'"{original_name}" uploaded successfully.', "success")
    return redirect(url_for("dashboard"))


@app.route("/isos/<int:iso_id>/view")
@login_required
def iso_view(iso_id):
    row = db.get_iso_file(iso_id)
    if not row or (row["media_type"] or "").lower() != "vsdx":
        abort(404)
    file_path = os.path.join(paths.iso_dir(), row["stored_name"])
    if not os.path.exists(file_path):
        abort(404)
    try:
        page_index = max(0, int(request.args.get("page", "0")))
    except ValueError:
        page_index = 0
    try:
        with open(file_path, "rb") as f:
            svg, page_count, page_index = visio_export.import_vsdx_svg(
                f.read(), page_index=page_index)
            svg = _sanitize_svg(svg)
    except Exception as exc:
        try:
            with open(os.path.join(paths.logs_dir(), "server_error.log"), "a", encoding="utf-8") as log:
                import traceback
                log.write("\\n--- VSDX viewer failure %s ---\\n" % datetime.now().isoformat())
                traceback.print_exc(file=log)
        except Exception:
            pass
        return render_template("error.html",
                               log_path=os.path.join(paths.logs_dir(), "server_error.log")), 500
    return render_template("vsdx_viewer.html", row=row, svg=svg,
                           page_count=page_count, page_index=page_index)

@app.route("/isos/<int:iso_id>/download")
@login_required
def iso_download(iso_id):
    row = db.get_iso_file(iso_id)
    if not row:
        abort(404)
    file_path = os.path.join(paths.iso_dir(), row["stored_name"])
    if not os.path.exists(file_path):
        flash("This ISO file is missing from disk.", "danger")
        return redirect(url_for("dashboard"))
    return send_file(file_path, as_attachment=True, download_name=row["original_name"])


@app.route("/isos/<int:iso_id>/delete", methods=["POST"])
@role_required("manager")
def iso_delete(iso_id):
    row = db.get_iso_file(iso_id)
    if row:
        file_path = os.path.join(paths.iso_dir(), row["stored_name"])
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except OSError:
            pass
        db.delete_iso_file(iso_id)
        db.log_action(current_user()["username"], "media_delete", f"{row['media_type']}:{row['original_name']}")
        flash(f'"{row["original_name"]}" deleted.', "warning")
    return redirect(url_for("dashboard"))


# ---------------------------------------------------------------------------
# Generic asset CRUD (flexible modal-based add/edit windows in the template)
# ---------------------------------------------------------------------------

@app.route("/assets/<table>/columns", methods=["GET", "POST"])
@role_required("manager")
def asset_columns(table):
    if table not in db.SCHEMAS:
        abort(404)
    if request.method == "POST":
        _require_v20_csrf()
        try:
            action = request.form.get("action", "")
            if action == "add":
                db.add_custom_field(table, request.form.get("label", ""), request.form.get("field_type", "text"), current_user()["username"])
                flash("Custom column added.", "success")
            elif action == "remove":
                if request.form.get("confirmed") != "yes":
                    raise ValueError("Confirm removal of this column.")
                db.remove_custom_field(table, request.form.get("field_key", ""), current_user()["username"])
                flash("Column removed from forms and exports. Stored values are retained in the database.", "success")
            else:
                raise ValueError("Unknown action.")
        except ValueError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("asset_columns", table=table))
    return render_template("asset_columns.html", table=table, spec=db.SCHEMAS[table], custom_fields=db.custom_fields(table))


@app.route("/assets/<table>")
@login_required
def asset_list(table):
    if table not in db.SCHEMAS:
        abort(404)
    q = request.args.get("q", "").strip()
    rows = db.list_assets(table, q or None)
    return render_template("list.html", table=table, spec=db.SCHEMAS[table],
                            ups_options=db.list_assets('ups'), rows=rows, port_connections={r['id']: __import__('port_map').mappings(table,r['id']) for r in rows} if table in ('servers','storage') else {},
                            port_field_map=__import__('port_map').SERVER_FIELD_PORTS,
                            storage_port_field_map=__import__('port_map').STORAGE_FIELD_PORTS, q=q, edit_row=db.get_asset(table, request.args.get("edit", type=int)) if request.args.get("edit", type=int) else None,
                            lookups={f[3]: db.get_lookup(f[3]) for f in db.SCHEMAS[table]["fields"] if f[3]})


def _asset_health(row):
    raw = str(row["status"] if "status" in row.keys() else "").lower()
    if any(x in raw for x in ("fault", "critical", "down", "failed", "offline")):
        return "critical"
    if any(x in raw for x in ("warn", "maintenance", "standby", "degraded")):
        return "warning"
    if any(x in raw for x in ("active", "healthy", "resolved", "online", "operational", "ok")):
        return "healthy"
    return "unknown"


@app.route('/assets/<table>/<int:row_id>/port-map')
@login_required
def physical_port_map(table, row_id):
    import port_map as pm
    if table not in db.SCHEMAS or table == 'ups' or not db.get_asset(table,row_id): abort(404)
    asset=db.get_asset(table,row_id)
    selected=request.args.get('port','')
    all_ports=pm.ports(table,row_id)
    if selected and selected not in all_ports: abort(404)
    target=request.args.get('target','')
    selected_port=all_ports.get(selected,{})
    selected_kind=selected_port.get('kind','')
    allowed_targets={'FC':{'san_switches'},'Ethernet':{'network'},'Management':{'network'},'SAS':{'storage'},'Power':{'ups'}}.get(selected_kind,set())
    target_table,target_id='',0
    if target:
        try:
            target_table,raw=target.split(':');target_id=int(raw)
            if target_table not in allowed_targets: abort(400)
            target_ports=pm.ports(target_table,target_id) if target_table != 'ups' else {}
            target_used=pm.mappings(target_table,target_id) if target_table != 'ups' else {}
            compatible={'Ethernet':{'Ethernet','Management'},'Management':{'Ethernet','Management'}}.get(selected_kind,{selected_kind})
            target_ports={name:port for name,port in target_ports.items() if name not in target_used and port['kind'] in compatible}
        except (ValueError,TypeError): abort(400)
    else: target_ports={}
    devices=[]
    for category in allowed_targets:
        for item in db.list_assets(category):
            if category==table and item['id']==row_id: continue
            devices.append(dict(key=f"{category}:{item['id']}",label=f"{db.SCHEMAS[category]['label']} · {db.asset_label(category,item)} · #{item['id']}"))
    legacy=db.san_ports_for_switch(row_id) if table=='san_switches' else []
    return render_template('physical_port_map.html',table=table,row_id=row_id,asset=asset,
        port_rows=list(all_ports.values()),connections=pm.mappings(table,row_id),selected=selected,
        devices=devices,target=target,target_ports=target_ports,target_table=target_table,target_id=target_id,
        kinds=pm.KINDS,legacy=legacy,selected_kind=selected_kind,allowed_targets=allowed_targets, power_assignment=(db.get_power_assignments(table,row_id).get(int(selected[3:])) if selected_kind=='Power' and selected.startswith('PSU') and selected[3:].isdigit() else None))


@app.route('/assets/<table>/<int:row_id>/port-map',methods=['POST'])
@role_required('editor')
def physical_port_save(table,row_id):
    import port_map as pm
    _require_v20_csrf()
    if table not in db.SCHEMAS or table == 'ups' or not db.get_asset(table,row_id): abort(404)
    port=request.form.get('port','')
    try:
        action=request.form.get('action','connect')
        user=current_user()['username']
        if action=='configure':
            pm.configure(table,row_id,port,request.form.get('kind',''),request.form.get('section',''),request.form.get('hide')=='1',user)
            port=''
        elif action=='disconnect': pm.disconnect(table,row_id,port,user)
        elif action=='assign_power':
            if not (port.startswith('PSU') and port[3:].isdigit()): raise ValueError('Select a power supply.')
            target_table,raw=request.form.get('target','').split(':')
            if target_table!='ups': raise ValueError('Power supplies can only be assigned to a UPS.')
            db.set_power_assignment(table,row_id,int(port[3:]),raw,user)
        elif action=='connect':
            target_table,raw=request.form.get('target','').split(':')
            pm.connect(table,row_id,port,target_table,int(raw),request.form.get('target_port',''),request.form.get('fabric',''),request.form.get('notes',''),user)
        else: raise ValueError('Unknown action')
        flash('Port map saved. Both endpoints have been updated.','success')
    except (ValueError,TypeError) as exc: flash(str(exc),'danger')
    if port not in pm.ports(table,row_id): port=''
    return redirect(url_for('physical_port_map',table=table,row_id=row_id,port=port))


@app.route("/assets/<table>/<int:row_id>")
@login_required
def asset_detail(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    asset = db.get_asset(table, row_id)
    if not asset:
        abort(404)
    asset_workflows.touch_asset(table, row_id)
    if table == 'san_switches':
        try:
            port_count = int(asset['port_count'] or asset['fc_ports'] or 32)
        except (TypeError, ValueError):
            port_count = 32
        if not 1 <= port_count <= 256:
            port_count = 32
        saved_ports = {int(p['port_number']): p for p in db.san_ports_for_switch(row_id)}
        import port_map as pm
        for name, cable in pm.mappings(table,row_id).items():
            if name.startswith('FC') and name[2:].isdigit():
                saved_ports[int(name[2:])] = dict(destination=cable['target_label']+' / '+cable['target_port'],fabric=cable['fabric'],notes=cable['notes'],updated_by=cable['updated_by'],updated_at=cable['updated_at'],structured=True)
        selected_port = request.args.get('port', type=int)
        if selected_port is not None and not 1 <= selected_port <= port_count:
            abort(404)
        return render_template('san_switch_detail.html', table=table, row_id=row_id, asset=asset,
                               port_count=port_count, saved_ports=saved_ports, selected_port=selected_port,
                               selected_connection=saved_ports.get(selected_port))
    if table == 'network':
        import port_map as pm
        try:
            port_count = int(asset['port_count'] or 24)
        except (TypeError, ValueError):
            port_count = 24
        port_count = min(256, max(1, port_count))
        connections = pm.mappings(table, row_id)
        selected_name = request.args.get('port', '')
        valid_ports = {f'Port{i}' for i in range(1, port_count + 1)}
        if selected_name and selected_name not in valid_ports:
            abort(404)
        return render_template('network_switch_detail.html', table=table, row_id=row_id, asset=asset,
                               port_count=port_count, connections=connections,
                               selected_port=selected_name,
                               selected_connection=connections.get(selected_name))
    spec = db.SCHEMAS[table]
    fields = [{"key": key, "label": label, "value": asset[key] or ""}
              for key, label, _field_type, _lookup in spec["fields"]]
    import port_map as pm
    port_connections = pm.mappings(table, row_id) if table in ("servers", "storage", "ups", "hpe_synergy_servers") else {}
    if table == "servers":
        for field in fields:
            port_name = pm.SERVER_FIELD_PORTS.get(field["key"])
            cable = port_connections.get(port_name) if port_name else None
            if cable:
                field["value"] = f"{cable['target_label']} / {cable['target_port']}"
    populated = [field for field in fields if str(field["value"]).strip()]
    relationships = []
    for link in db.links_for(table, row_id):
        is_source = link["source_table"] == table and link["source_id"] == row_id
        other_table = link["target_table"] if is_source else link["source_table"]
        other_id = link["target_id"] if is_source else link["source_id"]
        other = db.get_asset(other_table, other_id) if other_table in db.SCHEMAS else None
        relationships.append({"link": link, "table": other_table, "id": other_id,
                              "label": db.asset_label(other_table, other) if other is not None else f"{other_table} #{other_id}",
                              "type": db.SCHEMAS.get(other_table, {}).get("label", other_table),
                              "direction": "outbound" if is_source else "inbound"})
    components = db.list_sub_objects(table, row_id)
    identity_values = [asset[k] for k in ("serial_number", "management_ip", "ilo_ip")
                       if k in asset.keys() and asset[k]]
    monitoring_device = None
    for device in db.list_monitoring_devices():
        if device["management_ip"] in identity_values or (device["serial_number"] and device["serial_number"] in identity_values):
            monitoring_device = device
            break
    marker = f"{table}#{row_id}"
    activity = [row for row in db.list_system_logs(200) if marker in str(row["details"] or "")][:8]
    maintenance_logs = db.list_maintenance_logs(table, row_id)
    repair_state = next((log['severity'] for log in maintenance_logs if log['severity'] != 'change'), None)
    if 'status' in asset.keys() and str(asset['status']).strip().lower() in ('healthy','resolved'):
        repair_state = 'green'
    return render_template("asset_detail.html", table=table, row_id=row_id, asset=asset,
                           spec=spec, fields=fields, populated=populated,
                           completion=round((len(populated) / max(1, len(fields))) * 100),
                           health=_asset_health(asset), relationships=relationships,
                           components=components, monitoring_device=monitoring_device,
                           activity=activity, maintenance_logs=maintenance_logs, repair_state=repair_state,
                           preview_ports=pm.ports(table,row_id) if table in ("servers","storage","ups","hpe_synergy_servers") else {},
                           preview_connections=port_connections,
                           power_assignments=db.get_power_assignments(table,row_id) if table in ('servers','storage') else {},
                           powered_assets=db.get_power_assignments_to_ups(row_id) if table=='ups' else [])


@app.route('/assets/san_switches/<int:row_id>/ports/<int:port_number>', methods=['POST'])
@role_required('editor')
def san_port_update(row_id, port_number):
    try:
        import port_map as pm
        if f'FC{port_number}' in pm.mappings('san_switches',row_id):
            raise ValueError('Use Device panel & port map to edit this two-ended cable.')
        db.save_san_port(row_id, port_number, request.form.get('destination', ''),
                         request.form.get('fabric', ''), request.form.get('notes', ''),
                         current_user()['username'])
    except ValueError as exc:
        flash(str(exc), 'danger')
    else:
        flash(f'Port {port_number} connection saved.', 'success')
    return redirect(url_for('asset_detail', table='san_switches', row_id=row_id, port=port_number))


@app.route('/assets/<table>/<int:row_id>/changes.xlsx')
@login_required
def asset_change_export(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    asset = db.get_asset(table, row_id)
    if not asset:
        abort(404)
    if not EXCEL_AVAILABLE:
        flash("openpyxl is not installed.", "danger")
        return redirect(url_for('asset_detail', table=table, row_id=row_id))
    wb = Workbook()
    ws = wb.active
    ws.title = "Equipment Changes"
    ws.append(["Date", "Change", "Record type / status", "Recorded by", "Recorded at"])
    for log in db.list_maintenance_logs(table, row_id):
        ws.append([log["event_date"], log["description"], log["severity"], log["created_by"], log["created_at"]])
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str): cell.data_type = 's'
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    mem = io.BytesIO()
    wb.save(mem)
    mem.seek(0)
    return send_file(mem, as_attachment=True,
        download_name=f"{table}_{row_id}_changes_{datetime.now():%Y%m%d_%H%M}.xlsx")


@app.route('/assets/<table>/<int:row_id>/edit', methods=['GET'])
@role_required('editor')
def asset_edit_page(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    asset = db.get_asset(table, row_id)
    if not asset:
        abort(404)
    return render_template('asset_edit.html', table=table, row_id=row_id, asset=asset,
                           spec=db.SCHEMAS[table], ups_options=db.list_assets('ups'),
                           power_assignments=db.get_power_assignments(table,row_id),
                           lookups={f[3]: db.get_lookup(f[3]) for f in db.SCHEMAS[table]['fields'] if f[3]})


@app.route('/assets/<table>/<int:row_id>/maintenance', methods=['POST'])
@role_required('editor')
def asset_maintenance_create(table, row_id):
    if table not in db.SCHEMAS or not db.get_asset(table, row_id):
        abort(404)
    try:
        db.add_maintenance_log(table, row_id, request.form.get('event_date', ''),
                               request.form.get('description', ''), request.form.get('severity', ''),
                               current_user()['username'])
    except (ValueError, TypeError):
        flash('Enter a valid date, description and severity.', 'danger')
    else:
        flash('Maintenance log saved.', 'success')
    return redirect(url_for('asset_detail', table=table, row_id=row_id))


@app.route("/assets/<table>/new", methods=["POST"])
@role_required("editor")
def asset_create(table):
    if table not in db.SCHEMAS:
        abort(404)
    try:
        row_id = db.create_asset(table, request.form, current_user()["username"])
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("asset_list",table=table))
    if table in ('servers','storage'):
        try:
            db.save_power_assignments(table,row_id,request.form,current_user()['username'])
        except ValueError as exc:
            flash(str(exc),'warning')
    if request.form.get('maintenance_description', '').strip() or request.form.get('maintenance_severity') == 'green':
        try:
            db.add_maintenance_log(table, row_id, request.form.get('maintenance_date') or datetime.now().strftime('%Y-%m-%d'), request.form.get('maintenance_description') or 'Issue resolved; asset marked healthy.', request.form.get('maintenance_severity', ''), current_user()['username'])
        except (ValueError, TypeError):
            flash('Asset saved; maintenance log needs a valid date and severity.', 'warning')
    flash("New record created successfully.", "success")
    return redirect(url_for("asset_detail", table=table, row_id=row_id))


@app.route("/assets/<table>/<int:row_id>/edit", methods=["POST"])
@role_required("editor")
def asset_edit(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    if not db.get_asset(table, row_id):
        abort(404)
    try:
        db.update_asset(table, row_id, request.form, current_user()["username"])
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("asset_edit_page",table=table,row_id=row_id))
    if table in ('servers','storage'):
        try:
            db.save_power_assignments(table,row_id,request.form,current_user()['username'])
        except ValueError as exc:
            flash(str(exc),'warning')
    if request.form.get('maintenance_description', '').strip() or request.form.get('maintenance_severity') == 'green':
        try:
            db.add_maintenance_log(table, row_id, request.form.get('maintenance_date') or datetime.now().strftime('%Y-%m-%d'), request.form.get('maintenance_description') or 'Issue resolved; asset marked healthy.', request.form.get('maintenance_severity', ''), current_user()['username'])
        except (ValueError, TypeError):
            flash('Asset saved; maintenance log needs a valid date and severity.', 'warning')
    flash("Record updated successfully.", "success")
    return redirect(url_for("asset_detail", table=table, row_id=row_id))


@app.route("/assets/<table>/<int:row_id>/delete", methods=["POST"])
@role_required("manager")
def asset_delete(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    if table == 'ups' and db.get_power_assignments_to_ups(row_id):
        flash("This UPS still has assigned power supplies. Reassign them before deleting it.", "danger")
        return redirect(url_for("asset_list", table=table))
    db.delete_asset(table, row_id, current_user()["username"])
    flash("Record moved to Recycle Bin for 30 days.", "warning")
    return redirect(url_for("asset_list", table=table))

@app.route("/assets/<table>/bulk-delete", methods=["POST"])
@role_required("manager")
def asset_bulk_delete(table):
    if table not in ("servers", "storage"): abort(403)
    ids=[]
    for raw in request.form.getlist("selected_ids"):
        try:
            v=int(raw)
            if v>0: ids.append(v)
        except (TypeError,ValueError): pass
    ids=list(dict.fromkeys(ids))
    if not ids: flash("No equipment selected.","warning")
    else: flash(f"{db.delete_assets(table,ids,current_user()["username"])} selected equipment record(s) moved to Recycle Bin.","warning")
    return redirect(url_for("asset_list", table=table))


@app.route("/assets/<table>/<int:row_id>/subobjects", methods=["GET", "POST"])
@login_required
def sub_objects(table, row_id):
    if table not in db.SCHEMAS:
        abort(404)
    if request.method == "POST":
        if db.ROLE_LEVEL[current_user()["role"]] < db.ROLE_LEVEL["editor"]:
            abort(403)
        db.add_sub_object(table, row_id, request.form.get("name", ""),
                           request.form.get("obj_type", ""), request.form.get("notes", ""))
        db.log_action(current_user()["username"], "subobject_create", f"{table}#{row_id}:{request.form.get('name','')}")
        return redirect(url_for("sub_objects", table=table, row_id=row_id))
    asset = db.get_asset(table, row_id)
    if not asset:
        abort(404)
    subs = db.list_sub_objects(table, row_id)
    return render_template("subobjects.html", table=table, spec=db.SCHEMAS[table],
                            asset=asset, subs=subs)


SUBOBJECT_FILE_DIR=os.path.join(paths.data_dir(),"subobject_files")
os.makedirs(SUBOBJECT_FILE_DIR,exist_ok=True)

@app.route("/subobjects/<int:sub_id>/file", methods=["POST"])
@role_required("editor")
def sub_object_file_upload(sub_id):
    sub=db.get_sub_object(sub_id)
    if not sub: abort(404)
    f=request.files.get("file"); description=request.form.get("description","").strip()
    if not f or not f.filename or not description:
        flash("File and Description are required.","danger")
        return redirect(_safe_local_redirect(request.referrer, url_for("dashboard")))
    ext=os.path.splitext(f.filename)[1].lower()
    if ext not in EQUIPMENT_FILE_EXTENSIONS:
        flash("Unsupported file type.","danger")
        return redirect(_safe_local_redirect(request.referrer, url_for("dashboard")))
    original=f.filename; safe=secure_filename(original) or ("document"+ext)
    stored=uuid.uuid4().hex+"_"+safe; path=os.path.join(SUBOBJECT_FILE_DIR,stored)
    try:
        _save_upload_limited(f, path, DOCUMENT_MAX_BYTES)
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(_safe_local_redirect(request.referrer, url_for("dashboard")))
    db.add_sub_object_file(sub_id,original,stored,EQUIPMENT_FILE_EXTENSIONS[ext],os.path.getsize(path),current_user()["username"],description)
    db.log_action(current_user()["username"],"subobject_file_upload",f"subobject#{sub_id}:{original}")
    flash("File uploaded successfully.","success")
    return redirect(_safe_local_redirect(request.referrer, url_for("dashboard")))

@app.route("/subobjects/file/<int:file_id>")
@login_required
def sub_object_file_view(file_id):
    row=db.get_sub_object_file(file_id)
    if not row: abort(404)
    path=os.path.join(SUBOBJECT_FILE_DIR,row["stored_name"])
    if not os.path.exists(path): abort(404)
    return send_file(path,as_attachment=False,download_name=row["original_name"])

@app.route("/subobjects/<int:sub_id>/delete", methods=["POST"])
@role_required("manager")
def sub_object_delete(sub_id):
    db.delete_sub_object(sub_id)
    db.log_action(current_user()["username"], "subobject_delete", f"subobject#{sub_id}")
    return redirect(_safe_local_redirect(request.referrer, url_for("dashboard")))


# ---------------------------------------------------------------------------
# Lookup (dropdown) management - add / rename / delete values live
# ---------------------------------------------------------------------------

@app.route("/lookups")
@role_required("manager")
def lookups_page():
    keys = db.all_lookup_keys()
    data = {}
    conn = db.get_conn()
    for k in keys:
        data[k] = conn.execute(
            "SELECT * FROM lookups WHERE field_key=? ORDER BY sort_order, value", (k,)).fetchall()
    conn.close()
    return render_template("lookups.html", data=data)


@app.route("/lookups/<field_key>/add", methods=["POST"])
@role_required("manager")
def lookup_add(field_key):
    db.add_lookup_value(field_key, request.form.get("value", ""))
    db.log_action(current_user()["username"], "lookup_add", f"{field_key}:{request.form.get('value','')}")
    return redirect(url_for("lookups_page"))


@app.route("/lookups/<int:lookup_id>/rename", methods=["POST"])
@role_required("manager")
def lookup_rename(lookup_id):
    db.rename_lookup_value(lookup_id, request.form.get("value", ""))
    db.log_action(current_user()["username"], "lookup_rename", f"lookup#{lookup_id}")
    return redirect(url_for("lookups_page"))


@app.route("/lookups/<int:lookup_id>/delete", methods=["POST"])
@role_required("manager")
def lookup_delete(lookup_id):
    db.delete_lookup_value(lookup_id)
    db.log_action(current_user()["username"], "lookup_delete", f"lookup#{lookup_id}")
    return redirect(url_for("lookups_page"))


# Inline "quick add" used by the dropdown widgets on asset forms (AJAX)
@app.route("/api/lookups/<field_key>/quick-add", methods=["POST"])
@role_required("editor")
def api_lookup_quick_add(field_key):
    value = (request.json or {}).get("value", "").strip()
    if value:
        db.add_lookup_value(field_key, value)
        db.log_action(current_user()["username"], "lookup_add", f"{field_key}:{value}")
    return jsonify({"values": db.get_lookup(field_key)})


# ---------------------------------------------------------------------------
# Diagram (Jira-Assets style link graph)
# ---------------------------------------------------------------------------

@app.route("/diagram")
@login_required
def diagram_page():
    return render_template("diagram.html")


def _node_key(table, row_id, is_sub=False):
    return f"{'sub' if is_sub else 'asset'}:{table}:{row_id}"


@app.route("/api/diagram/data")
@login_required
def api_diagram_data():
    positions = db.all_positions()
    links = db.list_links()
    nodes = {}
    edges = []

    def ensure_node(table, row_id):
        if table not in db.SCHEMAS:
            return None
        key = _node_key(table, row_id)
        if key in nodes:
            return key
        row = db.get_asset(table, row_id)
        if not row:
            return None
        x, y = positions.get(key, (None, None))
        nodes[key] = {
            "id": key, "table": table, "row_id": row_id,
            "label": db.asset_label(table, row),
            "group": table,
            "x": x, "y": y,
        }
        return key

    for link in links:
        sk = ensure_node(link["source_table"], link["source_id"])
        tk = ensure_node(link["target_table"], link["target_id"])
        if sk and tk:
            edges.append({
                "id": link["id"], "from": sk, "to": tk,
                "label": link["link_type"] or "",
                "notes": link["notes"] or "",
            })
    return jsonify({"nodes": list(nodes.values()), "edges": edges})


@app.route("/api/diagram/search-assets")
@login_required
def api_search_assets():
    q = request.args.get("q", "")
    return jsonify(db.search_all_assets(q) if q else [])


@app.route("/api/diagram/link", methods=["POST"])
@role_required("editor")
def api_create_link():
    data = request.json or {}
    source_table = str(data.get("source_table", ""))
    target_table = str(data.get("target_table", ""))
    if source_table not in db.SCHEMAS or target_table not in db.SCHEMAS:
        abort(400)
    try:
        source_id = int(data.get("source_id"))
        target_id = int(data.get("target_id"))
    except (TypeError, ValueError):
        abort(400)
    if source_id <= 0 or target_id <= 0 or not db.get_asset(source_table, source_id) or not db.get_asset(target_table, target_id):
        abort(404)
    link_type = str(data.get("link_type", "connected to"))[:120]
    label = str(data.get("label", ""))[:240]
    notes = str(data.get("notes", ""))[:4000]
    db.create_link(source_table, source_id, target_table, target_id, link_type, label, notes, current_user()["username"])
    db.log_action(current_user()["username"], "link_create", f"{source_table}#{source_id} -> {target_table}#{target_id}")
    return jsonify({"ok": True})


@app.route("/api/diagram/link/<int:link_id>", methods=["DELETE"])
@role_required("editor")
def api_delete_link(link_id):
    db.delete_link(link_id)
    db.log_action(current_user()["username"], "link_delete", f"link#{link_id}")
    return jsonify({"ok": True})


@app.route("/api/diagram/position", methods=["POST"])
@role_required("editor")
def api_save_position():
    data = request.json or {}
    node_key = str(data.get("node_key", ""))[:200]
    try:
        x, y = float(data.get("x")), float(data.get("y"))
    except (TypeError, ValueError):
        abort(400)
    if not node_key or not math.isfinite(x) or not math.isfinite(y) or abs(x) > 1_000_000 or abs(y) > 1_000_000:
        abort(400)
    db.save_position(node_key, x, y)
    db.log_action(current_user()["username"], "diagram_position_update", node_key)
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Import / Export (CSV, Excel, Visio .vdx)
# ---------------------------------------------------------------------------

@app.route("/export/<table>.csv")
@login_required
def export_csv(table):
    if table not in db.SCHEMAS:
        abort(404)
    spec = db.SCHEMAS[table]
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([f[1] for f in spec["fields"]])
    for row in db.list_assets(table):
        writer.writerow([row[f[0]] for f in spec["fields"]])
    mem = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    return send_file(mem, mimetype="text/csv", as_attachment=True,
                      download_name=f"{table}_{datetime.now():%Y%m%d_%H%M}.csv")


@app.route("/export/<table>.xlsx")
@login_required
def export_xlsx(table):
    if not EXCEL_AVAILABLE:
        flash("openpyxl is not installed.", "danger")
        return redirect(url_for("asset_list", table=table))
    if table not in db.SCHEMAS:
        abort(404)
    spec = db.SCHEMAS[table]
    wb = Workbook()
    ws = wb.active
    ws.title = spec["label"][:31]
    ws.append([f[1] for f in spec["fields"]])
    for row in db.list_assets(table):
        ws.append([row[f[0]] for f in spec["fields"]])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.font = cell.font.copy(bold=True)
    mem = io.BytesIO()
    wb.save(mem)
    mem.seek(0)
    return send_file(mem, as_attachment=True,
                      download_name=f"{table}_{datetime.now():%Y%m%d_%H%M}.xlsx")


@app.route("/import/<table>", methods=["POST"])
@role_required("editor")
def import_table(table):
    if table not in db.SCHEMAS:
        abort(404)
    file = request.files.get("file")
    if not file or not file.filename:
        flash("No file selected.", "danger")
        return redirect(url_for("asset_list", table=table))
    try:
        filename = (file.filename or "").lower()
        ext = os.path.splitext(filename)[1]
        if ext not in {".xlsx", ".csv"}:
            raise ValueError("Only .xlsx and .csv files are accepted for asset import.")
        data = _read_upload_limited(file, IMPORT_MAX_BYTES)
        _validate_file_signature(filename, data)
        if ext == ".xlsx":
            if not EXCEL_AVAILABLE:
                raise ValueError("Excel import requires openpyxl to be installed.")
            from openpyxl import load_workbook
            wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
            ws = wb.active
            rows = []
            for row_index, row in enumerate(ws.iter_rows(values_only=True), start=1):
                if row_index > 100001:
                    wb.close()
                    raise ValueError("Import is limited to 100,000 data rows.")
                rows.append(list(row))
            wb.close()
            rows = [["" if value is None else str(value) for value in row] for row in rows]
        else:
            content = data.decode("utf-8-sig", errors="strict")
            sample = content[:4096]
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except csv.Error:
                dialect = csv.excel
            rows = []
            for row_index, row in enumerate(csv.reader(io.StringIO(content), dialect), start=1):
                if row_index > 100001:
                    raise ValueError("Import is limited to 100,000 data rows.")
                rows.append(row)
        if not rows:
            raise ValueError("The file is empty.")
        headers = [str(h or "").strip()[:200] for h in rows[0]]
        mapping = db.match_import_columns(table, headers)
        if not any(mapping):
            raise ValueError("No matching columns found. Please check the header names.")
        imported = 0
        for values in rows[1:]:
            record = {}
            for idx, field in enumerate(mapping):
                if field and idx < len(values):
                    record[field] = str(values[idx] or "").strip()[:10000]
            if any(record.values()):
                db.create_asset(table, record, current_user()["username"])
                imported += 1
        db.log_action(current_user()["username"], "asset_import", f"{table}: {imported} records from {secure_filename(file.filename)}")
        flash(f"{imported} record(s) imported successfully.", "success")
    except UnicodeDecodeError:
        flash("Import error: CSV files must be UTF-8 encoded.", "danger")
    except Exception as exc:
        flash(f"Import error: {exc}", "danger")
    return redirect(url_for("asset_list", table=table))


@app.route("/export/diagram.vdx")
@login_required
def export_diagram_vdx():
    positions = db.all_positions()
    links = db.list_links()
    nodes_by_key = {}

    def ensure(table, row_id):
        if table not in db.SCHEMAS:
            return None
        key = _node_key(table, row_id)
        if key not in nodes_by_key:
            row = db.get_asset(table, row_id)
            if not row:
                return None
            x, y = positions.get(key, (1 + len(nodes_by_key) * 2, 1))
            nodes_by_key[key] = {"key": key, "label": db.asset_label(table, row),
                                  "x": x or 1, "y": y or 1}
        return key

    edges = []
    for link in links:
        sk = ensure(link["source_table"], link["source_id"])
        tk = ensure(link["target_table"], link["target_id"])
        if sk and tk:
            edges.append({"source_key": sk, "target_key": tk, "label": link["link_type"]})

    vdx = visio_export.export_vdx(list(nodes_by_key.values()), edges)
    mem = io.BytesIO(vdx.encode("utf-8"))
    return send_file(mem, mimetype="application/xml", as_attachment=True,
                      download_name=f"diagram_{datetime.now():%Y%m%d_%H%M}.vdx")


@app.route("/import/diagram-vdx", methods=["POST"])
@role_required("editor")
def import_diagram_vdx():
    file = request.files.get("file")
    if not file or not file.filename:
        flash("No file selected.", "danger")
        return redirect(url_for("diagram_page"))
    if os.path.splitext(file.filename)[1].lower() != ".vdx":
        flash("Only .vdx files are accepted.", "danger")
        return redirect(url_for("diagram_page"))
    try:
        data = _read_upload_limited(file, VDX_MAX_BYTES)
        _validate_file_signature(file.filename, data)
        shapes, _ = visio_export.import_vdx(data)
    except Exception as exc:
        flash(f"VDX import error: {exc}", "danger")
        return redirect(url_for("diagram_page"))
    matched = 0
    for shape in shapes[:10000]:
        for table in db.SCHEMAS:
            for row in db.list_assets(table, str(shape.get("text", ""))[:500]):
                key = _node_key(table, row["id"])
                db.save_position(key, shape["x"], shape["y"])
                matched += 1
                break
    db.log_action(current_user()["username"], "diagram_vdx_import", f"{secure_filename(file.filename)}: {matched} matches")
    flash(f"{matched} shape(s) matched to existing assets and positions saved.", "info")
    return redirect(url_for("diagram_page"))


# ---------------------------------------------------------------------------
# Users (admin only) - 4 access levels: admin / manager / editor / viewer
# ---------------------------------------------------------------------------

@app.route("/recycle-bin")
@role_required("manager")
def recycle_bin():
    return render_template("recycle_bin.html", items=db.list_trashed_assets())


@app.route("/recycle-bin/<table>/<int:row_id>/restore", methods=["POST"])
@role_required("manager")
def recycle_restore(table, row_id):
    if not db.restore_asset(table, row_id, current_user()["username"]): abort(404)
    flash("Equipment restored with its original ID, components and relationships.", "success")
    return redirect(url_for("recycle_bin"))


@app.route("/logs/<kind>/<int:log_id>/delete", methods=["POST"])
@role_required("admin")
def log_delete(kind, log_id):
    if kind not in ("audit", "system"): abort(404)
    if not db.delete_log_entry(kind, log_id): abort(404)
    db.log_action(current_user()["username"], "log_delete", f"Deleted {kind} log entry #{log_id}")
    return redirect(url_for("logs_page", tab=kind))


@app.route("/logs/export.xlsx")
@role_required("manager")
def export_logs_xlsx():
    if not EXCEL_AVAILABLE:
        flash("openpyxl is not installed.", "danger")
        return redirect(url_for("logs_page", tab=request.args.get("tab", "audit")))
    tab = request.args.get("tab", "audit")
    if tab not in ("audit", "system"):
        tab = "audit"
    rows = db.list_audit_logs() if tab == "audit" else db.list_system_logs()
    wb = Workbook()
    ws = wb.active
    ws.title = "Audit" if tab == "audit" else "System Log"
    ws.append(["ID", "Date / Time", "User", "Action", "Details"])
    for r in rows:
        ws.append([r["id"], r["created_at"], r["username"] or "system", r["action"], r["details"] or ""])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    widths = {"A": 10, "B": 22, "C": 24, "D": 30, "E": 90}
    for col, width in widths.items():
        ws.column_dimensions[col].width = width
    for cell in ws[1]:
        cell.font = cell.font.copy(bold=True)
    mem = io.BytesIO()
    wb.save(mem)
    mem.seek(0)
    return send_file(mem, as_attachment=True,
                     download_name=f"{tab}_Log_{datetime.now():%Y%m%d_%H%M}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/logs")
@role_required("manager")
def logs_page():
    tab = request.args.get("tab", "audit")
    if tab not in ("audit", "system"):
        tab = "audit"
    return render_template("logs.html", tab=tab,
                           audit_logs=db.list_audit_logs(),
                           system_logs=db.list_system_logs())


def _normalize_profile_image(data):
    """Decode and re-encode profile images to strip metadata/active payloads."""
    try:
        with Image.open(io.BytesIO(data)) as probe:
            probe.verify()
        with Image.open(io.BytesIO(data)) as image:
            image.load()
            if image.width < 1 or image.height < 1 or image.width * image.height > 20_000_000:
                raise ValueError("Profile photo dimensions are not allowed.")
            image.thumbnail((2048, 2048))
            fmt = (image.format or "").upper()
            output = io.BytesIO()
            if fmt in {"JPEG", "JPG"}:
                image.convert("RGB").save(output, format="JPEG", quality=90, optimize=True)
                ext, mimetype = ".jpg", "image/jpeg"
            elif fmt == "PNG":
                clean = image.convert("RGBA") if "A" in image.getbands() else image.convert("RGB")
                clean.save(output, format="PNG", optimize=True)
                ext, mimetype = ".png", "image/png"
            elif fmt == "WEBP":
                clean = image.convert("RGBA") if "A" in image.getbands() else image.convert("RGB")
                clean.save(output, format="WEBP", quality=90, method=6)
                ext, mimetype = ".webp", "image/webp"
            else:
                raise ValueError("Profile photo must be a valid JPG, PNG or WebP image.")
            normalized = output.getvalue()
            if not normalized or len(normalized) > 4 * 1024 * 1024:
                raise ValueError("The normalized profile photo is too large.")
            return normalized, ext, mimetype
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError("Profile photo must be a valid JPG, PNG or WebP image.") from exc


def _profile_return_path():
    return _safe_local_redirect(request.form.get("next", ""), url_for("dashboard"))


@app.route("/profile/photo/<int:user_id>")
@login_required
def profile_photo(user_id):
    user = db.get_user_by_id(user_id)
    if not user or not user["avatar_filename"]:
        abort(404)
    filename = os.path.basename(user["avatar_filename"])
    path = os.path.join(PROFILE_IMAGE_DIR, filename)
    if not os.path.isfile(path):
        abort(404)
    ext = os.path.splitext(filename)[1].lower()
    mimetype = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(ext, "application/octet-stream")
    return send_file(path, mimetype=mimetype)


@app.route("/profile/photo", methods=["POST"])
@login_required
def profile_photo_upload():
    _require_v20_csrf()
    user = current_user()
    upload = request.files.get("photo")
    if not upload or not upload.filename:
        flash("Choose a profile photo first.", "danger")
        return redirect(_profile_return_path())
    try:
        data = upload.read(PROFILE_IMAGE_MAX_BYTES + 1)
        if not data:
            raise ValueError("The selected image is empty.")
        if len(data) > PROFILE_IMAGE_MAX_BYTES:
            raise ValueError("Profile photo must be 2 MB or smaller.")
        normalized, ext, _ = _normalize_profile_image(data)
        filename = f"user-{user['id']}-{uuid.uuid4().hex}{ext}"
        destination = os.path.join(PROFILE_IMAGE_DIR, filename)
        temp_destination = destination + ".part"
        with open(temp_destination, "wb") as target:
            target.write(normalized)
        os.replace(temp_destination, destination)
        previous = user["avatar_filename"]
        db.set_user_avatar(user["id"], filename)
        if previous:
            old_path = os.path.join(PROFILE_IMAGE_DIR, os.path.basename(previous))
            if old_path != destination and os.path.isfile(old_path):
                try: os.remove(old_path)
                except OSError: pass
        db.log_action(user["username"], "profile_photo_update", "Updated own profile photo")
        flash("Profile photo updated.", "success")
    except Exception as exc:
        flash(str(exc), "danger")
    return redirect(_profile_return_path())


@app.route("/profile/photo/delete", methods=["POST"])
@login_required
def profile_photo_delete():
    _require_v20_csrf()
    user = current_user()
    previous = user["avatar_filename"]
    if previous:
        db.set_user_avatar(user["id"], None)
        old_path = os.path.join(PROFILE_IMAGE_DIR, os.path.basename(previous))
        if os.path.isfile(old_path):
            try: os.remove(old_path)
            except OSError: pass
        db.log_action(user["username"], "profile_photo_delete", "Removed own profile photo")
        flash("Profile photo removed.", "success")
    return redirect(_profile_return_path())


@app.route("/users")
@role_required("admin")
def users_page():
    return render_template("users.html", users=db.list_users(), roles=db.ROLES)


@app.route("/users/new", methods=["POST"])
@role_required("admin")
def user_create():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "operator")
    try:
        if not 2 <= len(username) <= 64: raise ValueError("Username must contain 2 to 64 characters.")
        _validate_new_password(password)
        if role not in db.ROLES: raise ValueError("Invalid user role.")
        db.create_user(username, password, request.form.get("full_name", "").strip(), role)
        db.log_action(current_user()["username"], "user_create", f"Created user {username}; name={request.form.get('full_name', '').strip()}; role={role}; active=yes")
        flash("User created successfully.", "success")
    except Exception as exc:
        flash("That username already exists." if "UNIQUE" in str(exc).upper() else str(exc), "danger")
    return redirect(url_for("users_page"))


@app.route("/users/<int:user_id>/edit", methods=["POST"])
@role_required("admin")
def user_edit(user_id):
    target = db.get_user_by_id(user_id)
    if not target: abort(404)
    username = request.form.get("username", "").strip()
    role = request.form.get("role", "operator")
    active = 1 if request.form.get("active") else 0
    new_password = request.form.get("password") or None
    try:
        if not 2 <= len(username) <= 64: raise ValueError("Username must contain 2 to 64 characters.")
        if role not in db.ROLES: raise ValueError("Invalid user role.")
        if new_password: _validate_new_password(new_password)
        is_self = target["username"] == current_user()["username"]
        removing_admin = target["role"] == "admin" and target["active"] and (role != "admin" or not active)
        if is_self and (not active or role != "admin"):
            raise ValueError("You cannot deactivate or remove the Admin role from your current account.")
        if removing_admin and db.count_active_admins() <= 1:
            raise ValueError("At least one active Administrator account must remain.")
        db.update_user(user_id, username, request.form.get("full_name", "").strip(), role, active, new_password)
        if is_self and username != target["username"]: session["username"] = username
        changes = []
        for field, before, after in (("username", target["username"], username),
                                     ("full name", target["full_name"], request.form.get("full_name", "").strip()),
                                     ("role", target["role"], role), ("active", bool(target["active"]), bool(active))):
            if before != after: changes.append(f"{field}: {before} -> {after}")
        if new_password: changes.append("password changed (value omitted)")
        db.log_action(current_user()["username"], "user_update", f"user#{user_id} ({username}): " + ("; ".join(changes) or "no changes"))
        flash("User updated successfully.", "success")
    except Exception as exc:
        flash("That username already exists." if "UNIQUE" in str(exc).upper() else str(exc), "danger")
    return redirect(url_for("users_page"))


@app.route("/users/<int:user_id>/delete", methods=["POST"])
@role_required("admin")
def user_delete(user_id):
    target = db.get_user_by_id(user_id)
    if not target: abort(404)
    if target["username"] == current_user()["username"]:
        flash("You cannot delete the account you are currently using.", "danger")
    elif target["role"] == "admin" and target["active"] and db.count_active_admins() <= 1:
        flash("The last active Administrator account cannot be deleted.", "danger")
    else:
        avatar_filename = target["avatar_filename"]
        db.delete_user(user_id)
        if avatar_filename:
            avatar_path = os.path.join(PROFILE_IMAGE_DIR, os.path.basename(avatar_filename))
            if os.path.isfile(avatar_path):
                try: os.remove(avatar_path)
                except OSError: pass
        db.log_action(current_user()["username"], "user_delete", f"Deleted user#{user_id}: {target['username']}; role={target['role']}; active={bool(target['active'])}")
        flash("User deleted successfully.", "warning")
    return redirect(url_for("users_page"))


# Serve plain HTTP on :5000 by default for local development.
PORT = int(os.environ.get("FHW_ASSET_PORT", "5000"))
HOST = os.environ.get("FHW_ASSET_HOST", "127.0.0.1")
# Set FHW_ASSET_SSL=1 only when direct, self-signed local TLS is needed.
USE_SSL = os.environ.get("FHW_ASSET_SSL", "0") not in ("0", "false", "False", "")

CERT_DIR = os.path.join(BASE_DIR, "instance")
CERT_FILE = os.path.join(CERT_DIR, "cert.pem")
KEY_FILE = os.path.join(CERT_DIR, "key.pem")


def _ensure_self_signed_cert():
    """Create a self-signed TLS certificate on first run if one isn't already
    provided. Lets the app serve HTTPS directly on :443 with zero setup.
    Browsers will show a "not trusted" warning for this cert; that's expected
    for a self-signed certificate and can be replaced with a real one issued
    by your CA by dropping it at the same CERT_FILE/KEY_FILE paths."""
    if os.path.exists(CERT_FILE) and os.path.exists(KEY_FILE):
        return True
    try:
        import datetime as _dt
        import ipaddress
        import socket
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID

        os.makedirs(CERT_DIR, exist_ok=True)
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        hostname = socket.gethostname()
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, hostname)])

        san = [x509.DNSName(u"localhost"), x509.DNSName(hostname)]
        # Include every local IPv4 address so direct HTTPS :443 also works
        # when clients connect with the server's LAN IP instead of its host name.
        local_ips = {"127.0.0.1"}
        try:
            for item in socket.getaddrinfo(hostname, None, socket.AF_INET):
                local_ips.add(item[4][0])
        except Exception:
            pass
        for ip in sorted(local_ips):
            try:
                san.append(x509.IPAddress(ipaddress.IPv4Address(ip)))
            except Exception:
                pass

        now = _dt.datetime.utcnow()
        cert = (
            x509.CertificateBuilder()
            .subject_name(name)
            .issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + _dt.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName(san), critical=False)
            .sign(key, hashes.SHA256())
        )

        with open(KEY_FILE, "wb") as f:
            f.write(key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            ))
        with open(CERT_FILE, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        return True
    except Exception:
        return False


def _startup_error(exc):
    try:
        root = paths.data_dir()
        os.makedirs(root, exist_ok=True)
        log_path = os.path.join(root, "startup.log")
        with open(log_path, "a", encoding="utf-8") as f:
            import traceback
            f.write("\n--- startup failure %s ---\n" % datetime.now().isoformat())
            traceback.print_exc(file=f)
    except Exception:
        pass


def _backup_scheduler_loop():
    from scripts.backup_scheduler import tick
    while True:
        try:
            tick()
        except Exception as exc:
            try:
                backup_manager.save_status({**backup_manager.load_status(), "result": "error",
                                            "message": str(exc)[:2000]})
            except Exception:
                pass
        time.sleep(60)


@app.fastapi.on_event("startup")
async def _start_native_backup_scheduler():
    # Docker has a dedicated scheduler service; native installs use this daemon.
    if not os.path.exists("/.dockerenv"):
        threading.Thread(target=_backup_scheduler_loop, name="fhw-backup-scheduler", daemon=True).start()

@app.fastapi.on_event("startup")
async def _start_inventory_automation():
    automation.start(paths, intelligence.quality,
                     lambda severity, source, title, details, key: ops20.record_event(db, severity, source, title, details, key))


import asset_workflows
asset_workflows.register(app, module_required, module_allowed)

asgi_app = app.fastapi

if __name__ == "__main__":
    try:
        ssl_context = None
        if USE_SSL:
            if _ensure_self_signed_cert():
                ssl_context = (CERT_FILE, KEY_FILE)
            else:
                print("WARNING: could not create/find a TLS certificate; "
                      "falling back to plain HTTP. Set FHW_ASSET_SSL=0 to "
                      "silence this, or install the 'cryptography' package.")

        import uvicorn
        uvicorn.run(asgi_app, host=HOST, port=PORT,
                    ssl_certfile=CERT_FILE if ssl_context else None,
                    ssl_keyfile=KEY_FILE if ssl_context else None,
                    proxy_headers=TRUST_PROXY)
    except Exception as exc:
        _startup_error(exc)
        raise
