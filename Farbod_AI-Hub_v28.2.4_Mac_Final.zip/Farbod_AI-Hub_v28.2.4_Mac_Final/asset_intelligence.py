"""Recorded-inventory analysis. No result is a claim about live service availability."""
import json, re, ipaddress
from collections import defaultdict
from contextlib import closing
from datetime import date, datetime, timezone
import database as db
import port_map as pm

DATE_FIELDS = ('purchase_date','warranty_end','support_end','next_service','retirement_date')

def actor():
    try:
        from webcore import session
        return session.get('username') or 'system'
    except (LookupError, RuntimeError, AttributeError):
        return 'system'

def record(conn, table, asset_id, kind, before, after, user=None):
    if before == after: return
    conn.execute('INSERT INTO asset_history_v27(asset_table,asset_id,kind,actor,before_json,after_json) VALUES(?,?,?,?,?,?)',
                 (table, asset_id, kind, user or actor(), json.dumps(before,ensure_ascii=False), json.dumps(after,ensure_ascii=False)))

def ensure_schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS asset_history_v27(
      id INTEGER PRIMARY KEY,asset_table TEXT NOT NULL,asset_id INTEGER NOT NULL,kind TEXT NOT NULL,
      actor TEXT NOT NULL,at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      before_json TEXT NOT NULL,after_json TEXT NOT NULL)''')
    conn.execute('CREATE INDEX IF NOT EXISTS history_v27_asset ON asset_history_v27(asset_table,asset_id,id DESC)')
    conn.execute('''CREATE TABLE IF NOT EXISTS asset_lifecycle_v27(
      asset_table TEXT NOT NULL,asset_id INTEGER NOT NULL,purchase_date TEXT DEFAULT '',warranty_end TEXT DEFAULT '',
      support_end TEXT DEFAULT '',next_service TEXT DEFAULT '',retirement_date TEXT DEFAULT '',
      support_vendor TEXT DEFAULT '',contract_number TEXT DEFAULT '',notes TEXT DEFAULT '',reminder_days INTEGER DEFAULT 30,
      PRIMARY KEY(asset_table,asset_id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS user_assets_v27(
      username TEXT NOT NULL,asset_table TEXT NOT NULL,asset_id INTEGER NOT NULL,favorite INTEGER NOT NULL DEFAULT 0,
      visited_at TEXT NOT NULL DEFAULT '',PRIMARY KEY(username,asset_table,asset_id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS user_workspaces_v27(
      username TEXT NOT NULL,path TEXT NOT NULL,label TEXT NOT NULL,visited_at TEXT NOT NULL,
      PRIMARY KEY(username,path))''')
    if 'favorite' not in {r[1] for r in conn.execute('PRAGMA table_info(user_workspaces_v27)')}:
        conn.execute('ALTER TABLE user_workspaces_v27 ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0')
    conn.execute('''CREATE TABLE IF NOT EXISTS redfish_previews_v27(
      token TEXT PRIMARY KEY,username TEXT NOT NULL,asset_table TEXT NOT NULL,asset_id INTEGER NOT NULL,
      before_json TEXT NOT NULL,proposal_json TEXT NOT NULL,observations_json TEXT NOT NULL,expires_at REAL NOT NULL)''')
    for table,spec in db.SCHEMAS.items():
        keys=[f[0] for f in spec['fields']]+['deleted_at']
        def obj(prefix):
            # Keep each json_object call small, including wide Synergy records.
            chunks=[]
            for i in range(0,len(keys),35):
                chunks.append('json_object('+','.join("'"+k.replace("'","''")+"',"+prefix+'."'+k.replace('"','""')+'"' for k in keys[i:i+35])+')')
            out=chunks[0]
            for chunk in chunks[1:]: out=f'json_patch({out},{chunk})'
            return out
        for event,prefix in [('INSERT','NEW'),('UPDATE','NEW'),('DELETE','OLD')]:
            before=obj('OLD') if event!='INSERT' else "'{}'"
            after=obj('NEW') if event!='DELETE' else "'{}'"
            condition=(' WHEN '+ ' OR '.join('OLD."'+k+'" IS NOT NEW."'+k+'"' for k in keys)) if event=='UPDATE' else ''
            conn.execute(f'''CREATE TRIGGER IF NOT EXISTS audit27_{table}_{event} AFTER {event} ON "{table}"{condition}
              BEGIN INSERT INTO asset_history_v27(asset_table,asset_id,kind,actor,before_json,after_json)
              VALUES('{table}',{prefix}.id,'{event.lower()}',audit_actor(),{before},{after}); END''')
    # Power assignments record a genuine before/after change, including disconnects.
    for event,prefix in [('INSERT','NEW'),('UPDATE','NEW'),('DELETE','OLD')]:
        before="json_object('PSU',OLD.psu_index,'UPS',OLD.ups_id)" if event!='INSERT' else "'{}'"
        after="json_object('PSU',NEW.psu_index,'UPS',NEW.ups_id)" if event!='DELETE' else "'{}'"
        condition=' WHEN OLD.ups_id IS NOT NEW.ups_id' if event=='UPDATE' else ''
        conn.execute(f'''CREATE TRIGGER IF NOT EXISTS audit27_power_{event} AFTER {event} ON power_assignments{condition}
          BEGIN INSERT INTO asset_history_v27(asset_table,asset_id,kind,actor,before_json,after_json)
          VALUES({prefix}.asset_table,{prefix}.asset_id,'power_{event.lower()}',audit_actor(),{before},{after}); END''')


def inventory():
    return {(t,int(r['id'])):dict(r) for t in db.SCHEMAS for r in db.list_assets(t)}

def label(key, data):
    row=data.get(key)
    return db.asset_label(key[0],row) if row else f'{key[0]} #{key[1]} (missing)'

def snapshot():
    data=inventory(); cables=defaultdict(list); links=defaultdict(list); power=defaultdict(dict); definitions={}
    with closing(db.get_conn()) as conn:
        for row in conn.execute('SELECT e.*,c.fabric FROM physical_endpoints e LEFT JOIN physical_cables c ON c.id=e.cable_id'):
            cables[row['cable_id']].append(dict(row))
        for row in conn.execute('SELECT * FROM power_assignments'):
            power[(row['asset_table'],row['asset_id'])][row['psu_index']]=row['ups_id']
        custom=defaultdict(list)
        for row in conn.execute('SELECT * FROM physical_ports'):custom[(row['asset_table'],row['asset_id'])].append(dict(row))
    for key,row in data.items():
        try: definitions[key]={n:{'kind':k,'section':s} for n,k,s in pm.defaults(key[0],row)}
        except (ValueError,TypeError):definitions[key]={}
        for port in custom[key]:
            if port['hidden']:definitions[key].pop(port['name'],None)
            else:definitions[key][port['name']]=port
    for cid, ends in cables.items():
        if len(ends)!=2:continue
        for a,b in (ends,ends[::-1]):
            key=(a['asset_table'],a['asset_id']);target=(b['asset_table'],b['asset_id'])
            links[key].append({'port':a['port'],'target':target,'target_port':b['port'],'fabric':a['fabric'] or '',
                'kind':definitions.get(key,{}).get(a['port'],{}).get('kind','Unknown'),'cable_id':cid})
    return dict(data=data,cables=cables,links=links,power=power,definitions=definitions)

def normalize_fabric(value):
    return re.sub(r'[^\w]+','',str(value or '').casefold().replace('fabric',''))

def redundancy(key,snap=None):
    s=snap or snapshot(); row=s['data'].get(key)
    if row is None:raise ValueError('Asset not found')
    result={'key':key,'label':label(key,s['data']),'power':{},'fc':{}}
    if key[0] not in ('servers','storage'):
        result['power']=dict(state='not_applicable',detail='PSU analysis supports server/storage inventory.')
        result['fc']=dict(state='not_applicable',detail='FC analysis supports server/storage inventory.')
        return result
    try:expected=int(row.get('power_count') or 2) if key[0]=='servers' else 2
    except (ValueError,TypeError):expected=0
    assignments=s['power'].get(key,{})
    valid={i:u for i,u in assignments.items() if ('ups',u) in s['data'] and 1<=i<=expected}
    complete=expected>0 and len(valid)==expected
    distinct=set(valid.values())
    if not complete: state='unknown';detail=f'{len(valid)}/{expected} expected PSUs have a valid UPS assignment. Complete the mapping.'
    elif len(distinct)<2:state='shared_risk';detail='All recorded PSUs use one UPS. Independent power sources are not recorded.'
    else:state='recorded_diversity';detail='PSUs use multiple recorded UPS devices. Upstream feeds and PSU load capacity are not verified.'
    result['power']=dict(state=state,detail=detail,expected=expected,mapped=len(valid),ups=sorted(distinct))
    fc=[link for link in s['links'].get(key,[]) if link['kind']=='FC']
    valid_fc=[]; unknown=False; fabrics=set()
    for link in fc:
        target=s['data'].get(link['target'])
        if link['target'][0]!='san_switches' or not target:unknown=True;continue
        cable_fabric=normalize_fabric(link['fabric']);switch_fabric=normalize_fabric(target.get('fabric'))
        if cable_fabric and switch_fabric and cable_fabric!=switch_fabric:unknown=True;continue
        fabric=switch_fabric or cable_fabric
        if not fabric:unknown=True
        else:fabrics.add(fabric)
        valid_fc.append(link)
    switches={l['target'] for l in valid_fc}
    if unknown or not fc: state='unknown';detail='No complete, unambiguous FC/Fabric mapping. Unused ports are not assumed to be required.'
    elif len(valid_fc)>=2 and len(switches)>=2 and len(fabrics)>=2:
        state='recorded_diversity';detail='Recorded FC paths reach different switches and Fabrics. Zoning, target access and multipathing are not verified.'
    else:state='shared_risk';detail='Fewer than two independent switch/Fabric paths are recorded.'
    result['fc']=dict(state=state,detail=detail,paths=len(valid_fc),fabrics=sorted(fabrics),switches=len(switches))
    return result

def impact(key,snap=None):
    s=snap or snapshot()
    if key not in s['data']:raise ValueError('Asset not found')
    affected=[]
    if key[0]=='ups':
        for asset,assignments in s['power'].items():
            if asset not in s['data'] or key[1] not in assignments.values():continue
            r=redundancy(asset,s)['power']; lost=[f'PSU{i}' for i,u in assignments.items() if u==key[1]]
            alternatives=[u for u in r.get('ups',[]) if u!=key[1]]
            state='unknown' if r['state']=='unknown' else ('remaining_recorded_source' if alternatives else 'all_recorded_power_sources_lost')
            affected.append(dict(key=asset,label=label(asset,s['data']),state=state,ports=lost,detail='Recorded PSU-to-UPS links; actual load, upstream power and runtime are not measured.'))
    else:
        peers=defaultdict(list)
        for link in s['links'].get(key,[]):peers[link['target']].append(link)
        for peer,links in peers.items():
            if peer not in s['data']:continue
            kinds={l['kind'] for l in links}
            alternatives=[l for l in s['links'].get(peer,[]) if l['target']!=key and l['target'] in s['data'] and l['kind'] in kinds]
            state='remaining_recorded_path' if alternatives else 'all_recorded_paths_lost'
            affected.append(dict(key=peer,label=label(peer,s['data']),state=state,ports=[l['target_port'] for l in links],detail='Direct recorded connectivity only; end-to-end storage/network service availability is unknown.'))
    return {'key':key,'label':label(key,s['data']),'affected':affected,
        'note':'Simulation of direct recorded dependencies only. Missing links, downstream chains, zoning, VLANs and shared upstream sources can change the real impact.'}

def quality(snap=None):
    s=snap or snapshot();findings=[];serials=defaultdict(set);ips=defaultdict(set)
    def add(key,kind,detail):findings.append(dict(key=key,label=label(key,s['data']),kind=kind,detail=detail))
    for key,row in s['data'].items():
        for field in ('model','serial_number','rack'):
            if field in row and not str(row.get(field) or '').strip():add(key,'incomplete',f'Missing {field}')
        serial=str(row.get('serial_number') or '').strip().casefold()
        if serial and serial not in {'n/a','na','unknown','-'}:serials[serial].add(key)
        for field,value in row.items():
            if ('ip' not in field.lower() or not re.search(r'(^ip\d*$|_ip|ip_addr|ip_address)',field.lower()) or not value):continue
            for item in re.split(r'[,;\s]+',str(value).strip()):
                try:ips[str(ipaddress.ip_address(item.split('/')[0]))].add((key,field))
                except ValueError:add(key,'invalid_ip',f'{field}: {item}')
        mapped={l['port'] for l in s['links'].get(key,[])}
        free=[n for n,p in s['definitions'].get(key,{}).items() if p['kind']!='Power' and n not in mapped]
        if free and key[0] not in ('servers', 'hpe_synergy_servers'):add(key,'unmapped_ports',f'{len(free)} ports have no destination (may be intentionally unused): '+', '.join(free[:12]))
        if key[0] in ('servers','storage'):
            result=redundancy(key,s)
            for kind in ('power','fc'):
                if kind == 'fc' and key[0] == 'servers' and not any(l['kind'] == 'FC' for l in s['links'].get(key, [])):
                    continue
                if result[kind]['state']!='recorded_diversity':add(key,kind+'_'+result[kind]['state'],result[kind]['detail'])
    for value,keys in serials.items():
        if len(keys)>1:
            for key in keys:add(key,'duplicate_serial',f'Serial {value} is shared by '+', '.join(label(k,s['data']) for k in sorted(keys)))
    for value,locations in ips.items():
        if len({k for k,f in locations})>1:
            for key,field in locations:add(key,'duplicate_ip',f'{field}: {value} is used on multiple assets. Verify VLAN/VRF context.')
    for cid,ends in s['cables'].items():
        for a in ends:
            key=(a['asset_table'],a['asset_id'])
            if key not in s['data'] or a['port'] not in s['definitions'].get(key,{}):add(key,'orphan_endpoint',f'Cable #{cid}: missing asset or port {a["port"]}')
        if len(ends)!=2:
            for a in ends:add((a['asset_table'],a['asset_id']),'invalid_cable',f'Cable #{cid} has {len(ends)} endpoints; expected 2.')
        else:
            kinds=[s['definitions'].get((e['asset_table'],e['asset_id']),{}).get(e['port'],{}).get('kind') for e in ends]
            if None not in kinds and not (kinds[0]==kinds[1] or set(kinds)<={'Ethernet','Management'}):
                add((ends[0]['asset_table'],ends[0]['asset_id']),'incompatible_ports',f'Cable #{cid}: {kinds[0]} to {kinds[1]}')
    return findings

def get_lifecycle(key):
    with closing(db.get_conn()) as c:row=c.execute('SELECT * FROM asset_lifecycle_v27 WHERE asset_table=? AND asset_id=?',key).fetchone()
    return dict(row) if row else dict.fromkeys(DATE_FIELDS+('support_vendor','contract_number','notes'),'')|{'reminder_days':30}

def save_lifecycle(key,form,user):
    values={k:str(form.get(k,'')).strip() for k in DATE_FIELDS+('support_vendor','contract_number','notes')}
    for k in DATE_FIELDS:
        if values[k]:values[k]=date.fromisoformat(values[k]).isoformat()
    for k in ('warranty_end','support_end','retirement_date'):
        if values['purchase_date'] and values[k] and values[k]<values['purchase_date']:raise ValueError(k+' must not precede purchase date.')
    if any(len(values[k])>3000 for k in values):raise ValueError('Text is too long (maximum 3000 characters).')
    values['reminder_days']=int(form.get('reminder_days') or 30)
    if not 1<=values['reminder_days']<=365:raise ValueError('Reminder window must be 1 to 365 days.')
    with closing(db.get_conn()) as c,c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT * FROM asset_lifecycle_v27 WHERE asset_table=? AND asset_id=?',key).fetchone()
        before={k:old[k] for k in values} if old else {}
        columns=list(values);updates=','.join(k+'=excluded.'+k for k in columns)
        c.execute('INSERT INTO asset_lifecycle_v27(asset_table,asset_id,'+','.join(columns)+') VALUES('+','.join('?' for _ in range(len(columns)+2))+') ON CONFLICT(asset_table,asset_id) DO UPDATE SET '+updates,(*key,*values.values()))
        record(c,*key,'lifecycle',before,values,user)

def reminders(today=None):
    today=today or date.today();data=inventory();out=[]
    with closing(db.get_conn()) as c:rows=c.execute('SELECT * FROM asset_lifecycle_v27').fetchall()
    for row in rows:
        key=(row['asset_table'],row['asset_id'])
        if key not in data:continue
        for field in DATE_FIELDS[1:]:
            if not row[field]:continue
            days=(date.fromisoformat(row[field])-today).days
            if days<=row['reminder_days']:out.append(dict(key=key,label=label(key,data),field=field,date=row[field],days=days,state='overdue' if days<0 else 'due'))
    return sorted(out,key=lambda x:(x['days'],x['label']))

def history(key,limit=200,before_id=None):
    with closing(db.get_conn()) as c:
        rows=c.execute('SELECT * FROM asset_history_v27 WHERE asset_table=? AND asset_id=? AND id<? ORDER BY id DESC LIMIT ?',(*key,before_id or 2**63-1,limit)).fetchall()
    result=[]
    for r in rows:
        r=dict(r);old=json.loads(r['before_json']);new=json.loads(r['after_json']);r['changes']=[dict(field=k,before=old.get(k,''),after=new.get(k,'')) for k in sorted(set(old)|set(new)) if old.get(k)!=new.get(k) and not (old.get(k) in (None,'') and new.get(k) in (None,''))];result.append(r)
    return result

def assistant_answer(question):
    q=str(question).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹','0123456789'));low=q.lower()
    if not re.search(r'redundan|single.point|افزون|مستقل|قطع|خراب|از مدار|fail|outage|impact',low):return None
    s=snapshot()
    if re.search(r'redundan|single.point|افزون|مستقل',low):
        rows=[redundancy(k,s) for k in s['data'] if k[0] in ('servers','storage')]
        wanted='power' if re.search(r'ups|power|برق|پاور',low) else ('fc' if re.search(r'fc|fabric|san',low) else None)
        text=['Recorded inventory analysis / تحلیل اطلاعات ثبت‌شده:']
        for r in rows[:100]:
            for kind in ([wanted] if wanted else ['power','fc']):text.append(f'{r["key"][0]} #{r["key"][1]} - {r["label"]}: {kind.upper()} = {r[kind]["state"]}. {r[kind]["detail"]}')
        if not rows:text.append('No server/storage records available. / اطلاعاتی ثبت نشده است.')
        if len(rows)>100:text.append('Showing 100 assets. Open Asset Manager > Resilience for the full list.')
    else:
        match=re.search(r'(ups|san\s*switch|sanswitch|network\s*switch|سوئیچ\s*سن|یو\s*پی\s*اس)\s*(?:#|شماره|number)?\s*(\d+)',low)
        if not match:return 'For a precise impact report use the inventory ID: “What if UPS #1 fails?” or “SAN switch #2 outage”. / شناسه تجهیز را وارد کنید: UPS #1'
        kind=match.group(1);table='ups' if kind in ('ups','یو پی اس') or 'یو' in kind else ('network' if kind.startswith('network') else 'san_switches')
        key=(table,int(match.group(2)))
        if key not in s['data']:return 'No matching inventory ID. / تجهیزی با این شناسه یافت نشد.'
        report=impact(key,s);text=[report['label']+' - recorded impact:']
        text += [f'{r["label"]} ({r["key"][0]} #{r["key"][1]}): {r["state"]}; '+', '.join(r['ports']) for r in report['affected']]
        if not report['affected']:text.append('No direct dependencies recorded; this does not prove there is no real impact.')
    text.append('Recorded topology only; live health, missing connections, zoning and upstream independence remain unverified. / این نتیجه تأیید سلامت زنده نیست.')
    return '\n'.join(text)
