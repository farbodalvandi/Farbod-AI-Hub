"""Portable equipment report; embeds fonts and preserves untrusted text as text."""
from io import BytesIO
from pathlib import Path
from datetime import datetime, timezone
from xml.sax.saxutils import escape
import re
import database as db
import asset_intelligence as intelligence
import port_map as pm

def create_report(table,row_id,asset):
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_LEFT
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,KeepTogether
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.pagesizes import A4
    import arabic_reshaper
    from bidi.algorithm import get_display
    root=Path(__file__).parent
    for name,file in [('Farbod','DejaVuSans.ttf'),('FarbodBold','DejaVuSans-Bold.ttf')]:
        if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(root/'fonts'/file)))
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Body27',fontName='Farbod',fontSize=9,leading=14,spaceAfter=7,wordWrap='CJK'))
    styles.add(ParagraphStyle(name='Heading27',fontName='FarbodBold',fontSize=14,leading=19,spaceBefore=16,spaceAfter=9,textColor=colors.HexColor('#20395f'),keepWithNext=True))
    styles.add(ParagraphStyle(name='Event27',parent=styles['Body27'],fontName='FarbodBold',keepWithNext=True,spaceBefore=8))
    styles.add(ParagraphStyle(name='Title27',fontName='FarbodBold',fontSize=23,leading=30,spaceAfter=12,textColor=colors.HexColor('#17375b')))
    def text(value):
        text=str(value if value is not None else '')
        text=''.join(c for c in text if c in '\n\t' or ord(c)>=32)
        lines=text.splitlines() or ['']
        return '<br/>'.join(escape(get_display(arabic_reshaper.reshape(line)) if re.search('[\u0600-\u06ff]',line) else line) for line in lines)
    def para(value,style='Body27'):return Paragraph(text(value),styles[style])
    story=[]
    logo=root/'static/images/farbod-fa-logo.png'
    if logo.exists():
        from PIL import Image as PILImage
        with PILImage.open(logo) as im:w,h=im.size
        story.append(Image(str(logo),width=48,height=48*h/w,hAlign='LEFT'))
    story += [Spacer(1,12),para('Equipment report','Title27'),para(db.asset_label(table,asset),'Heading27'),
        para(f'Farbod AI-Hub v28.1.3 | {table} #{row_id}'),para('Generated '+datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')),
        para('Inventory snapshot, not a live health certificate. Empty values are shown as not recorded.')]
    def section(title):story.append(para(title,'Heading27'))
    def field(name,value):
        story.append(para(str(name).replace('_',' ').title()+': '+(str(value) if value not in (None,'') else 'Not recorded')))
    section('Specifications and location')
    for field_spec in db.SCHEMAS[table]['fields']:
        name=field_spec[0];field(name,asset.get(name))
    section('Physical ports and connections')
    ports=pm.ports(table,row_id);mapping=pm.mappings(table,row_id)
    if not ports:story.append(para('No physical port definitions recorded.'))
    for name,port in ports.items():
        link=mapping.get(name)
        field(name, (f"{link['target_label']} / {link['target_port']} | Fabric: {link['fabric'] or 'not recorded'}" if link else ('See Power / UPS assignments below' if port['kind']=='Power' else 'No destination recorded')))
    if table=='san_switches':
        section('Legacy SAN port notes')
        legacy=db.san_ports_for_switch(row_id)
        if not legacy:story.append(para('No legacy SAN port notes recorded.'))
        for port in legacy:field('FC'+str(port['port_number']),f"{port['destination']} | Fabric: {port['fabric']} | {port['notes']}")
    section('Power / UPS assignments')
    assignments=db.get_power_assignments(table,row_id)
    if not assignments:story.append(para('No UPS assignments recorded.'))
    for psu,assignment in assignments.items():
        ups_id=assignment['ups_id']
        ups=db.get_asset('ups',ups_id)
        field(f'PSU {psu}',db.asset_label('ups',ups) if ups else f'UPS #{ups_id} (missing)')
    if table in ('servers','storage'):
        section('Recorded redundancy')
        result=intelligence.redundancy((table,row_id))
        for kind in ('power','fc'):field(kind,result[kind]['state'].replace('_',' ')+' - '+result[kind]['detail'])
    section('Lifecycle and service dates')
    for name,value in intelligence.get_lifecycle((table,row_id)).items():
        if name not in ('asset_table','asset_id'):field(name,value)
    section('Maintenance records')
    logs=db.list_maintenance_logs(table,row_id)
    if not logs:story.append(para('No maintenance records.'))
    for entry in logs:
        story.append(para(f"{entry['event_date']} | {entry['severity']} | {entry['created_by']}"))
        story.append(para(entry['description']))
    section('Automatic change history - latest 200 events')
    story.append(para('Automatic history begins with version 27. Older maintenance entries are included above. Full history can be paged in the application.'))
    events=intelligence.history((table,row_id),limit=200)
    if not events:story.append(para('No automatic changes recorded.'))
    for event in events:
        story.append(para(f"{event['at']} | {event['kind']} | {event['actor']}",'Event27'))
        for change in event['changes']:
            field(change['field'],f"{change['before']} → {change['after']}")
        story.append(Spacer(1,6))
    stream=BytesIO()
    doc=SimpleDocTemplate(stream,pagesize=A4,leftMargin=44,rightMargin=44,topMargin=40,bottomMargin=48,title=f'Equipment report {table} {row_id}',author='Farbod AI-Hub')
    def footer(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#ced7e3'));canvas.line(44,35,A4[0]-44,35)
        canvas.setFont('Farbod',8);canvas.setFillColor(colors.HexColor('#596a80'));canvas.drawString(44,23,'Farbod AI-Hub | Recorded inventory');canvas.drawRightString(A4[0]-44,23,f'Page {doc.page}');canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return stream.getvalue()
