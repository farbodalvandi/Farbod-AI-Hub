"""Authenticated inventory workflows and per-user Hub shortcuts."""
from contextlib import closing
import secrets
import json
from datetime import datetime, timezone
from io import BytesIO
from urllib.parse import urlsplit, urlencode
import database as db
import asset_intelligence as intelligence
import redfish_inventory as redfish
import automation_center as automation
import operations_v20 as ops20
import paths
from auth import current_user, role_required, login_required
from webcore import request, render_template, redirect, url_for, abort, flash, send_file, session

WORKSPACES={'/dashboard':('Asset Manager','asset_manager'),'/warehouse':('Warehouse','warehouse'),
 '/ai-assistant':('AI Assistant','ai_assistant'),'/raid-calculator':('RAID Calculator',None),
 '/monitoring':('Monitoring','monitoring'),'/knowledge':('Knowledge','knowledge'),
 '/equipment':('Equipment','equipment_profile'),'/operations/digital-twin':('Digital Twin','operations'),'/operations/automation':('Automation Center','operations'),
 '/linux-health':('Linux Health','linux_health'),'/diagram':('Infrastructure Map','asset_manager'),'/backups':('Backup Manager','settings')}

def timestamp():return datetime.now(timezone.utc).isoformat()
def touch_asset(table,row_id):
    user=current_user()
    if not user:return
    with closing(db.get_conn()) as c,c:
        c.execute('INSERT INTO user_assets_v27(username,asset_table,asset_id,visited_at) VALUES(?,?,?,?) ON CONFLICT(username,asset_table,asset_id) DO UPDATE SET visited_at=excluded.visited_at',(user['username'],table,row_id,timestamp()))

def shortcuts(allowed):
    user=current_user();result={'favorites':[],'recent':[],'workspaces':[],'workspace_options':[]}
    if not user:return result
    result['workspace_options']=[{'path':path,'label':spec[0]} for path,spec in WORKSPACES.items() if spec[1] is None or allowed(spec[1])]
    with closing(db.get_conn()) as c:
        if allowed('asset_manager'):
            for favorite,name in ((True,'favorites'),(False,'recent')):
                rows=c.execute('SELECT * FROM user_assets_v27 WHERE username=? '+('AND favorite=1 ' if favorite else "AND visited_at<>'' ")+'ORDER BY visited_at DESC LIMIT 24',(user['username'],)).fetchall()
                for r in rows:
                    if r['asset_table'] not in db.SCHEMAS:continue
                    asset=db.get_asset(r['asset_table'],r['asset_id'])
                    if asset:result[name].append({'label':db.asset_label(r['asset_table'],asset),'url':url_for('asset_detail',table=r['asset_table'],row_id=r['asset_id'])})
                result[name]=result[name][:8]
        for r in c.execute('SELECT * FROM user_workspaces_v27 WHERE username=? ORDER BY visited_at DESC LIMIT 11',(user['username'],)):
            spec=WORKSPACES.get(r['path'])
            if spec and (spec[1] is None or allowed(spec[1])):
                if r['visited_at']:result['workspaces'].append(dict(r))
                if r['favorite']:result['favorites'].append({'label':r['label'],'url':r['path'],'workspace':True})
    return result

def asset_or_404(table,row_id):
    if table not in db.SCHEMAS:abort(404)
    asset=db.get_asset(table,row_id)
    if asset is None:abort(404)
    return asset

def qr_target(table,row_id,base):
    u=urlsplit(base.strip())
    if u.scheme not in ('http','https') or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
        raise ValueError('Use an HTTP(S) origin, e.g. https://192.168.1.20 (no path, password or query).')
    return base.rstrip('/')+url_for('asset_detail',table=table,row_id=row_id)

def register(app,module_required,module_allowed):
    @app.before_request
    def track_workspaces_v27():
        if request.method!='GET' or not current_user():return
        from workspace_navigation import workspace_section
        path={'assets':'/dashboard','warehouse':'/warehouse','ai':'/ai-assistant','raid':'/raid-calculator','monitoring':'/monitoring','knowledge':'/knowledge','equipment':'/equipment','twin':'/operations/digital-twin','linux':'/linux-health','map':'/diagram','backup':'/backups'}.get(workspace_section(request.path))
        spec=WORKSPACES.get(path)
        if spec and (spec[1] is None or module_allowed(spec[1])):
            with closing(db.get_conn()) as c,c:
                c.execute('INSERT INTO user_workspaces_v27(username,path,label,visited_at) VALUES(?,?,?,?) ON CONFLICT(username,path) DO UPDATE SET visited_at=excluded.visited_at',(current_user()['username'],path,spec[0],timestamp()))

    @app.route('/hub-shortcuts/workspaces',methods=['POST'])
    @login_required
    def favorite_workspace():
        path=request.form.get('path','');spec=WORKSPACES.get(path)
        if not spec or (spec[1] and not module_allowed(spec[1])):abort(403)
        favorite=1 if request.form.get('favorite')=='1' else 0
        with closing(db.get_conn()) as c,c:
            c.execute('INSERT INTO user_workspaces_v27(username,path,label,visited_at,favorite) VALUES(?,?,?,?,?) ON CONFLICT(username,path) DO UPDATE SET favorite=excluded.favorite',(current_user()['username'],path,spec[0],'',favorite))
        return redirect(url_for('hardware_hub'))

    @app.route('/asset-tools')
    @module_required('asset_manager')
    def asset_tools():
        s=intelligence.snapshot()
        results=[intelligence.redundancy(key,s) for key in s['data'] if key[0] in ('servers','storage')]
        return render_template('asset_tools.html',view='overview',results=results,reminders=intelligence.reminders())

    @app.route('/operations/automation', methods=['GET', 'POST'])
    @module_required('operations')
    def automation_page():
        state = automation.load(paths)
        if request.method == 'POST':
            if not secrets.compare_digest(request.form.get('csrf', ''), session.get('search_csrf', 'missing')):
                abort(403)
            action = request.form.get('action', '')
            if action == 'run':
                result = automation.run(paths, intelligence.quality,
                    lambda severity, source, title, details, key: ops20.record_event(db, severity, source, title, details, key),
                    actor=current_user()['username'])
                db.log_action(current_user()['username'], 'automation_quality_scan',
                              f"status={result['status']}; findings={result['finding_count']}")
                flash('Inventory quality scan completed.' if result['status'] != 'error' else 'Inventory quality scan failed; see the recent scans table.',
                      'success' if result['status'] != 'error' else 'danger')
            elif action == 'settings':
                if current_user()['role'] not in ('admin', 'manager'):
                    abort(403)
                schedule = request.form.get('schedule', 'daily')
                time_value = request.form.get('time', '')
                try:
                    from datetime import datetime
                    if schedule not in ('daily', 'weekly'):
                        raise ValueError()
                    datetime.strptime(time_value, '%H:%M')
                    weekday = int(request.form.get('weekday', '6'))
                    if not 0 <= weekday <= 6:
                        raise ValueError()
                except (ValueError, TypeError):
                    flash('Choose a valid frequency, weekday, and local time.', 'danger')
                    return redirect(url_for('automation_page'))
                state.update(enabled=request.form.get('enabled') == 'on', schedule=schedule,
                             time=time_value, weekday=weekday)
                automation.save(paths, state)
                db.log_action(current_user()['username'], 'automation_schedule_update',
                              json.dumps({'enabled': state['enabled'], 'schedule': schedule, 'time': time_value, 'weekday': weekday}))
                flash('Automation schedule saved.', 'success')
            else:
                abort(400)
            return redirect(url_for('automation_page'))
        return render_template('automation_center.html', state=state,
                               can_manage=current_user()['role'] in ('admin', 'manager'),
                               weekdays=['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'])

    @app.route('/asset-tools/quality')
    @module_required('asset_manager')
    def asset_quality():
        all_findings = intelligence.quality()
        kind = request.args.get('kind', '')
        findings = [f for f in all_findings if not kind or f['kind'] == kind]
        groups = {}
        for finding in findings:
            key = tuple(finding['key'])
            group = groups.setdefault(key, {'key': key, 'label': finding['label'], 'findings': []})
            group['findings'].append(finding)
        selected = None
        if request.args.get('table'):
            key = (request.args.get('table'), request.args.get('id', type=int))
            if key not in intelligence.inventory():
                abort(404)
            selected = {'key': key, 'label': intelligence.label(key, intelligence.inventory()),
                        'findings': [f for f in findings if tuple(f['key']) == key]}
        return render_template('asset_tools.html', view='quality', findings=findings,
                               groups=list(groups.values()), selected=selected,
                               kinds=sorted({f['kind'] for f in all_findings}), kind=kind)

    @app.route('/asset-tools/impact')
    @module_required('asset_manager')
    def asset_impact():
        s=intelligence.snapshot();key=(request.args.get('table','ups'),request.args.get('id',type=int) or 0)
        report=intelligence.impact(key,s) if key in s['data'] else None
        options=[{'table':k[0],'id':k[1],'label':intelligence.label(k,s['data'])} for k in s['data'] if k[0] in ('ups','san_switches','network')]
        return render_template('asset_tools.html',view='impact',report=report,options=options,selected=key)

    @app.route('/asset-tools/search')
    @module_required('asset_manager')
    def hub_search():
        query=request.args.get('q','').strip()[:150];results=[]
        if query:
            for key,row in intelligence.inventory().items():
                if query.casefold() in ' '.join(str(v or '') for v in row.values()).casefold():
                    results.append({'key':key,'label':intelligence.label(key,{key:row}),'serial':row.get('serial_number',''),'model':row.get('model','')})
                    if len(results)>=100:break
        return render_template('asset_tools.html',view='search',query=query,results=results)

    @app.route('/asset-tools/<table>/<int:row_id>',methods=['GET','POST'])
    @module_required('asset_manager')
    def asset_workspace(table,row_id):
        asset=asset_or_404(table,row_id);key=(table,row_id)
        if request.method=='POST':
            if db.ROLE_LEVEL.get(current_user()['role'],0)<2:abort(403)
            try:intelligence.save_lifecycle(key,request.form,current_user()['username']);flash('Lifecycle saved.','success');return redirect(url_for('asset_workspace',table=table,row_id=row_id))
            except (ValueError,TypeError) as e:flash(str(e),'danger')
        with closing(db.get_conn()) as c:
            fav=c.execute('SELECT favorite FROM user_assets_v27 WHERE username=? AND asset_table=? AND asset_id=?',(current_user()['username'],*key)).fetchone()
        cursor=request.args.get('before',type=int)
        events=intelligence.history(key,limit=50,before_id=cursor)
        base=request.args.get('base','') or str(request._r().base_url).rstrip('/')
        qr_url=None
        try:qr_url=qr_target(table,row_id,base)
        except ValueError as e:flash(str(e),'danger')
        return render_template('asset_workspace.html',table=table,row_id=row_id,asset=asset,asset_label=db.asset_label(table,asset),
          lifecycle=intelligence.get_lifecycle(key),date_fields=intelligence.DATE_FIELDS,events=events,
          favorite=bool(fav and fav['favorite']),base=base,qr_url=qr_url,
          qr_image=url_for('asset_qr',table=table,row_id=row_id)+'?'+urlencode({'base':base}),
          redundancy=intelligence.redundancy(key) if table in ('servers','storage') else None)

    @app.route('/asset-tools/<table>/<int:row_id>/favorite',methods=['POST'])
    @module_required('asset_manager')
    def favorite_asset(table,row_id):
        asset_or_404(table,row_id)
        favorite=1 if request.form.get('favorite')=='1' else 0
        with closing(db.get_conn()) as c,c:
            c.execute('INSERT INTO user_assets_v27(username,asset_table,asset_id,favorite) VALUES(?,?,?,?) ON CONFLICT(username,asset_table,asset_id) DO UPDATE SET favorite=excluded.favorite',(current_user()['username'],table,row_id,favorite))
        return redirect(url_for('asset_workspace',table=table,row_id=row_id))

    @app.route('/asset-tools/<table>/<int:row_id>/report.pdf')
    @module_required('asset_manager')
    def asset_pdf(table,row_id):
        asset=asset_or_404(table,row_id)
        from asset_reports import create_report
        return send_file(BytesIO(create_report(table,row_id,dict(asset))),mimetype='application/pdf',as_attachment=True,download_name=f'Farbod-{table}-{row_id}.pdf')

    @app.route('/asset-tools/<table>/<int:row_id>/qr.png')
    @module_required('asset_manager')
    def asset_qr(table,row_id):
        asset_or_404(table,row_id)
        try:target=qr_target(table,row_id,request.args.get('base',''))
        except ValueError:abort(400)
        import qrcode
        image=qrcode.make(target);stream=BytesIO();image.save(stream,format='PNG');stream.seek(0)
        return send_file(stream,mimetype='image/png',as_attachment=False,download_name=f'{table}-{row_id}-qr.png')

    @app.route('/asset-tools/servers/<int:row_id>/redfish',methods=['GET','POST'])
    @module_required('asset_manager')
    @role_required('editor')
    def redfish_read(row_id):
        asset=asset_or_404('servers',row_id);systems=[];preview=None;error=''
        ip=request.form.get('ip','') if request.method=='POST' else asset['ilo_ip'] or ''
        if request.method=='POST':
            try:
                result=redfish.fetch(ip,request.form.get('username',''),request.form.get('password',''),verify=request.form.get('verify')=='1',system_path=request.form.get('system_path',''))
                systems=result['systems']
                if result['fields']:
                    token=redfish.preview(row_id,current_user()['username'],result)
                    preview=redfish.load_preview(token,current_user()['username'])
            except (ValueError,TypeError,KeyError) as e:error=str(e)
        return render_template('redfish_preview.html',asset=asset,row_id=row_id,ip=ip,systems=systems,preview=preview,error=error)

    @app.route('/asset-tools/redfish/apply',methods=['POST'])
    @module_required('asset_manager')
    @role_required('editor')
    def redfish_apply():
        try:
            row_id=redfish.apply(request.form.get('token',''),current_user()['username'],request.form.getlist('fields'))
            flash('Selected Redfish fields saved. Change history updated.','success')
            return redirect(url_for('asset_workspace',table='servers',row_id=row_id))
        except ValueError as e:
            flash(str(e),'danger');return redirect(url_for('asset_tools'))
