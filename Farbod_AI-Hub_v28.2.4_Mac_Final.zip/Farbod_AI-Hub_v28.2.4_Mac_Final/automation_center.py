"""Scheduled, read-only inventory quality automation for Farbod AI-Hub."""
import json
import os
import threading
from datetime import datetime

_LOCK = threading.RLock()
_THREAD_STARTED = False


def _path(paths):
    return os.path.join(paths.runtime_dir(), "automation-center.json")


def _default():
    return {"enabled": False, "schedule": "daily", "time": "02:00", "weekday": 6,
            "last_run_at": "", "last_scheduled_key": "", "runs": []}


def load(paths):
    data = _default()
    try:
        with open(_path(paths), encoding="utf-8") as stream:
            saved = json.load(stream)
        if isinstance(saved, dict):
            data.update({k: saved[k] for k in data if k in saved})
    except (OSError, ValueError, TypeError):
        pass
    return data


def save(paths, data):
    target = _path(paths)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    temporary = target + ".tmp"
    with open(temporary, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, target)


def run(paths, quality_fn, event_fn, actor="system", scheduled=False):
    with _LOCK:
        state = load(paths)
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        try:
            findings = quality_fn()
            counts = {}
            for item in findings:
                key = str(item.get("kind") or "other")
                counts[key] = counts.get(key, 0) + 1
            result = {"at": now, "actor": actor, "scheduled": bool(scheduled),
                      "status": "attention" if findings else "clear",
                      "finding_count": len(findings), "counts": counts,
                      "findings": findings[:25]}
            event_fn("warning" if findings else "info", "Inventory Automation",
                     "Scheduled quality scan" if scheduled else "Manual quality scan",
                     f"{len(findings)} findings across inventory records", "automation:quality")
        except Exception as exc:
            result = {"at": now, "actor": actor, "scheduled": bool(scheduled),
                      "status": "error", "finding_count": 0, "counts": {}, "findings": [],
                      "error": str(exc)[:500]}
            event_fn("critical", "Inventory Automation", "Quality scan failed", str(exc)[:500], "automation:quality")
        state["last_run_at"] = now
        state["runs"] = [result] + list(state.get("runs") or [])[:19]
        if scheduled:
            state["last_scheduled_key"] = datetime.now().astimezone().strftime("%Y-%m-%d")
        save(paths, state)
        return result


def _due(state, now):
    if not state.get("enabled"):
        return False
    try:
        hour, minute = map(int, str(state.get("time", "02:00")).split(":"))
        weekday = int(state.get("weekday", 6))
    except (ValueError, TypeError):
        return False
    local = now.astimezone()
    if local.strftime("%H:%M") < f"{hour:02d}:{minute:02d}":
        return False
    if state.get("last_scheduled_key") == local.strftime("%Y-%m-%d"):
        return False
    schedule = state.get("schedule")
    return schedule == "daily" or (schedule == "weekly" and local.weekday() == weekday)


def start(paths, quality_fn, event_fn):
    global _THREAD_STARTED
    with _LOCK:
        if _THREAD_STARTED:
            return
        _THREAD_STARTED = True

    def loop():
        import time
        while True:
            try:
                state = load(paths)
                now = datetime.now().astimezone()
                if _due(state, now):
                    run(paths, quality_fn, event_fn, scheduled=True)
            except Exception:
                pass
            time.sleep(30)

    threading.Thread(target=loop, name="fhw-inventory-automation", daemon=True).start()
