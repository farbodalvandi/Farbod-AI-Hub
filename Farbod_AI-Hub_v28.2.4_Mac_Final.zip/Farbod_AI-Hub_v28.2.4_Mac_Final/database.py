# -*- coding: utf-8 -*-
"""
Database layer for Farbod AI-Hub - Enterprise Web Edition.

Design goals:
- Pure sqlite3 (stdlib) -> zero external DB server, tiny footprint, easy to
  back up (single file). Can be pointed at a network share if a shared
  multi-user file is desired, or swapped for another DB later since all
  access goes through this module.
- Every "enum-like" field (Manufacturer, Status, Data Center, ...) is backed
  by a `lookups` table so values are editable/addable from the UI (dropdown
  + manage) instead of being hard coded.
- `asset_links` implements a generic graph: any asset (or sub-object) can be
  linked to any other asset/sub-object with a relationship type and label,
  which is what the Diagram view (Jira Assets / Insight style) renders.
- `sub_objects` lets an asset have child components (e.g. a Server's NICs,
  a Storage array's disk shelves) that can themselves be linked/diagrammed.
"""

import os
import json
import sqlite3
import re
import secrets
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash

import paths


def _hash_password(password):
    return generate_password_hash(password, method="scrypt")

BASE_DIR = paths.data_dir()
DB_FILE = os.path.join(BASE_DIR, "instance", "dcam.db")

# ---------------------------------------------------------------------------
# Asset schemas (kept compatible with the original desktop tool's fields)
# Each field tuple: (key, label, type, dropdown_lookup_key_or_None)
# ---------------------------------------------------------------------------
SCHEMAS = {
    "servers": {
        "label": "Servers",
        "icon": "bi-server",
        "fields": [
            ("manufacturer", "Manufacturer", "text", "manufacturer"),
            ("model", "Model", "text", None),
            ("serial_number", "Serial Number", "text", None),
            ("asset_tag", "Asset Tag", "text", None),
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack", "Rack", "text", "rack"),
            ("u_position", "U Position", "text", None),
            ("cpu", "CPU", "text", None),
            ("ram", "Memory", "text", None),
            ("power_count", "Power supply count (1–12)", "number", None),
            ("disk", "Disk", "text", None),
            ("ETH Port1", "ETH Port1", "text", None),
            ("ETH Port2", "ETH Port2", "text", None),
            ("ETH Port3", "ETH Port3", "text", None),
            ("ETH Port4", "ETH Port4", "text", None),
            ("HBA1 Port1", "HBA1 Port1", "text", None),
            ("HBA1 Port2", "HBA1 Port2", "text", None),
            ("HBA2 Port1", "HBA2 Port1", "text", None),
            ("HBA2 Port2", "HBA2 Port2", "text", None),
            ("network_port1", "Network Port 1", "text", None),
            ("network_port2", "Network Port 2", "text", None),
            ("network_port3", "Network Port 3", "text", None),
            ("network_port4", "Network Port 4", "text", None),
            ("firmware", "Firmware", "text", None),
            ("ilo_ip", "iLO / iDRAC IP", "text", None),
            ("first_ip_addr", "First IP Addr", "text", None),
            ("private_ip_addr_1", "Private IP Addr 1", "text", None),
            ("private_ip_addr_2", "Private IP Addr 2", "text", None),
            ("os", "Operating System", "text", "os"),
            ("hypervisor", "Hypervisor", "text", "hypervisor"),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "hpe_synergy_servers": {
        "label": "HPE Synergy Servers",
        "icon": "bi-server",
        "fields": [
            ("chassis_serial_number", "Chassis Serial Number", "text", None),
            ("ip1", "IP1", "text", None),
            ("ip2", "IP2", "text", None),
            ("ip3", "IP3", "text", None),
            ('compute_1_server_ip', 'Compute Module 1 - Server IP', 'text', None),
            ('compute_1_serial_number', 'Compute Module 1 - Serial Number', 'text', None),
            ('compute_1_hdd', 'Compute Module 1 - HDD', 'text', None),
            ('compute_1_notes', 'Compute Module 1 - Notes', 'textarea', None),
            ('compute_2_server_ip', 'Compute Module 2 - Server IP', 'text', None),
            ('compute_2_serial_number', 'Compute Module 2 - Serial Number', 'text', None),
            ('compute_2_hdd', 'Compute Module 2 - HDD', 'text', None),
            ('compute_2_notes', 'Compute Module 2 - Notes', 'textarea', None),
            ('compute_3_server_ip', 'Compute Module 3 - Server IP', 'text', None),
            ('compute_3_serial_number', 'Compute Module 3 - Serial Number', 'text', None),
            ('compute_3_hdd', 'Compute Module 3 - HDD', 'text', None),
            ('compute_3_notes', 'Compute Module 3 - Notes', 'textarea', None),
            ('compute_4_server_ip', 'Compute Module 4 - Server IP', 'text', None),
            ('compute_4_serial_number', 'Compute Module 4 - Serial Number', 'text', None),
            ('compute_4_hdd', 'Compute Module 4 - HDD', 'text', None),
            ('compute_4_notes', 'Compute Module 4 - Notes', 'textarea', None),
            ('compute_5_server_ip', 'Compute Module 5 - Server IP', 'text', None),
            ('compute_5_serial_number', 'Compute Module 5 - Serial Number', 'text', None),
            ('compute_5_hdd', 'Compute Module 5 - HDD', 'text', None),
            ('compute_5_notes', 'Compute Module 5 - Notes', 'textarea', None),
            ('compute_6_server_ip', 'Compute Module 6 - Server IP', 'text', None),
            ('compute_6_serial_number', 'Compute Module 6 - Serial Number', 'text', None),
            ('compute_6_hdd', 'Compute Module 6 - HDD', 'text', None),
            ('compute_6_notes', 'Compute Module 6 - Notes', 'textarea', None),
            ('compute_7_server_ip', 'Compute Module 7 - Server IP', 'text', None),
            ('compute_7_serial_number', 'Compute Module 7 - Serial Number', 'text', None),
            ('compute_7_hdd', 'Compute Module 7 - HDD', 'text', None),
            ('compute_7_notes', 'Compute Module 7 - Notes', 'textarea', None),
            ('compute_8_server_ip', 'Compute Module 8 - Server IP', 'text', None),
            ('compute_8_serial_number', 'Compute Module 8 - Serial Number', 'text', None),
            ('compute_8_hdd', 'Compute Module 8 - HDD', 'text', None),
            ('compute_8_notes', 'Compute Module 8 - Notes', 'textarea', None),
            ('compute_9_server_ip', 'Compute Module 9 - Server IP', 'text', None),
            ('compute_9_serial_number', 'Compute Module 9 - Serial Number', 'text', None),
            ('compute_9_hdd', 'Compute Module 9 - HDD', 'text', None),
            ('compute_9_notes', 'Compute Module 9 - Notes', 'textarea', None),
            ('compute_10_server_ip', 'Compute Module 10 - Server IP', 'text', None),
            ('compute_10_serial_number', 'Compute Module 10 - Serial Number', 'text', None),
            ('compute_10_hdd', 'Compute Module 10 - HDD', 'text', None),
            ('compute_10_notes', 'Compute Module 10 - Notes', 'textarea', None),
            ('compute_11_server_ip', 'Compute Module 11 - Server IP', 'text', None),
            ('compute_11_serial_number', 'Compute Module 11 - Serial Number', 'text', None),
            ('compute_11_hdd', 'Compute Module 11 - HDD', 'text', None),
            ('compute_11_notes', 'Compute Module 11 - Notes', 'textarea', None),
            ('compute_12_server_ip', 'Compute Module 12 - Server IP', 'text', None),
            ('compute_12_serial_number', 'Compute Module 12 - Serial Number', 'text', None),
            ('compute_12_hdd', 'Compute Module 12 - HDD', 'text', None),
            ('compute_12_notes', 'Compute Module 12 - Notes', 'textarea', None),
            ('icb_1_notes', 'ICB1 - Notes', 'textarea', None),
            ('icb_2_notes', 'ICB2 - Notes', 'textarea', None),
            ('icb_3_notes', 'ICB3 - Notes', 'textarea', None),
            ('icb_4_notes', 'ICB4 - Notes', 'textarea', None),
            ('icb_5_notes', 'ICB5 - Notes', 'textarea', None),
            ('icb_6_notes', 'ICB6 - Notes', 'textarea', None),
        ],
    },
    "storage": {
        "label": "Storage",
        "icon": "bi-hdd-rack",
        "fields": [
            ("manufacturer", "Manufacturer", "text", "manufacturer"),
            ("model", "Model", "text", None),
            ("serial_number", "Serial Number", "text", None),
            ("asset_tag", "Asset Tag", "text", None),
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack", "Rack", "text", "rack"),
            ("u_position", "U Position", "text", None),
            ("rack_units", "Unit (U)", "text", None),
            ("controller", "Controller", "text", None),
            ("SPA_PORT_0", "SPA PORT 0", "text", None),
            ("SPA_PORT_1", "SPA PORT 1", "text", None),
            ("SPA_PORT_2", "SPA PORT 2", "text", None),
            ("SPA_PORT_3", "SPA PORT 3", "text", None),
            ("SPB_PORT_0", "SPB PORT 0", "text", None),
            ("SPB_PORT_1", "SPB PORT 1", "text", None),
            ("SPB_PORT_2", "SPB PORT 2", "text", None),
            ("SPB_PORT_3", "SPB PORT 3", "text", None),
            ("pool", "Pool", "text", None),
            ("management_ip", "Management IP", "text", None),
            ("firmware", "Firmware / OE", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "san_switches": {
        "label": "SAN Switches",
        "icon": "bi-diagram-3",
        "fields": [
            ("manufacturer", "Manufacturer", "text", "manufacturer"),
            ("model", "Model", "text", None),
            ("serial_number", "Serial Number", "text", None),
            ("asset_tag", "Asset Tag", "text", None),
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack", "Rack", "text", "rack"),
            ("wwn", "WWN", "text", None),
            ("fc_ports", "FC Ports", "text", None),
            ("port_count", "Port Count (1–256)", "text", None),
            ("fabric", "Fabric", "text", "fabric"),
            ("management_ip", "Management IP", "text", None),
            ("firmware", "Firmware", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "network": {
        "label": "Network Devices",
        "icon": "bi-router",
        "fields": [
            ("device_type", "Device Type", "text", "device_type"),
            ("manufacturer", "Manufacturer", "text", "manufacturer"),
            ("model", "Model", "text", None),
            ("serial_number", "Serial Number", "text", None),
            ("asset_tag", "Asset Tag", "text", None),
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack", "Rack", "text", "rack"),
            ("port_count", "Port Count (1–256)", "number", None),
            ("management_ip", "Management IP", "text", None),
            ("vlan", "VLAN", "text", None),
            ("firmware", "Firmware", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "ups": {
        "label": "UPS",
        "icon": "bi-battery-charging",
        "fields": [
            ("manufacturer", "Manufacturer", "text", "manufacturer"),
            ("model", "Model", "text", None),
            ("serial_number", "Serial Number", "text", None),
            ("asset_tag", "Asset Tag", "text", None),
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack", "Rack", "text", "rack"),
            ("u_position", "U Position", "text", None),
            ("capacity_va", "Capacity (VA)", "number", None),
            ("capacity_w", "Capacity (W)", "number", None),
            ("topology", "Topology", "text", "ups_topology"),
            ("input_voltage", "Input voltage (V)", "text", None),
            ("output_voltage", "Output voltage (V)", "text", None),
            ("battery_type", "Battery type", "text", None),
            ("battery_install_date", "Battery installation date", "date", None),
            ("runtime_minutes", "Estimated runtime (minutes)", "number", None),
            ("management_ip", "Management IP", "text", None),
            ("firmware", "Firmware", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "racks": {
        "label": "Racks",
        "icon": "bi-inboxes",
        "fields": [
            ("datacenter", "Data Center", "text", "datacenter"),
            ("room", "Room", "text", "room"),
            ("rack_number", "Rack Number", "text", None),
            ("rack_name", "Rack Name", "text", None),
            ("rack_size_u", "Rack Size (U)", "text", None),
            ("power", "Power", "text", None),
            ("notes", "Notes", "textarea", None),
        ],
    },
    "cables": {
        "label": "Cables",
        "icon": "bi-plug",
        "fields": [
            ("cable_type", "Cable Type", "text", "cable_type"),
            ("source_device", "Source Device", "text", None),
            ("source_port", "Source Port", "text", None),
            ("destination_device", "Destination Device", "text", None),
            ("destination_port", "Destination Port", "text", None),
            ("cable_label", "Cable Label", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },

    "esxi_hosts": {
        "label": "ESXi Hosts",
        "icon": "bi-cpu",
        "fields": [
            ("hostname", "Hostname", "text", None),
            ("cluster_name", "Cluster", "text", None),
            ("server_serial", "Server Serial", "text", None),
            ("management_ip", "Management IP", "text", None),
            ("esxi_version", "ESXi Version", "text", None),
            ("status", "Status", "text", "status"),
            ("notes", "Notes", "textarea", None),
        ],
    },


}

# Owner is a built-in field for every equipment category.
for _spec in SCHEMAS.values():
    _spec["fields"].insert(4, ("owner", "Owner", "text", None))
BASE_SCHEMAS = SCHEMAS

# Default seed values for dropdown lookups (all editable later in the UI)
DEFAULT_LOOKUPS = {
    "manufacturer": ["HPE", "DellEMC", "Cisco", "NetApp", "IBM", "Huawei", "Lenovo"],
    "status": ["Active", "Standby", "Maintenance", "Decommissioned", "Faulty", "Healthy", "Resolved"],
    "datacenter": ["DC-1", "DC-2"],
    "room": ["Room-101", "Room-102"],
    "rack": [],
    "os": ["Windows Server 2022", "RHEL 9", "Ubuntu 22.04", "ESXi 8.0"],
    "hypervisor": ["VMware ESXi", "Hyper-V", "KVM", "None"],
    "device_type": ["Switch", "Router", "Firewall", "Load Balancer"],
    "cable_type": ["Fiber LC-LC", "Fiber SC-LC", "Copper Cat6", "DAC"],
    "fabric": ["Fabric-A", "Fabric-B"],
    "ups_topology": ["Online", "Line-interactive", "Standby / Offline"],
}

ROLES = ["admin", "manager", "operator"]
ROLE_LEVEL = {"operator": 0, "manager": 2, "admin": 3, "editor": 2}


def get_conn():
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    conn = sqlite3.connect(DB_FILE, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA journal_mode = WAL")
    from asset_intelligence import actor
    conn.create_function('audit_actor',0,actor)
    return conn



from collections.abc import Mapping

class AssetSchemas(Mapping):
    """Read field definitions from SQLite so all workers see committed changes."""
    def __iter__(self):
        return iter(BASE_SCHEMAS)
    def __len__(self):
        return len(BASE_SCHEMAS)
    def __contains__(self, key):
        return key in BASE_SCHEMAS
    def __getitem__(self, key):
        base = BASE_SCHEMAS[key]
        fields = list(base["fields"])
        if os.path.exists(DB_FILE):
            conn = get_conn()
            try:
                if conn.execute("SELECT 1 FROM sqlite_master WHERE name='asset_custom_fields'").fetchone():
                    fields.extend((r["field_key"], r["label"], r["field_type"], None)
                        for r in conn.execute("SELECT * FROM asset_custom_fields WHERE asset_table=? AND active=1 ORDER BY id", (key,)))
            finally:
                conn.close()
        return dict(base, fields=fields)

SCHEMAS = AssetSchemas()

def custom_fields(table):
    if table not in BASE_SCHEMAS:
        raise ValueError("Unknown equipment category.")
    conn = get_conn()
    try:
        return conn.execute("SELECT * FROM asset_custom_fields WHERE asset_table=? AND active=1 ORDER BY id", (table,)).fetchall()
    finally:
        conn.close()

def add_custom_field(table, label, field_type, username):
    if table not in BASE_SCHEMAS:
        raise ValueError("Unknown equipment category.")
    label = label.strip()
    if not label or len(label) > 80 or any(ord(c) < 32 for c in label):
        raise ValueError("Enter a column name of 1–80 characters.")
    if field_type not in ("text", "textarea", "number", "date"):
        raise ValueError("Unsupported field type.")
    conn = get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE")
        labels = [f[1].casefold() for f in BASE_SCHEMAS[table]["fields"]]
        labels += [r[0].casefold() for r in conn.execute("SELECT label FROM asset_custom_fields WHERE asset_table=? AND active=1", (table,))]
        if label.casefold() in labels:
            raise ValueError("A column with this name already exists.")
        if conn.execute("SELECT count(*) FROM asset_custom_fields WHERE asset_table=?", (table,)).fetchone()[0] >= 100:
            raise ValueError("This category has reached its limit of 100 custom columns.")
        key = "custom_" + secrets.token_hex(10)
        conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{key}" TEXT')
        conn.execute("INSERT INTO asset_custom_fields(asset_table,field_key,label,field_type,active) VALUES(?,?,?,?,1)", (table,key,label,field_type))
        conn.commit()
    finally:
        conn.close()
    log_action(username, "custom_field_add", f"{table}: {label}")
    return key

def remove_custom_field(table, key, username):
    if table not in BASE_SCHEMAS:
        raise ValueError("Unknown equipment category.")
    conn = get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM asset_custom_fields WHERE asset_table=? AND field_key=? AND active=1", (table,key)).fetchone()
        if not row:
            raise ValueError("Only active custom columns can be removed.")
        # Retain underlying values for backups and historical records.
        conn.execute("UPDATE asset_custom_fields SET active=0 WHERE id=?", (row["id"],))
        conn.commit()
    finally:
        conn.close()
    log_action(username, "custom_field_remove", f"{table}: {row['label']}")


def init_db():
    first_run = not os.path.exists(DB_FILE)
    conn = get_conn()
    conn.execute("BEGIN IMMEDIATE")
    cur = conn.cursor()
    from warehouse import ensure_schema
    ensure_schema(conn)
    from port_map import ensure_schema as ensure_port_schema
    ensure_port_schema(conn)
    cur.execute('''CREATE TABLE IF NOT EXISTS asset_maintenance_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_table TEXT NOT NULL, asset_id INTEGER NOT NULL,
        event_date TEXT NOT NULL, description TEXT NOT NULL,
        severity TEXT NOT NULL CHECK(severity IN ('yellow','orange','red')),
        created_by TEXT NOT NULL, created_at TEXT NOT NULL
    )''')
    # Expand the legacy CHECK constraint atomically without losing repair history.
    schema = cur.execute("SELECT sql FROM sqlite_master WHERE name='asset_maintenance_logs'").fetchone()[0]
    if "'green'" not in schema:
        cur.execute("ALTER TABLE asset_maintenance_logs RENAME TO asset_maintenance_logs_old")
        cur.execute("""CREATE TABLE asset_maintenance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_table TEXT NOT NULL, asset_id INTEGER NOT NULL,
            event_date TEXT NOT NULL, description TEXT NOT NULL,
            severity TEXT NOT NULL CHECK(severity IN ('yellow','orange','red','green','change')),
            created_by TEXT NOT NULL, created_at TEXT NOT NULL)""")
        cur.execute("INSERT INTO asset_maintenance_logs SELECT * FROM asset_maintenance_logs_old")
        cur.execute("DROP TABLE asset_maintenance_logs_old")
    cur.execute('CREATE INDEX IF NOT EXISTS idx_asset_maintenance ON asset_maintenance_logs(asset_table, asset_id, event_date DESC, id DESC)')
    cur.execute("CREATE TABLE IF NOT EXISTS power_assignments (asset_table TEXT NOT NULL CHECK(asset_table IN ('servers','storage')), asset_id INTEGER NOT NULL, psu_index INTEGER NOT NULL CHECK(psu_index BETWEEN 1 AND 12), ups_id INTEGER NOT NULL, updated_by TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL, PRIMARY KEY(asset_table,asset_id,psu_index))")
    cur.execute('CREATE INDEX IF NOT EXISTS idx_power_assignments_ups ON power_assignments(ups_id)')
    cur.execute('''CREATE TABLE IF NOT EXISTS san_port_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        switch_id INTEGER NOT NULL,
        port_number INTEGER NOT NULL,
        destination TEXT NOT NULL DEFAULT '',
        fabric TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        updated_by TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        UNIQUE(switch_id, port_number)
    )''')

    cur.execute("""CREATE TABLE IF NOT EXISTS asset_custom_fields (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_table TEXT NOT NULL, field_key TEXT NOT NULL,
        label TEXT NOT NULL, field_type TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        UNIQUE(asset_table,field_key))""")
    for table, spec in BASE_SCHEMAS.items():
        cols = ", ".join(f'"{f[0]}" TEXT' for f in spec["fields"])
        cur.execute(f'''
            CREATE TABLE IF NOT EXISTS "{table}" (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                {cols},
                created_at TEXT,
                updated_at TEXT
            )
        ''')

        # Migrate databases created by older builds.  CREATE TABLE IF NOT EXISTS
        # does not add new columns, which previously caused 500 errors when an
        # existing database was opened by a newer EXE.
        existing = {row[1] for row in cur.execute(f'PRAGMA table_info("{table}")').fetchall()}
        for field_key, _label, _ftype, _lookup in spec["fields"]:
            if field_key not in existing:
                cur.execute(f'ALTER TABLE "{table}" ADD COLUMN "{field_key}" TEXT')
        existing = {row[1] for row in cur.execute(f'PRAGMA table_info("{table}")').fetchall()}
        if "created_at" not in existing:
            cur.execute(f'ALTER TABLE "{table}" ADD COLUMN created_at TEXT')
        if "updated_at" not in existing:
            cur.execute(f'ALTER TABLE "{table}" ADD COLUMN updated_at TEXT')
        if "deleted_at" not in existing:
            cur.execute(f'ALTER TABLE "{table}" ADD COLUMN deleted_at TEXT')

    # Convert v26.1.0 outlet-level PSU-to-UPS cables to model-level assignments.
    cur.execute("""INSERT OR IGNORE INTO power_assignments(asset_table,asset_id,psu_index,ups_id,updated_by,updated_at)
        SELECT a.asset_table,a.asset_id,CAST(substr(a.port,4) AS INTEGER),b.asset_id,c.updated_by,c.updated_at
        FROM physical_endpoints a JOIN physical_cables c ON c.id=a.cable_id
        JOIN physical_endpoints b ON b.cable_id=a.cable_id AND b.asset_table='ups'
        WHERE a.asset_table IN ('servers','storage') AND a.port GLOB 'PSU[0-9]*'
          AND CAST(substr(a.port,4) AS INTEGER) BETWEEN 1 AND 12""")

    cur.execute('''
        CREATE TABLE IF NOT EXISTS lookups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            field_key TEXT NOT NULL,
            value TEXT NOT NULL,
            sort_order INTEGER DEFAULT 0,
            UNIQUE(field_key, value)
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS sub_objects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_table TEXT NOT NULL,
            parent_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            obj_type TEXT,
            notes TEXT,
            created_at TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS asset_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_table TEXT NOT NULL,
            source_id INTEGER NOT NULL,
            target_table TEXT NOT NULL,
            target_id INTEGER NOT NULL,
            link_type TEXT DEFAULT 'connected to',
            label TEXT,
            notes TEXT,
            created_by TEXT,
            created_at TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS diagram_positions (
            node_key TEXT PRIMARY KEY,
            x REAL,
            y REAL
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            role TEXT NOT NULL DEFAULT 'viewer',
            active INTEGER DEFAULT 1,
            created_at TEXT
        )
    ''')

    # v24.6: optional profile image filename. Existing installations migrate in place.
    user_cols = {r[1] for r in cur.execute('PRAGMA table_info("users")').fetchall()}
    if "avatar_filename" not in user_cols:
        cur.execute("ALTER TABLE users ADD COLUMN avatar_filename TEXT")

    cur.execute('''
        CREATE TABLE IF NOT EXISTS module_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_key TEXT NOT NULL,
            username TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            active INTEGER DEFAULT 1,
            created_at TEXT
        )
    ''')

    # Upgrade old single-user-per-module schema by rebuilding it without UNIQUE(module_key).
    idxs = cur.execute("PRAGMA index_list(module_users)").fetchall()
    if any(i[2] and [r[2] for r in cur.execute(f'PRAGMA index_info("{i[1]}")').fetchall()] == ["module_key"] for i in idxs):
        cur.execute("ALTER TABLE module_users RENAME TO module_users_old")
        cur.execute("CREATE TABLE module_users (id INTEGER PRIMARY KEY AUTOINCREMENT, module_key TEXT NOT NULL, username TEXT NOT NULL, password_hash TEXT NOT NULL, active INTEGER DEFAULT 1, created_at TEXT, UNIQUE(module_key, username))")
        cur.execute("INSERT INTO module_users SELECT id,module_key,username,password_hash,active,created_at FROM module_users_old")
        cur.execute("DROP TABLE module_users_old")

    cur.execute('''
        CREATE TABLE IF NOT EXISTS equipment_banks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            created_at TEXT
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS equipment_bank_subcategories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bank_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            created_at TEXT,
            UNIQUE(bank_id, name),
            FOREIGN KEY(bank_id) REFERENCES equipment_banks(id) ON DELETE CASCADE
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS equipment_bank_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subcategory_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            media_type TEXT NOT NULL,
            size_bytes INTEGER,
            uploaded_by TEXT,
            created_at TEXT,
            FOREIGN KEY(subcategory_id) REFERENCES equipment_bank_subcategories(id) ON DELETE CASCADE
        )
    ''')
    equipment_file_cols = {r[1] for r in cur.execute('PRAGMA table_info("equipment_bank_files")').fetchall()}
    if "description" not in equipment_file_cols:
        cur.execute("ALTER TABLE equipment_bank_files ADD COLUMN description TEXT DEFAULT ''")

    cur.execute('''CREATE TABLE IF NOT EXISTS equipment_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subcategory_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        manufacturer TEXT DEFAULT '', model TEXT DEFAULT '', serial_number TEXT DEFAULT '',
        asset_tag TEXT DEFAULT '', location TEXT DEFAULT '', status TEXT DEFAULT '',
        specifications TEXT DEFAULT '', created_at TEXT, updated_at TEXT,
        FOREIGN KEY(subcategory_id) REFERENCES equipment_bank_subcategories(id) ON DELETE CASCADE
    )''')

    equipment_cols = {r[1] for r in cur.execute('PRAGMA table_info(equipment_records)')}
    for key in EQUIPMENT_RECORD_FIELDS:
        if key not in equipment_cols:
            cur.execute(f'ALTER TABLE equipment_records ADD COLUMN "{key}" TEXT DEFAULT \'\'')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS bank_connection_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            media_type TEXT NOT NULL,
            size_bytes INTEGER,
            uploaded_by TEXT,
            description TEXT NOT NULL,
            created_at TEXT
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS sub_object_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sub_object_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            media_type TEXT NOT NULL,
            size_bytes INTEGER,
            uploaded_by TEXT,
            description TEXT NOT NULL,
            created_at TEXT,
            FOREIGN KEY(sub_object_id) REFERENCES sub_objects(id) ON DELETE CASCADE
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS knowledge_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL,
            size_bytes INTEGER,
            media_type TEXT,
            uploaded_by TEXT,
            created_at TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS user_presence (
            username TEXT PRIMARY KEY,
            session_id TEXT,
            last_seen TEXT NOT NULL,
            ip_address TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            action TEXT,
            details TEXT,
            created_at TEXT
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS system_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            action TEXT,
            details TEXT,
            created_at TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS ai_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            provider TEXT NOT NULL DEFAULT 'ollama',
            ollama_url TEXT NOT NULL DEFAULT 'http://127.0.0.1:11434',
            ollama_model TEXT NOT NULL DEFAULT 'qwen3.5:9b',
            answer_mode TEXT NOT NULL DEFAULT 'hybrid',
            temperature REAL NOT NULL DEFAULT 0.1,
            max_tokens INTEGER NOT NULL DEFAULT 1200,
            timeout_seconds INTEGER NOT NULL DEFAULT 90,
            updated_by TEXT,
            updated_at TEXT
        )
    ''')
    cur.execute('''
        INSERT OR IGNORE INTO ai_settings
        (id, provider, ollama_url, ollama_model, answer_mode, temperature,
         max_tokens, timeout_seconds, updated_at)
        VALUES (1, 'ollama', 'http://127.0.0.1:11434', 'qwen3.5:9b',
                'hybrid', 0.1, 1200, 90, ?)
    ''', (datetime.now().isoformat(),))
    # v27.0.2 Local LLM migration: only move installations that still carry
    # the untouched historical defaults. Admin-customized AI settings remain intact.
    cur.execute('''
        UPDATE ai_settings
           SET provider='ollama', ollama_model='qwen3.5:9b', answer_mode='hybrid',
               ollama_url='http://127.0.0.1:11434', updated_at=?
         WHERE id=1 AND provider='local' AND ollama_model='llama3.1:8b'
           AND (updated_by IS NULL OR updated_by='')
    ''', (datetime.now().isoformat(),))

    cur.execute('''
        CREATE TABLE IF NOT EXISTS ai_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS ai_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            provider TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
        )
    ''')
    cur.execute('''CREATE TABLE IF NOT EXISTS ai_raid_state (
        conversation_id INTEGER PRIMARY KEY, state_json TEXT NOT NULL,
        FOREIGN KEY(conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
    )''')
    cur.execute('CREATE INDEX IF NOT EXISTS ai_conversations_user ON ai_conversations(username, updated_at DESC)')
    cur.execute('CREATE INDEX IF NOT EXISTS ai_messages_conversation ON ai_messages(conversation_id, id)')
    cur.execute('''CREATE TABLE IF NOT EXISTS ai_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id INTEGER NOT NULL,
        username TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK(rating IN (-1, 1)),
        comment TEXT,
        created_at TEXT NOT NULL,
        UNIQUE(conversation_id, username),
        FOREIGN KEY(conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
    )''')
    # Additive v12 migration: cross-worker request limits; no user data rewritten.
    cur.execute('CREATE TABLE IF NOT EXISTS ai_request_limits (username TEXT NOT NULL, requested_at REAL NOT NULL)')
    cur.execute('CREATE INDEX IF NOT EXISTS ai_request_limits_user ON ai_request_limits(username, requested_at)')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS monitoring_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            device_type TEXT NOT NULL DEFAULT 'HPE iLO',
            management_ip TEXT NOT NULL UNIQUE,
            username TEXT NOT NULL,
            password_enc TEXT NOT NULL,
            verify_ssl INTEGER DEFAULT 0,
            status TEXT DEFAULT 'Pending',
            vendor TEXT DEFAULT 'HPE',
            model TEXT,
            serial_number TEXT,
            firmware TEXT,
            last_error TEXT,
            last_seen TEXT,
            created_by TEXT,
            created_at TEXT
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS iso_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            size_bytes INTEGER,
            notes TEXT,
            uploaded_by TEXT,
            created_at TEXT,
            media_type TEXT DEFAULT 'iso'
        )
    ''')
    # Migrate older installations that did not have a media_type column.
    media_cols = {r[1] for r in cur.execute('PRAGMA table_info("iso_files")').fetchall()}
    if "media_type" not in media_cols:
        cur.execute("ALTER TABLE iso_files ADD COLUMN media_type TEXT DEFAULT 'iso'")

    # Normalize legacy roles to the new AI-Hub access model.
    cur.execute("UPDATE users SET role='manager' WHERE role='editor'")
    cur.execute("UPDATE users SET role='operator' WHERE role='viewer'")
    conn.commit()

    # Farbod AI-Hub predefined Equipment workspaces. Existing user-created banks are preserved.
    for bank_name in ('Pasargad bank','Taavon bank','Dotin','Resalat bank','Refah bank','Karafarin bank','Gardeshgari bank','Riton'):
        cur.execute("INSERT OR IGNORE INTO equipment_banks(name,created_at) VALUES(?,?)", (bank_name, datetime.now().isoformat()))
    conn.commit()

    if first_run:
        for key, values in DEFAULT_LOOKUPS.items():
            for i, v in enumerate(values):
                cur.execute(
                    "INSERT OR IGNORE INTO lookups (field_key, value, sort_order) VALUES (?,?,?)",
                    (key, v, i))
        conn.commit()

        bootstrap_password = os.environ.get("FHW_BOOTSTRAP_ADMIN_PASSWORD", "").strip()
        generated_bootstrap = False
        if bootstrap_password:
            if len(bootstrap_password) < 10 and bootstrap_password != "admin123":
                raise RuntimeError("FHW_BOOTSTRAP_ADMIN_PASSWORD must contain at least 10 characters.")
        else:
            bootstrap_password = "admin123"
        cur.execute(
            "INSERT INTO users (username, password_hash, full_name, role, active, created_at) "
            "VALUES (?,?,?,?,1,?)",
            ("admin", _hash_password(bootstrap_password), "Administrator",
             "admin", datetime.now().isoformat()))
        conn.commit()
        if generated_bootstrap:
            bootstrap_file = os.path.join(BASE_DIR, "instance", "bootstrap-admin.txt")
            fd = os.open(bootstrap_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write("Farbod AI-Hub first-run administrator\n")
                handle.write("username=admin\n")
                handle.write(f"password={bootstrap_password}\n")
                handle.write("Change this password immediately, then delete this file.\n")

    for value in ('Healthy', 'Resolved'):
        cur.execute("INSERT OR IGNORE INTO lookups(field_key,value,sort_order) VALUES ('status',?,10)", (value,))
    # v24.8.9: canonical manufacturer display, preserving IDs and unrelated fields.
    aliases = ("dell", "dell emc", "dellemc", "emc")
    cur.execute("INSERT OR IGNORE INTO lookups(field_key,value,sort_order) VALUES ('manufacturer','DellEMC',1)")
    cur.execute("DELETE FROM lookups WHERE field_key='manufacturer' AND lower(trim(value)) IN (?,?,?,?) AND value <> 'DellEMC'", aliases)
    for table, spec in SCHEMAS.items():
        if any(field[0] == "manufacturer" for field in spec["fields"]):
            cur.execute(f'UPDATE "{table}" SET manufacturer=? WHERE lower(trim(manufacturer)) IN (?,?,?,?)', ("DellEMC", *aliases))
    cur.execute("UPDATE warehouse_items SET manufacturer='DellEMC' WHERE lower(trim(manufacturer)) IN (?,?,?,?)", aliases)
    conn.commit()

    # Keep legacy module-user records available for administration without shipping
    # predictable credentials. The current UI uses the primary authenticated session,
    # but these rows are retained for backwards compatibility.
    module_defaults = [
        ("asset_manager", "asset"),
        ("knowledge", "knowledge"),
        ("equipment_profile", "equipment"),
        ("settings", "settings"),
    ]
    for module_key, username in module_defaults:
        exists = cur.execute(
            "SELECT 1 FROM module_users WHERE module_key=? AND username=?",
            (module_key, username),
        ).fetchone()
        if not exists:
            cur.execute(
                "INSERT INTO module_users "
                "(module_key, username, password_hash, active, created_at) VALUES (?,?,?,?,?)",
                (module_key, username, _hash_password(secrets.token_urlsafe(24)), 1, datetime.now().isoformat())
            )
    conn.commit()

    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    for table in SCHEMAS:
        expired = cur.execute(f'SELECT id FROM "{table}" WHERE deleted_at IS NOT NULL AND deleted_at < ?', (cutoff,)).fetchall()
        for item in expired:
            cur.execute('DELETE FROM asset_links WHERE (source_table=? AND source_id=?) OR (target_table=? AND target_id=?)', (table,item[0],table,item[0]))
            subs = cur.execute('SELECT id FROM sub_objects WHERE parent_table=? AND parent_id=?', (table,item[0])).fetchall()
            for sub in subs: cur.execute('DELETE FROM sub_object_files WHERE sub_object_id=?', (sub[0],))
            cur.execute('DELETE FROM sub_objects WHERE parent_table=? AND parent_id=?', (table,item[0]))
            cur.execute(f'DELETE FROM "{table}" WHERE id=?', (item[0],))
    cur.execute('DELETE FROM audit_log WHERE created_at < ?', (cutoff,))
    cur.execute('DELETE FROM system_log WHERE created_at < ?', (cutoff,))
    from asset_intelligence import ensure_schema as ensure_intelligence_schema
    ensure_intelligence_schema(conn)
    conn.commit()
    conn.close()


def get_module_user(module_key, username=None):
    conn = get_conn()
    if username:
        row = conn.execute("SELECT * FROM module_users WHERE module_key=? AND username=?", (module_key, username)).fetchone()
    else:
        row = conn.execute("SELECT * FROM module_users WHERE module_key=? ORDER BY id LIMIT 1", (module_key,)).fetchone()
    conn.close(); return row

def list_module_users(module_key):
    conn = get_conn(); rows = conn.execute("SELECT id,module_key,username,active,created_at FROM module_users WHERE module_key=? ORDER BY username", (module_key,)).fetchall(); conn.close(); return rows

def create_module_user(module_key, username, password):
    conn=get_conn(); conn.execute("INSERT INTO module_users(module_key,username,password_hash,active,created_at) VALUES(?,?,?,?,?)",(module_key,username,_hash_password(password),1,datetime.now().isoformat())); conn.commit(); conn.close()

def update_module_user(user_id,module_key,username,password=None,active=1):
    conn=get_conn()
    if password: conn.execute("UPDATE module_users SET username=?,password_hash=?,active=? WHERE id=? AND module_key=?",(username,_hash_password(password),active,user_id,module_key))
    else: conn.execute("UPDATE module_users SET username=?,active=? WHERE id=? AND module_key=?",(username,active,user_id,module_key))
    conn.commit(); conn.close()

def delete_module_user(user_id,module_key):
    conn=get_conn(); conn.execute("DELETE FROM module_users WHERE id=? AND module_key=?",(user_id,module_key)); conn.commit(); conn.close()

def update_module_credentials(module_key, username, password=None):
    user=get_module_user(module_key)
    if user: update_module_user(user["id"],module_key,username,password,user["active"])

def list_equipment_banks():
    conn=get_conn(); rows=conn.execute("SELECT * FROM equipment_banks ORDER BY name COLLATE NOCASE").fetchall(); conn.close(); return rows

def get_equipment_bank(bank_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM equipment_banks WHERE id=?", (bank_id,)).fetchone(); conn.close(); return row

def list_equipment_subcategories(bank_id):
    conn=get_conn(); rows=conn.execute("SELECT * FROM equipment_bank_subcategories WHERE bank_id=? ORDER BY name COLLATE NOCASE",(bank_id,)).fetchall(); conn.close(); return rows

def get_equipment_subcategory(sub_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM equipment_bank_subcategories WHERE id=?", (sub_id,)).fetchone(); conn.close(); return row

def create_equipment_bank(name):
    conn=get_conn()
    try:
        with conn:
            cur=conn.execute("INSERT INTO equipment_banks(name,created_at) VALUES(?,?)",(name,datetime.now().isoformat()))
            return conn.execute("SELECT * FROM equipment_banks WHERE id=?",(cur.lastrowid,)).fetchone()
    finally:
        conn.close()

def delete_equipment_bank(bank_id):
    """Delete an equipment bank and its subcategories/files, including stored files on disk."""
    conn=get_conn()
    file_rows=conn.execute(
        "SELECT stored_name FROM equipment_bank_files WHERE subcategory_id IN "
        "(SELECT id FROM equipment_bank_subcategories WHERE bank_id=?)", (bank_id,)
    ).fetchall()
    conn.execute("DELETE FROM equipment_bank_files WHERE subcategory_id IN (SELECT id FROM equipment_bank_subcategories WHERE bank_id=?)", (bank_id,))
    conn.execute("DELETE FROM equipment_bank_subcategories WHERE bank_id=?", (bank_id,))
    conn.execute("DELETE FROM equipment_banks WHERE id=?", (bank_id,))
    conn.commit(); conn.close()
    return [r[0] for r in file_rows]

def delete_equipment_subcategory(sub_id):
    """Delete one site/subcategory and return its attachment paths for cleanup."""
    conn=get_conn()
    try:
        with conn:
            files=[r[0] for r in conn.execute("SELECT stored_name FROM equipment_bank_files WHERE subcategory_id=?",(sub_id,))]
            conn.execute("DELETE FROM equipment_records WHERE subcategory_id=?",(sub_id,))
            conn.execute("DELETE FROM equipment_bank_files WHERE subcategory_id=?",(sub_id,))
            conn.execute("DELETE FROM equipment_bank_subcategories WHERE id=?",(sub_id,))
        return files
    finally: conn.close()

def create_equipment_subcategory(bank_id,name):
    conn=get_conn()
    try:
        with conn:
            cur=conn.execute("INSERT INTO equipment_bank_subcategories(bank_id,name,created_at) VALUES(?,?,?)",(bank_id,name,datetime.now().isoformat()))
            return conn.execute("SELECT * FROM equipment_bank_subcategories WHERE id=?",(cur.lastrowid,)).fetchone()
    finally:
        conn.close()

EQUIPMENT_RECORD_FIELDS = tuple(dict.fromkeys(['name','equipment_type','manufacturer','model','serial_number','asset_tag','location','status','specifications'] + [f[0] for spec in SCHEMAS.values() for f in spec['fields']]))
def ensure_equipment_fields():
    global EQUIPMENT_RECORD_FIELDS
    fields=tuple(dict.fromkeys(list(EQUIPMENT_RECORD_FIELDS)+[f[0] for spec in SCHEMAS.values() for f in spec['fields']]))
    conn=get_conn()
    try:
        with conn:
            cols={r[1] for r in conn.execute('PRAGMA table_info(equipment_records)')}
            for key in fields:
                if key not in cols:
                    conn.execute(f'ALTER TABLE equipment_records ADD COLUMN "{key}" TEXT DEFAULT \'\'')
        EQUIPMENT_RECORD_FIELDS=fields
    finally: conn.close()

def list_equipment_records(sub_id):
    conn=get_conn(); rows=conn.execute("SELECT * FROM equipment_records WHERE subcategory_id=? ORDER BY name COLLATE NOCASE,id",(sub_id,)).fetchall(); conn.close(); return rows
def get_equipment_record(record_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM equipment_records WHERE id=?",(record_id,)).fetchone(); conn.close(); return row
def save_equipment_record(sub_id, values, record_id=None):
    ensure_equipment_fields()
    previous=get_equipment_record(record_id) if record_id else None
    vals={k:str(values.get(k, previous[k] if previous else '') or '').strip() for k in EQUIPMENT_RECORD_FIELDS}
    if not vals['name']: raise ValueError('Equipment name is required.')
    kind = vals['equipment_type']
    if kind and kind not in SCHEMAS: raise ValueError('Choose a valid equipment type.')
    for key, low, high in [('power_count',1,12), ('port_count',1,256 if kind in ('network', 'san_switches') else 65535)]:
        if vals.get(key):
            try: n=int(vals[key])
            except ValueError: raise ValueError(f'{key} must be a whole number.')
            if not low <= n <= high: raise ValueError(f'{key} must be between {low} and {high}.')
    conn=get_conn(); now=datetime.now().isoformat()
    if record_id:
        assignments=','.join('"'+k+'"=?' for k in EQUIPMENT_RECORD_FIELDS)
        cur=conn.execute(f"UPDATE equipment_records SET {assignments},updated_at=? WHERE id=? AND subcategory_id=?",(*[vals[k] for k in EQUIPMENT_RECORD_FIELDS],now,record_id,sub_id))
        if not cur.rowcount: conn.close(); raise ValueError('Equipment record not found.')
        rid=record_id
    else:
        columns=','.join('"'+k+'"' for k in EQUIPMENT_RECORD_FIELDS)
        placeholders=','.join('?' for _ in EQUIPMENT_RECORD_FIELDS)
        cur=conn.execute(f"INSERT INTO equipment_records(subcategory_id,{columns},created_at,updated_at) VALUES(?,{placeholders},?,?)",(sub_id,*[vals[k] for k in EQUIPMENT_RECORD_FIELDS],now,now)); rid=cur.lastrowid
    conn.commit(); row=conn.execute("SELECT * FROM equipment_records WHERE id=?",(rid,)).fetchone(); conn.close(); return row
def delete_equipment_record(record_id):
    conn=get_conn(); cur=conn.execute("DELETE FROM equipment_records WHERE id=?",(record_id,)); conn.commit(); conn.close(); return bool(cur.rowcount)

def list_equipment_files(sub_id):
    conn=get_conn(); rows=conn.execute("SELECT * FROM equipment_bank_files WHERE subcategory_id=? ORDER BY id DESC",(sub_id,)).fetchall(); conn.close(); return rows

def add_equipment_file(sub_id, original_name, stored_name, media_type, size_bytes, uploaded_by, description=""):
    conn=get_conn(); cur=conn.execute("INSERT INTO equipment_bank_files(subcategory_id,original_name,stored_name,media_type,size_bytes,uploaded_by,created_at,description) VALUES(?,?,?,?,?,?,?,?)",(sub_id,original_name,stored_name,media_type,size_bytes,uploaded_by,datetime.now().isoformat(),description)); conn.commit(); row=conn.execute("SELECT * FROM equipment_bank_files WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return row

def list_bank_connection_files():
    conn=get_conn(); rows=conn.execute("SELECT * FROM bank_connection_files ORDER BY id DESC").fetchall(); conn.close(); return rows

def add_bank_connection_file(original_name, stored_name, media_type, size_bytes, uploaded_by, description):
    conn=get_conn(); cur=conn.execute("INSERT INTO bank_connection_files(original_name,stored_name,media_type,size_bytes,uploaded_by,description,created_at) VALUES(?,?,?,?,?,?,?)",(original_name,stored_name,media_type,size_bytes,uploaded_by,description,datetime.now().isoformat())); conn.commit(); row=conn.execute("SELECT * FROM bank_connection_files WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return row

def get_bank_connection_file(file_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM bank_connection_files WHERE id=?",(file_id,)).fetchone(); conn.close(); return row

def get_sub_object(sub_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM sub_objects WHERE id=?",(sub_id,)).fetchone(); conn.close(); return row

def list_sub_object_files(sub_id):
    conn=get_conn(); rows=conn.execute("SELECT * FROM sub_object_files WHERE sub_object_id=? ORDER BY id DESC",(sub_id,)).fetchall(); conn.close(); return rows

def add_sub_object_file(sub_id, original_name, stored_name, media_type, size_bytes, uploaded_by, description):
    conn=get_conn(); cur=conn.execute("INSERT INTO sub_object_files(sub_object_id,original_name,stored_name,media_type,size_bytes,uploaded_by,description,created_at) VALUES(?,?,?,?,?,?,?,?)",(sub_id,original_name,stored_name,media_type,size_bytes,uploaded_by,description,datetime.now().isoformat())); conn.commit(); row=conn.execute("SELECT * FROM sub_object_files WHERE id=?",(cur.lastrowid,)).fetchone(); conn.close(); return row

def get_sub_object_file(file_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM sub_object_files WHERE id=?",(file_id,)).fetchone(); conn.close(); return row

def get_equipment_file(file_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM equipment_bank_files WHERE id=?",(file_id,)).fetchone(); conn.close(); return row

def list_knowledge_files(category):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM knowledge_files WHERE category=? ORDER BY id DESC", (category,)
    ).fetchall()
    conn.close()
    return rows


def add_knowledge_file(category, original_name, stored_name, description,
                        size_bytes, media_type, uploaded_by):
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO knowledge_files "
        "(category, original_name, stored_name, description, size_bytes, media_type, uploaded_by, created_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (category, original_name, stored_name, description, size_bytes, media_type,
         uploaded_by, datetime.now().isoformat())
    )
    conn.commit()
    row = conn.execute("SELECT * FROM knowledge_files WHERE id=?", (cur.lastrowid,)).fetchone()
    conn.close()
    return row


def get_knowledge_file(file_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM knowledge_files WHERE id=?", (file_id,)).fetchone()
    conn.close()
    return row


# ---------------------------------------------------------------------------
# Generic asset CRUD (table-driven off SCHEMAS)
# ---------------------------------------------------------------------------

def list_assets(table, q=None):
    spec = SCHEMAS[table]
    conn = get_conn()
    if q:
        like = f"%{q}%"
        clauses = " OR ".join(f'"{f[0]}" LIKE ?' for f in spec["fields"])
        rows = conn.execute(
            f'SELECT * FROM "{table}" WHERE ({clauses}) AND deleted_at IS NULL ORDER BY id ASC',
            [like] * len(spec["fields"])).fetchall()
    else:
        rows = conn.execute(f'SELECT * FROM "{table}" WHERE deleted_at IS NULL ORDER BY id ASC').fetchall()
    conn.close()
    return rows


def get_asset(table, row_id):
    if table not in SCHEMAS:
        raise ValueError("Unknown asset table")
    conn = get_conn()
    row = conn.execute(f'SELECT * FROM "{table}" WHERE id=? AND deleted_at IS NULL', (row_id,)).fetchone()
    conn.close()
    return row


def san_ports_for_switch(switch_id):
    conn = get_conn()
    rows = conn.execute('SELECT * FROM san_port_connections WHERE switch_id=? ORDER BY port_number', (switch_id,)).fetchall()
    conn.close()
    return rows


def save_san_port(switch_id, port_number, destination, fabric, notes, username):
    asset = get_asset('san_switches', switch_id)
    if not asset:
        raise ValueError('SAN switch not found')
    try:
        count = int(asset['port_count'] or asset['fc_ports'] or 0)
    except (TypeError, ValueError):
        count = 0
    if not 1 <= count <= 256 or not 1 <= int(port_number) <= count:
        raise ValueError('Invalid SAN port number')
    now = datetime.now().isoformat()
    conn = get_conn()
    conn.execute('BEGIN IMMEDIATE')
    previous=conn.execute('SELECT * FROM san_port_connections WHERE switch_id=? AND port_number=?',(switch_id,port_number)).fetchone()
    conn.execute('''INSERT INTO san_port_connections(switch_id,port_number,destination,fabric,notes,updated_by,updated_at)
        VALUES(?,?,?,?,?,?,?) ON CONFLICT(switch_id,port_number) DO UPDATE SET
        destination=excluded.destination,fabric=excluded.fabric,notes=excluded.notes,
        updated_by=excluded.updated_by,updated_at=excluded.updated_at''',
        (switch_id, int(port_number), destination.strip()[:300], fabric.strip()[:120], notes.strip()[:3000], username, now))
    from asset_intelligence import record
    record(conn,'san_switches',switch_id,'san_port_note', {k:previous[k] for k in ('port_number','destination','fabric','notes')} if previous else {},dict(port_number=int(port_number),destination=destination.strip()[:300],fabric=fabric.strip()[:120],notes=notes.strip()[:3000]),username)
    conn.commit()
    conn.close()
    log_action(username, 'san_port_update', f'san_switches#{switch_id} port={port_number} destination={destination[:120]}')


def list_maintenance_logs(table, row_id):
    if table not in SCHEMAS:
        raise ValueError('Unknown asset table')
    conn = get_conn()
    rows = conn.execute('SELECT * FROM asset_maintenance_logs WHERE asset_table=? AND asset_id=? ORDER BY event_date DESC, id DESC', (table, row_id)).fetchall()
    conn.close()
    return rows


def add_maintenance_log(table, row_id, event_date, description, severity, username):
    if not get_asset(table, row_id):
        raise ValueError('Asset not found')
    if severity not in ('yellow', 'orange', 'red', 'green', 'change') or not description.strip() or len(description) > 5000:
        raise ValueError('Invalid maintenance log')
    datetime.strptime(event_date, '%Y-%m-%d')
    conn = get_conn()
    conn.execute('INSERT INTO asset_maintenance_logs(asset_table,asset_id,event_date,description,severity,created_by,created_at) VALUES(?,?,?,?,?,?,?)',
                 (table, row_id, event_date, description.strip(), severity, username, datetime.now().isoformat()))
    if severity != 'change' and any(f[0] == 'status' for f in SCHEMAS[table]['fields']):
        latest = conn.execute("SELECT severity FROM asset_maintenance_logs WHERE asset_table=? AND asset_id=? AND severity <> 'change' ORDER BY event_date DESC,id DESC LIMIT 1", (table,row_id)).fetchone()
        state = {'green':'Resolved', 'red':'Faulty', 'orange':'Maintenance', 'yellow':'Maintenance'}[latest['severity']]
        conn.execute(f'UPDATE "{table}" SET status=?, updated_at=? WHERE id=?', (state,datetime.now().isoformat(),row_id))
    conn.commit()
    conn.close()
    log_action(username, 'maintenance_log_create' , f'{table}#{row_id} severity={severity} date={event_date}')


def maintenance_search_fields(table, row_id):
    logs = list_maintenance_logs(table, row_id)
    asset = get_asset(table, row_id)
    severity = next((log['severity'] for log in logs if log['severity'] != 'change'), None)
    if asset is not None and 'status' in asset.keys() and str(asset['status']).lower() in ('healthy','resolved'):
        severity = 'green'
    return {'Repair severity': ('red criticality critical' if severity == 'red' else severity or ''),
            'Repair history': ' '.join(f"{log['event_date']} {log['severity']} {log['description']}" for log in logs)}


def _power_data(table, data, row_id=None):
    if table in ('network', 'san_switches'):
        values = dict(data)
        raw = str(values.get('port_count', '') or '').strip()
        if not raw.isdecimal() or not 1 <= int(raw) <= 256:
            raise ValueError('Switch port count must be a whole number from 1 to 256.')
        if row_id:
            from port_map import mappings
            prefix = 'Port' if table == 'network' else 'FC'
            for name in mappings(table, row_id):
                suffix = name[len(prefix):] if name.startswith(prefix) else ''
                if suffix.isdigit() and int(suffix) > int(raw):
                    raise ValueError('Disconnect ports above the new capacity before reducing port count.')
            if table == 'san_switches' and any(r['port_number'] > int(raw) and r['destination'] for r in san_ports_for_switch(row_id)):
                raise ValueError('Clear SAN destinations above the new capacity before reducing port count.')
        values['port_count'] = str(int(raw))
        return values
    if table == 'hpe_synergy_servers' and row_id:
        from port_map import mappings
        old = get_asset(table, row_id)
        for slot in range(1, 7):
            field = f'icb_{slot}_notes'
            if not str(data.get(field, old[field]) or '').strip():
                if any(name.startswith(f'ICB{slot} / ') for name in mappings(table, row_id)):
                    raise ValueError(f'Disconnect ICB {slot} cables before removing its name.')
    if table != 'servers': return data
    values = dict(data)
    old = get_asset(table,row_id) if row_id else None
    raw = values.get('power_count', '')
    raw = str(raw).strip() if raw is not None else ''
    if not raw: raw = str((old['power_count'] if old else None) or '2')
    if not raw.isdecimal() or not 1 <= int(raw) <= 12:
        raise ValueError('Power supply count must be a whole number from 1 to 12.')
    count=int(raw)
    if old:
        from port_map import mappings
        for name in mappings(table,row_id):
            if name.startswith('PSU') and name[3:].isdigit() and int(name[3:])>count:
                raise ValueError('Disconnect power cables above the new PSU count before reducing it.')
    values['power_count']=str(count)
    return values


def get_power_assignments(table, asset_id):
    if table not in ('servers','storage'):
        return {}
    conn=get_conn()
    rows=conn.execute("SELECT p.psu_index,p.ups_id,u.manufacturer,u.model,u.serial_number,u.asset_tag FROM power_assignments p LEFT JOIN ups u ON u.id=p.ups_id AND u.deleted_at IS NULL WHERE p.asset_table=? AND p.asset_id=? ORDER BY p.psu_index",(table,asset_id)).fetchall()
    conn.close(); result={}
    for row in rows:
        item=dict(row); item['label']=' · '.join(str(item[k]) for k in ('manufacturer','model') if item[k]) or f"UPS #{item['ups_id']}"
        if item['asset_tag'] or item['serial_number']: item['label']+=f" · {item['asset_tag'] or item['serial_number']}"
        result[item['psu_index']]=item
    return result


def get_power_assignments_to_ups(ups_id):
    conn=get_conn()
    sql="SELECT p.asset_table,p.asset_id,p.psu_index,a.manufacturer,a.model,a.serial_number,a.asset_tag FROM power_assignments p JOIN servers a ON p.asset_table='servers' AND a.id=p.asset_id AND a.deleted_at IS NULL WHERE p.ups_id=? UNION ALL SELECT p.asset_table,p.asset_id,p.psu_index,a.manufacturer,a.model,a.serial_number,a.asset_tag FROM power_assignments p JOIN storage a ON p.asset_table='storage' AND a.id=p.asset_id AND a.deleted_at IS NULL WHERE p.ups_id=? ORDER BY asset_table,asset_id,psu_index"
    rows=conn.execute(sql,(ups_id,ups_id)).fetchall();conn.close();return [dict(r) for r in rows]


def save_power_assignments(table, asset_id, form, username):
    if table not in ('servers','storage'): return
    asset=get_asset(table,asset_id)
    if not asset: raise ValueError('Asset not found')
    count=max(1,min(12,int(asset['power_count'] or 2))) if table=='servers' else 2
    assignments=[]
    for index in range(1,count+1):
        raw=str(form.get(f'psu_ups_{index}','') or '').strip()
        if not raw: continue
        if not raw.isdecimal() or not get_asset('ups',int(raw)):
            raise ValueError('Select an existing UPS for each assigned power supply.')
        assignments.append((table,asset_id,index,int(raw),username,datetime.now().isoformat()))
    conn=get_conn();conn.execute('BEGIN IMMEDIATE')
    conn.create_function('audit_actor',0,lambda:username)
    wanted={a[2] for a in assignments}
    for old in conn.execute('SELECT psu_index FROM power_assignments WHERE asset_table=? AND asset_id=?',(table,asset_id)).fetchall():
        if old[0] not in wanted:conn.execute('DELETE FROM power_assignments WHERE asset_table=? AND asset_id=? AND psu_index=?',(table,asset_id,old[0]))
    conn.executemany('INSERT INTO power_assignments(asset_table,asset_id,psu_index,ups_id,updated_by,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(asset_table,asset_id,psu_index) DO UPDATE SET ups_id=excluded.ups_id,updated_by=excluded.updated_by,updated_at=excluded.updated_at',assignments)
    conn.commit();conn.close()
    log_action(username,'power_assignment_update',f'{table}#{asset_id} assignments={len(assignments)}')


def set_power_assignment(table, asset_id, psu_index, ups_id, username):
    if table not in ('servers','storage'):
        raise ValueError('Power assignments are available for servers and storage.')
    asset=get_asset(table,asset_id)
    if not asset:
        raise ValueError('Asset not found')
    index=int(psu_index)
    limit=max(1,min(12,int(asset['power_count'] or 2))) if table=='servers' else 2
    if index < 1 or index > limit:
        raise ValueError('Select a valid power supply.')
    ups=get_asset('ups',int(ups_id)) if str(ups_id).isdecimal() else None
    if not ups:
        raise ValueError('Select an existing UPS.')
    conn=get_conn(); conn.execute('BEGIN IMMEDIATE')
    conn.create_function('audit_actor',0,lambda:username)
    conn.execute('INSERT INTO power_assignments(asset_table,asset_id,psu_index,ups_id,updated_by,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(asset_table,asset_id,psu_index) DO UPDATE SET ups_id=excluded.ups_id,updated_by=excluded.updated_by,updated_at=excluded.updated_at',(table,asset_id,index,int(ups_id),username,datetime.now().isoformat()))
    conn.commit(); conn.close()
    log_action(username,'power_assignment_update',f'{table}#{asset_id} PSU{index} -> UPS#{ups_id}')

def create_asset(table, data, username=None):
    data = _power_data(table, data)
    spec = SCHEMAS[table]
    keys = [f[0] for f in spec["fields"]]
    now = datetime.now().isoformat()
    values = [data.get(k, "").strip() for k in keys]
    placeholders = ",".join(["?"] * (len(keys) + 2))
    cols = ",".join(f'"{k}"' for k in keys) + ", created_at, updated_at"
    conn = get_conn()
    if username: conn.create_function("audit_actor",0,lambda:username)
    cur = conn.execute(
        f'INSERT INTO "{table}" ({cols}) VALUES ({placeholders})',
        values + [now, now])
    conn.commit()
    new_id = cur.lastrowid
    log_action(username, "create", f"{table}#{new_id}")
    conn.close()
    return new_id


def update_asset(table, row_id, data, username=None):
    data = _power_data(table, data, row_id)
    spec = SCHEMAS[table]
    keys = [f[0] for f in spec["fields"]]
    now = datetime.now().isoformat()
    set_clause = ", ".join(f'"{k}"=?' for k in keys) + ', updated_at=?'
    values = [data.get(k, "").strip() for k in keys] + [now, row_id]
    conn = get_conn()
    if username: conn.create_function("audit_actor",0,lambda:username)
    conn.execute(f'UPDATE "{table}" SET {set_clause} WHERE id=?', values)
    conn.commit()
    conn.close()
    log_action(username, "update", f"{table}#{row_id}")


def delete_asset(table, row_id, username=None):
    if table not in SCHEMAS: raise ValueError("Unknown asset table")
    conn = get_conn()
    if username: conn.create_function("audit_actor",0,lambda:username)
    row = conn.execute(f'SELECT id FROM "{table}" WHERE id=? AND deleted_at IS NULL', (row_id,)).fetchone()
    if row:
        conn.execute(f'UPDATE "{table}" SET deleted_at=? WHERE id=?', (datetime.now().isoformat(), row_id))
        conn.commit()
    conn.close()
    if row: log_action(username, "asset_trashed", f"{table}#{row_id} moved to Recycle Bin for 30 days")
    return bool(row)


def delete_assets(table, row_ids, username=None):
    count = 0
    for row_id in set(int(x) for x in row_ids if int(x) > 0):
        count += delete_asset(table, row_id, username)
    return count


def list_trashed_assets():
    purge_expired_assets()
    conn = get_conn()
    result = []
    for table in SCHEMAS:
        result.extend({"table": table, "row": dict(row)} for row in conn.execute(
            f'SELECT * FROM "{table}" WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC'))
    conn.close()
    return sorted(result, key=lambda x: x["row"]["deleted_at"], reverse=True)


def restore_asset(table, row_id, username):
    if table not in SCHEMAS: raise ValueError("Unknown asset table")
    conn = get_conn()
    changed = conn.execute(f'UPDATE "{table}" SET deleted_at=NULL WHERE id=? AND deleted_at IS NOT NULL', (row_id,)).rowcount
    conn.commit(); conn.close()
    if changed: log_action(username, "asset_restored", f"{table}#{row_id} restored from Recycle Bin")
    return bool(changed)


# ---------------------------------------------------------------------------
# Lookups (dropdown values, editable from the UI)
# ---------------------------------------------------------------------------

def get_lookup(field_key):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM lookups WHERE field_key=? ORDER BY sort_order, value",
        (field_key,)).fetchall()
    conn.close()
    return [r["value"] for r in rows]


def all_lookup_keys():
    keys = set()
    for spec in SCHEMAS.values():
        for f in spec["fields"]:
            if f[3]:
                keys.add(f[3])
    return sorted(keys)


def add_lookup_value(field_key, value):
    value = value.strip()
    if not value:
        return
    conn = get_conn()
    conn.execute(
        "INSERT OR IGNORE INTO lookups (field_key, value, sort_order) VALUES (?,?,999)",
        (field_key, value))
    conn.commit()
    conn.close()


def rename_lookup_value(lookup_id, new_value):
    conn = get_conn()
    conn.execute("UPDATE lookups SET value=? WHERE id=?", (new_value.strip(), lookup_id))
    conn.commit()
    conn.close()


def delete_lookup_value(lookup_id):
    conn = get_conn()
    conn.execute("DELETE FROM lookups WHERE id=?", (lookup_id,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# ISO files (installation media the team keeps handy for server builds)
# ---------------------------------------------------------------------------

def list_iso_files():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM iso_files ORDER BY id ASC").fetchall()
    conn.close()
    return rows


def get_iso_file(iso_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM iso_files WHERE id=?", (iso_id,)).fetchone()
    conn.close()
    return row


def add_iso_file(original_name, stored_name, size_bytes, notes, uploaded_by, media_type="iso"):
    conn = get_conn()
    conn.execute(
        "INSERT INTO iso_files (original_name, stored_name, size_bytes, notes, uploaded_by, created_at, media_type) "
        "VALUES (?,?,?,?,?,?,?)",
        (original_name, stored_name, size_bytes, notes, uploaded_by,
         datetime.now().isoformat(), media_type))
    conn.commit()
    conn.close()


def delete_iso_file(iso_id):
    conn = get_conn()
    conn.execute("DELETE FROM iso_files WHERE id=?", (iso_id,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Sub-objects (components that belong to an asset, e.g. NIC, PSU, Disk Shelf)
# ---------------------------------------------------------------------------

def list_sub_objects(parent_table, parent_id):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM sub_objects WHERE parent_table=? AND parent_id=? ORDER BY id",
        (parent_table, parent_id)).fetchall()
    conn.close()
    return rows


def add_sub_object(parent_table, parent_id, name, obj_type, notes):
    conn = get_conn()
    conn.execute(
        "INSERT INTO sub_objects (parent_table, parent_id, name, obj_type, notes, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (parent_table, parent_id, name, obj_type, notes, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def delete_sub_object(sub_id):
    conn = get_conn()
    conn.execute("DELETE FROM sub_object_files WHERE sub_object_id=?", (sub_id,))
    conn.execute("DELETE FROM sub_objects WHERE id=?", (sub_id,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Asset links / diagram (Jira Assets style relationship graph)
# ---------------------------------------------------------------------------

def create_link(source_table, source_id, target_table, target_id, link_type, label, notes, username):
    conn = get_conn()
    conn.execute(
        "INSERT INTO asset_links (source_table, source_id, target_table, target_id, "
        "link_type, label, notes, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
        (source_table, source_id, target_table, target_id, link_type, label, notes,
         username, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def delete_link(link_id):
    conn = get_conn()
    conn.execute("DELETE FROM asset_links WHERE id=?", (link_id,))
    conn.commit()
    conn.close()


def list_links():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM asset_links").fetchall()
    conn.close()
    return rows


def links_for(table, row_id):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM asset_links WHERE (source_table=? AND source_id=?) "
        "OR (target_table=? AND target_id=?)", (table, row_id, table, row_id)).fetchall()
    conn.close()
    return rows


def save_position(node_key, x, y):
    conn = get_conn()
    conn.execute(
        "INSERT INTO diagram_positions (node_key, x, y) VALUES (?,?,?) "
        "ON CONFLICT(node_key) DO UPDATE SET x=excluded.x, y=excluded.y",
        (node_key, x, y))
    conn.commit()
    conn.close()


def all_positions():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM diagram_positions").fetchall()
    conn.close()
    return {r["node_key"]: (r["x"], r["y"]) for r in rows}


def asset_label(table, row):
    """Best-effort human readable label for a row (used as diagram node text)."""
    for key in ("hostname", "vm_name", "cluster_name", "datastore_name",
                "rack_name", "cable_label", "asset_tag", "model", "serial_number"):
        if key in row.keys() and row[key]:
            return row[key]
    return f"{SCHEMAS[table]['label']} #{row['id']}"


def search_all_assets(q):
    """Used by the diagram 'link picker' to find any asset across all tables."""
    like = f"%{q}%"
    results = []
    conn = get_conn()
    for table, spec in SCHEMAS.items():
        clauses = " OR ".join(f'"{f[0]}" LIKE ?' for f in spec["fields"])
        rows = conn.execute(
            f'SELECT * FROM "{table}" WHERE {clauses} ORDER BY id ASC LIMIT 15',
            [like] * len(spec["fields"])).fetchall()
        for r in rows:
            results.append({"table": table, "id": r["id"], "label": asset_label(table, r)})
    conn.close()
    return results


# ---------------------------------------------------------------------------
# Users / RBAC
# ---------------------------------------------------------------------------

def get_user(username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    return row


def list_users():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users ORDER BY id").fetchall()
    conn.close()
    return rows


def create_user(username, password, full_name, role):
    conn = get_conn()
    conn.execute(
        "INSERT INTO users (username, password_hash, full_name, role, active, created_at) "
        "VALUES (?,?,?,?,1,?)",
        (username, _hash_password(password), full_name, role, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def get_user_by_id(user_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return row


def count_active_admins():
    conn = get_conn()
    count = conn.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
    conn.close()
    return count


def update_user(user_id, username, full_name, role, active, new_password=None):
    conn = get_conn()
    if new_password:
        conn.execute(
            "UPDATE users SET username=?, full_name=?, role=?, active=?, password_hash=? WHERE id=?",
            (username, full_name, role, active, _hash_password(new_password), user_id))
    else:
        conn.execute(
            "UPDATE users SET username=?, full_name=?, role=?, active=? WHERE id=?",
            (username, full_name, role, active, user_id))
    conn.commit()
    conn.close()


def delete_user(user_id):
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()


def set_user_avatar(user_id, avatar_filename):
    conn = get_conn()
    conn.execute("UPDATE users SET avatar_filename=? WHERE id=?", (avatar_filename, user_id))
    conn.commit()
    conn.close()


def log_action(username, action, details):
    """Write every change to System Log and user/security events to Audit Log."""
    actor = username or "system"
    now = datetime.now().isoformat()
    conn = get_conn()
    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    conn.execute("DELETE FROM system_log WHERE created_at < ?", (cutoff,))
    conn.execute("DELETE FROM audit_log WHERE created_at < ?", (cutoff,))
    conn.execute(
        "INSERT INTO system_log (username, action, details, created_at) VALUES (?,?,?,?)",
        (actor, action, details, now))
    audit_actions = {"login", "login_failed", "login_blocked", "logout", "session_timeout", "user_create", "user_update", "user_delete", "user_password_change", "user_activate", "user_deactivate", "profile_photo_update", "profile_photo_delete"}
    if action in audit_actions or action.startswith("ai_"):
        conn.execute(
            "INSERT INTO audit_log (username, action, details, created_at) VALUES (?,?,?,?)",
            (actor, action, details, now))
    conn.commit()
    conn.close()

def list_audit_logs(limit=500):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    conn.close()
    return rows

def list_system_logs(limit=1000):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM system_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Local AI configuration and per-user conversation history
# ---------------------------------------------------------------------------

def get_ai_settings():
    conn = get_conn()
    row = conn.execute("SELECT * FROM ai_settings WHERE id=1").fetchone()
    conn.close()
    settings = dict(row) if row else {
        "provider": "ollama", "ollama_url": "http://127.0.0.1:11434",
        "ollama_model": "qwen3.5:9b", "answer_mode": "hybrid",
        "temperature": 0.1, "max_tokens": 1200, "timeout_seconds": 90,
    }
    # Explicit environment values remain useful for managed deployments.
    env_map = {
        "FHW_AI_PROVIDER": "provider", "FHW_OLLAMA_URL": "ollama_url",
        "FHW_OLLAMA_MODEL": "ollama_model", "FHW_AI_ANSWER_MODE": "answer_mode",
        "FHW_AI_TEMPERATURE": "temperature", "FHW_AI_MAX_TOKENS": "max_tokens",
        "FHW_AI_TIMEOUT": "timeout_seconds",
    }
    managed = []
    for env_name, key in env_map.items():
        if env_name in os.environ:
            settings[key] = os.environ[env_name]
            managed.append(key)
    settings["temperature"] = float(settings["temperature"])
    settings["max_tokens"] = int(settings["max_tokens"])
    settings["timeout_seconds"] = int(settings["timeout_seconds"])
    settings["managed_by_env"] = managed
    return settings


def update_ai_settings(provider, ollama_url, ollama_model, answer_mode,
                       temperature, max_tokens, timeout_seconds, updated_by):
    conn = get_conn()
    conn.execute('''UPDATE ai_settings SET provider=?, ollama_url=?, ollama_model=?,
                    answer_mode=?, temperature=?, max_tokens=?, timeout_seconds=?,
                    updated_by=?, updated_at=? WHERE id=1''',
                 (provider, ollama_url, ollama_model, answer_mode, temperature,
                  max_tokens, timeout_seconds, updated_by, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def create_ai_conversation(username, question):
    title = " ".join((question or "New conversation").split())[:80]
    now = datetime.now().isoformat()
    conn = get_conn()
    cur = conn.execute("INSERT INTO ai_conversations(username,title,created_at,updated_at) VALUES(?,?,?,?)",
                       (username, title, now, now))
    conn.commit()
    conversation_id = cur.lastrowid
    conn.close()
    return conversation_id


def get_ai_conversation(conversation_id, username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM ai_conversations WHERE id=? AND username=?",
                       (conversation_id, username)).fetchone()
    conn.close()
    return row


def list_ai_conversations(username, limit=30):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM ai_conversations WHERE username=? ORDER BY updated_at DESC LIMIT ?",
                        (username, int(limit))).fetchall()
    conn.close()
    return rows


def list_ai_messages(conversation_id, username, limit=100):
    conn = get_conn()
    rows = conn.execute('''SELECT m.* FROM ai_messages m
                           JOIN ai_conversations c ON c.id=m.conversation_id
                           WHERE c.id=? AND c.username=? ORDER BY m.id ASC LIMIT ?''',
                        (conversation_id, username, int(limit))).fetchall()
    conn.close()
    return rows


def get_ai_raid_state(conversation_id, username):
    conn = get_conn()
    try:
        row = conn.execute('''SELECT s.state_json FROM ai_raid_state s
            JOIN ai_conversations c ON c.id=s.conversation_id
            WHERE c.id=? AND c.username=?''', (conversation_id, username)).fetchone()
        return json.loads(row['state_json']) if row else None
    finally:
        conn.close()


def add_ai_exchange(conversation_id, username, question, answer, provider, raid_state=...):
    now = datetime.now().isoformat()
    conn = get_conn()
    try:
        with conn:
            owned = conn.execute("SELECT id FROM ai_conversations WHERE id=? AND username=?",
                                 (conversation_id, username)).fetchone()
            if not owned:
                raise ValueError("Conversation not found")
            conn.execute("INSERT INTO ai_messages(conversation_id,role,content,provider,created_at) VALUES(?,?,?,?,?)",
                         (conversation_id, "user", question, None, now))
            conn.execute("INSERT INTO ai_messages(conversation_id,role,content,provider,created_at) VALUES(?,?,?,?,?)",
                         (conversation_id, "assistant", answer, provider, now))
            if raid_state is not ...:
                if raid_state is None:
                    conn.execute("DELETE FROM ai_raid_state WHERE conversation_id=?", (conversation_id,))
                else:
                    conn.execute("INSERT OR REPLACE INTO ai_raid_state(conversation_id,state_json) VALUES(?,?)",
                                 (conversation_id, json.dumps(raid_state)))
            conn.execute("UPDATE ai_conversations SET updated_at=? WHERE id=?", (now, conversation_id))
    finally:
        conn.close()


def delete_ai_conversation(conversation_id, username):
    conn = get_conn()
    conn.execute("DELETE FROM ai_conversations WHERE id=? AND username=?", (conversation_id, username))
    conn.commit()
    conn.close()


def save_ai_feedback(conversation_id, username, rating, comment=""):
    conn = get_conn()
    owned = conn.execute("SELECT id FROM ai_conversations WHERE id=? AND username=?", (conversation_id, username)).fetchone()
    if not owned:
        conn.close()
        raise ValueError("Conversation not found")
    conn.execute('''INSERT INTO ai_feedback(conversation_id,username,rating,comment,created_at)
                    VALUES(?,?,?,?,?) ON CONFLICT(conversation_id,username) DO UPDATE SET
                    rating=excluded.rating, comment=excluded.comment, created_at=excluded.created_at''',
                 (conversation_id, username, int(rating), str(comment or "")[:500], datetime.now().isoformat()))
    conn.commit(); conn.close()


def ai_feedback_summary():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) total, SUM(CASE WHEN rating=1 THEN 1 ELSE 0 END) helpful FROM ai_feedback").fetchone()
    conn.close()
    return dict(row)


def normalize_header(value):
    value = str(value or "").strip().lower()
    return re.sub(r"[^a-z0-9]+", "_", value).strip("_")


def match_import_columns(table, headers):
    spec = SCHEMAS[table]
    aliases = {}
    for key, label, *_ in spec["fields"]:
        aliases[normalize_header(key)] = key
        aliases[normalize_header(label)] = key
    return [aliases.get(normalize_header(h)) for h in headers]


# ---------------------------------------------------------------------------
# Live user presence
# ---------------------------------------------------------------------------
def touch_presence(username, session_id, ip_address=None):
    now = datetime.now().isoformat()
    conn = get_conn()
    conn.execute("""INSERT INTO user_presence (username, session_id, last_seen, ip_address)
                 VALUES (?,?,?,?)
                 ON CONFLICT(username) DO UPDATE SET
                   session_id=excluded.session_id, last_seen=excluded.last_seen, ip_address=excluded.ip_address""",
                 (username, session_id, now, ip_address))
    conn.commit(); conn.close()

def remove_presence(username, session_id=None):
    conn = get_conn()
    if session_id:
        conn.execute("DELETE FROM user_presence WHERE username=? AND session_id=?", (username, session_id))
    else:
        conn.execute("DELETE FROM user_presence WHERE username=?", (username,))
    conn.commit(); conn.close()

def online_users(timeout_seconds=90):
    from datetime import timedelta
    cutoff = (datetime.now() - timedelta(seconds=timeout_seconds)).isoformat()
    conn = get_conn()
    rows = conn.execute("""SELECT u.id, u.username, u.full_name, u.role, u.avatar_filename, p.last_seen
                           FROM user_presence p JOIN users u ON u.username=p.username
                           WHERE p.last_seen >= ? AND u.active=1
                           ORDER BY COALESCE(u.full_name,u.username)""", (cutoff,)).fetchall()
    conn.execute("DELETE FROM user_presence WHERE last_seen < ?", (cutoff,))
    conn.commit(); conn.close()
    return rows


# --- Monitoring device registry -------------------------------------------------
def list_monitoring_devices():
    conn=get_conn(); rows=conn.execute("SELECT * FROM monitoring_devices ORDER BY id DESC").fetchall(); conn.close(); return rows

def get_monitoring_device(device_id):
    conn=get_conn(); row=conn.execute("SELECT * FROM monitoring_devices WHERE id=?",(device_id,)).fetchone(); conn.close(); return row

def create_monitoring_device(name, device_type, ip, username, password_enc, verify_ssl, created_by):
    conn=get_conn(); cur=conn.execute("INSERT INTO monitoring_devices(name,device_type,management_ip,username,password_enc,verify_ssl,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",(name,device_type,ip,username,password_enc,1 if verify_ssl else 0,created_by,datetime.now().isoformat())); conn.commit(); did=cur.lastrowid; conn.close(); return did

def update_monitoring_device_status(device_id, **fields):
    allowed={'status','vendor','model','serial_number','firmware','last_error','last_seen'}; fields={k:v for k,v in fields.items() if k in allowed}
    if not fields:return
    conn=get_conn(); conn.execute("UPDATE monitoring_devices SET "+", ".join(f'{k}=?' for k in fields)+" WHERE id=?",list(fields.values())+[device_id]); conn.commit(); conn.close()

def delete_monitoring_device(device_id):
    conn=get_conn(); conn.execute("DELETE FROM monitoring_devices WHERE id=?",(device_id,)); conn.commit(); conn.close()


def delete_log_entry(kind, log_id):
    if kind not in ("audit", "system"): raise ValueError("Invalid log category")
    conn = get_conn()
    count = conn.execute(f"DELETE FROM {kind}_log WHERE id=?", (log_id,)).rowcount
    conn.commit(); conn.close()
    return count


def delete_knowledge_file(file_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM knowledge_files WHERE id=?", (file_id,)).fetchone()
    if row:
        conn.execute("DELETE FROM knowledge_files WHERE id=?", (file_id,))
        conn.commit()
    conn.close()
    return row


def purge_expired_assets():
    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    conn = get_conn()
    try:
        for table in SCHEMAS:
            expired = conn.execute(f'SELECT id FROM "{table}" WHERE deleted_at IS NOT NULL AND deleted_at < ?', (cutoff,)).fetchall()
            for item in expired:
                conn.execute('DELETE FROM asset_links WHERE (source_table=? AND source_id=?) OR (target_table=? AND target_id=?)', (table,item[0],table,item[0]))
                subs = conn.execute('SELECT id FROM sub_objects WHERE parent_table=? AND parent_id=?', (table,item[0])).fetchall()
                for sub in subs: conn.execute('DELETE FROM sub_object_files WHERE sub_object_id=?', (sub[0],))
                conn.execute('DELETE FROM sub_objects WHERE parent_table=? AND parent_id=?', (table,item[0]))
                conn.execute(f'DELETE FROM "{table}" WHERE id=?', (item[0],))
        conn.commit()
    finally: conn.close()
