#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
env_file="$project_dir/.env.docker"
# Read the release from the same source used by /healthz.
release_version="$(sed -n 's/^APP_VERSION = "\([0-9.]*\)"$/\1/p' "$project_dir/app.py")"
[[ -n "$release_version" ]] || { echo "Cannot read application release version."; exit 1; }
release_build="${release_version}-automation-enterprise"

pause_terminal(){ if [[ -t 0 ]]; then read -r -p "Press Return to close…" _; fi; }
require_docker(){
  command -v docker >/dev/null || { echo "Docker Desktop is not installed or docker is not in PATH."; pause_terminal; exit 1; }
  docker info >/dev/null 2>&1 || { echo "Start Docker Desktop, wait until it is ready, then try again."; pause_terminal; exit 1; }
  docker compose version >/dev/null || { echo "Docker Compose v2 is required."; pause_terminal; exit 1; }
}
require_config(){ :; }
compose(){
  if [[ -f "$env_file" ]]; then
    docker compose --env-file "$env_file" "$@"
  else
    docker compose "$@"
  fi
}

if [[ -f "$env_file" ]]; then
  # Repair legacy newline damage and upgrade only bundled image tags.
  perl -pi -e 's/^(FHW_DOCKER_IMAGE=farbod-ai-hub:27\.0\.3)(FHW_[A-Z0-9_]+=)/$1\n$2/; s/^FHW_DOCKER_IMAGE=farbod-ai-hub:27\.0\.[23456789][ \t]*$/FHW_DOCKER_IMAGE=farbod-ai-hub:28.2.4/; s/^FHW_DOCKER_IMAGE=farbod-ai-hub:28\.(0\.0|1\.[0-4]|2\.[0-3])[ \t]*$/FHW_DOCKER_IMAGE=farbod-ai-hub:28.2.4/' "$env_file"
  set -a
  # shellcheck disable=SC1090
  source "$env_file"
  set +a
fi
bind_ip="${FHW_DOCKER_BIND_IP:-127.0.0.1}"
http_port="${FHW_DOCKER_HTTP_PORT:-80}"
https_port="${FHW_DOCKER_HTTPS_PORT:-443}"
http_url="http://$bind_ip:$http_port"
https_url="https://${FHW_HTTPS_HOST:-localhost}${https_port:+:$https_port}"
[[ "$https_port" == "443" ]] && https_url="https://${FHW_HTTPS_HOST:-localhost}"

# Verify the published HTTPS endpoint as well as the internal app.
verify_https(){
  local attempt response compact_response
  for attempt in {1..10}; do
    if response="$(curl --noproxy '*' -kfsS --connect-timeout 2 --max-time 5 "$https_url/healthz" 2>/dev/null)"; then
      compact_response="$(printf '%s' "$response" | tr -d '[:space:]')"
      if printf '%s' "$compact_response" | grep -Fq "\"version\":\"$release_version\"" &&
         printf '%s' "$compact_response" | grep -Fq "\"build\":\"$release_build\""; then
      echo "HTTPS verified: $https_url"
      return 0
      fi
    fi
    sleep 1
  done
  echo "HTTPS verification failed at $https_url (expected $release_build). The endpoint may be unreachable or serving a different release. Service status and logs follow:"
  compose ps -a || true
  compose logs --tail=40 app caddy || true
  return 1
}

# Verify the application serving requests, rather than trusting the image name.
verify_running_release(){
  local attempt
  for attempt in {1..30}; do
    if compose exec -T app python -c 'import json,sys,urllib.request; d=json.load(urllib.request.urlopen("http://127.0.0.1:8000/healthz",timeout=3)); assert d.get("version")==sys.argv[1] and d.get("build")==sys.argv[2], d; print("Verified running Farbod AI-Hub " + d["build"])' "$release_version" "$release_build" 2>/dev/null; then
      verify_https
      return $?
    fi
    sleep 2
  done
  echo "Could not verify running version $release_build. Check DOCKER_LOGS.command before using this build."
  return 1
}
