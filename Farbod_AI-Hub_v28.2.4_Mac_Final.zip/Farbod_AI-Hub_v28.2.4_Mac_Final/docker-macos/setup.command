#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker

echo "Farbod AI-Hub v28.2.4 — Docker setup"
if [[ ! -f "$env_file" ]]; then
  cp .env.docker.example "$env_file"
  /usr/bin/sed -i '' "s/^FHW_DOCKER_UID=.*/FHW_DOCKER_UID=$(id -u)/" "$env_file"
  /usr/bin/sed -i '' "s/^FHW_DOCKER_GID=.*/FHW_DOCKER_GID=$(id -g)/" "$env_file"
  chmod 600 "$env_file"
  echo "Created .env.docker for UID $(id -u)."
fi

set -a; source "$env_file"; set +a
data_path="${FHW_DOCKER_DATA_DIR:-./docker-data/data}"
backup_path="${FHW_DOCKER_BACKUP_DIR:-./docker-data/backups}"
mkdir -p "$data_path/instance" "$data_path/knowledge" "$data_path/equipment_files" \
  "$data_path/bank_connection_info" "$data_path/subobject_files" "$data_path/logs" "$data_path/runtime" "$backup_path"
chmod -R u+rwX "$data_path" "$backup_path"

if lsof -nP -iTCP:"${FHW_DOCKER_HTTPS_PORT:-443}" -sTCP:LISTEN >/dev/null 2>&1 \
   && ! docker ps --format '{{.Names}}' | grep -qx 'farbod-ai-hub-caddy'; then
  echo "Port ${FHW_DOCKER_HTTPS_PORT:-443} is already in use."
  pause_terminal
  exit 1
fi

compose config --quiet
compose --profile https up -d --build --force-recreate app worker backup caddy
verify_running_release

echo "Farbod AI-Hub is ready: $https_url"
echo "HTTP on port 80 redirects to HTTPS. The app's port 8000 is internal to Docker."
if [[ -f "$data_path/instance/bootstrap-admin.txt" ]]; then
  echo "First-run admin credentials: $data_path/instance/bootstrap-admin.txt"
  echo "Change the password after login, then delete that file."
fi
open "$https_url"
pause_terminal
