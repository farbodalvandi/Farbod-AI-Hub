#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
echo "Building and starting Farbod AI-Hub 28.2.4 from this folder…"
compose --profile https up -d --build --force-recreate app worker backup caddy
verify_running_release
echo "HTTPS started at $https_url"
echo "HTTP on port 80 redirects to HTTPS; app port 8000 is internal only."
open "$https_url"
pause_terminal
