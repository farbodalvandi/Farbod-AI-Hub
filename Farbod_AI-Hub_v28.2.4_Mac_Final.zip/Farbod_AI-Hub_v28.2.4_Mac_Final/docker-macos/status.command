#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
require_docker; require_config
compose --profile https ps
echo
if curl -fsS "$http_url/healthz" >/dev/null 2>&1; then echo "Health: OK — $http_url"; else echo "Health: unavailable"; fi
echo "Docker storage: ${FHW_DOCKER_DATA_DIR:-./docker-data/data}"
echo "Backups: ${FHW_DOCKER_BACKUP_DIR:-./docker-data/backups}"
pause_terminal
