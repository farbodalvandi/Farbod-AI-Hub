#!/bin/sh
set -eu
umask 077

mkdir -p /data/instance /data/knowledge /data/equipment_files \
  /data/bank_connection_info /data/subobject_files /data/logs /data/runtime /backups /tmp/fhw

for directory in /data /data/instance /data/logs /backups; do
  if [ ! -w "$directory" ]; then
    echo "ERROR: $directory is not writable by container UID $(id -u). Run DOCKER_SETUP.command again." >&2
    exit 1
  fi
done

exec "$@"
