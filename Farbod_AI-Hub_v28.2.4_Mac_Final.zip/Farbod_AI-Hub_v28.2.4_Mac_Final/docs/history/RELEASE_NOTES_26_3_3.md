# Farbod AI-Hub 26.3.3 — Ubuntu HTTPS deployment

Complete source release with the existing application features preserved.

- Caddy starts as a normal Compose service, publishing TCP 443 and HTTP-to-HTTPS redirect on TCP 80.
- App port 8000 remains internal; it is not published on the host.
- Caddy default SNI matches the configured site host for IP-based clients.
- Internal template links preserve the browser origin, preventing HTTP asset URLs behind TLS termination.
- Login forms include CSRF tokens in server-rendered HTML; CSRF validation and secure cookies remain enabled.
- Ubuntu setup builds one shared app image, then starts app, worker, backup and Caddy; subsequent starts do not rebuild.
- Private Debian and PyPI repository defaults are included. The requested internal APT trust bypass is configurable with FHW_DEBIAN_TRUSTED.
- Ubuntu launchers are invoked through bash; shell scripts retain executable archive permissions.
- Removed the external Dockerfile frontend directive and mandatory registry-mirror check, allowing existing local base images to be used.

Validation: HTTPS origin/asset delivery and CSRF regression tests; shell syntax; Compose YAML structure and mocked setup flow. A real Docker build against the user's private Nexus and live browser login have not been run in the authoring environment.

Start with INSTALL_UBUNTU_FA.txt. This is a source package, not a prebuilt or fully self-contained Docker image archive.
