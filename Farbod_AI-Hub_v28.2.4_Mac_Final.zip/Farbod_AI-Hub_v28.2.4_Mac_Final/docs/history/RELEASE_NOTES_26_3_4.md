# Farbod AI-Hub 26.4.0

Based on Farbod AI-Hub 26.3.3 Ubuntu HTTPS/Nexus, preserving its deployment configuration.

- Fixed the Asset Manager equipment table's vertical scrolling: the later UI stylesheet incorrectly disabled vertical overflow on a height-limited table. Both axes now scroll in the same table container, with keyboard focus support.
- Restored the exact uploaded green/orange JPEG logo. The image is copied byte for byte; there is no tracing, recoloring, cropping or redrawing. Color filters and logo rotation are disabled. The supplied white background is retained.
- Added RAID Calculator to the home workspace cards and sidebar. Supports RAID 0, 1, 5, 6, 10, 50 and 60, decimal GB/TB, binary GiB/TiB, hot spares and explicit nested RAID groups.
- Displays usable TB/TiB, raw capacity, redundancy overhead, efficiency, formula and fault tolerance.
- AI Assist recognizes `I want to create a RAID` (and Persian equivalents), then asks for disk count, per-disk capacity and RAID level separately. RAID 50/60 also ask for group count. Replies are validated before advancing. Type `cancel` or `restart` while in the wizard.
- The wizard uses the same deterministic Python calculation as the form, entirely offline. State is stored per owned conversation and survives refreshes and worker changes. A new additive `ai_raid_state` table is created automatically. Each answer and its next state are committed together.
- English/Persian interface labels and Persian numeric input in chat are supported.

## Calculation assumptions

Equal-sized active disks; use the smallest capacity for mixed sizes. RAID 1 means one N-way mirror, not multiple striped mirror pairs. RAID 10 uses two-way mirror pairs and an even number of active disks. This calculator uses a minimum of two disks for RAID 0 (some controllers also permit a single-disk RAID 0 virtual disk). RAID 50/60 require at least two equal-sized groups, with at least three/four disks per group respectively. Controller-specific limits may differ.

N = active disks, D = disk size, G = groups. Capacity: RAID 0 N×D; RAID 1 D; RAID 5 (N−1)×D; RAID 6 (N−2)×D; RAID 10 N×D/2; RAID 50 (N−G)×D; RAID 60 (N−2G)×D. Hot spares are subtracted from the total count before calculation. Formatting, controller metadata and filesystem overhead reduce actual space. No compression/deduplication benefit is assumed. RAID is not a backup.

## References

Requested interaction reference: https://www.raid-calculator.com/
RAID definitions and minimum disk counts: https://www.dell.com/support/manuals/en-ca/poweredge-rc-h730/perc9ugpublication/summary-of-raid-levels?guid=guid-6ae6da6f-688a-482e-af0e-f605d7299aca&lang=en-us
RAID 60 span formula: https://www.dell.com/support/manuals/en-ca/oth-xlr7960/idrac9_7.xx_ug/raid-level-60-striping-over-raid-6-sets?guid=guid-788d764f-a84d-40ab-b2b7-d63ecabc403a&lang=en-us

## Validation

Run from the project directory with a separate FHW_DATA_DIR:

    python3 -m pytest -q tests/test_raid_calculator.py tests/test_https_login.py tests/test_ai_port_lookup.py

Browser checks with a synthetic 75-server inventory: mouse-wheel and final-row scrolling, calculator form submission, nested RAID group selection, light/dark rendering, narrow viewport and actual AI Assist chat with a page reload between replies. No browser JavaScript errors were observed. Original JPEG SHA-256 equality was verified.

Docker image building and installation on the user's offline Ubuntu host were not performed in the development environment. No additional runtime Python dependencies were introduced.
