# Farbod AI-Hub v25.8.4 — Midnight Amber

- Added Midnight Amber, a dark theme with near-black surfaces, readable light text and amber-yellow action accents.
- Kept Light, Dark and Soft Glass as selectable appearance options. Theme selection is saved on this device.
- Added the theme to the main application and Linux Health workspace.
- Preserved the compact Infrastructure Copilot placement and Command Center-only quick link on FHW Hub.
