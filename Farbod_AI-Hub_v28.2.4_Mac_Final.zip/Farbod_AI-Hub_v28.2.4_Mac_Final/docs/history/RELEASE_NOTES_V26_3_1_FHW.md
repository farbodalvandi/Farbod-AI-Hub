# Farbod AI-Hub v26.3.1

- This is an independent, company-branded branch. Future personal-product releases remain on their existing line.
- Replaced product wordmarks and icons throughout the application with the supplied FHW company mark.
- Set the release, container image, Compose project, services, and backup labels to Farbod AI-Hub 26.3.1.
- Added the Ubuntu offline deployment profile from the 24.8.8 setup: Nexus Debian/PyPI repositories, Docker registry mirror, LAN binding, HTTP 8000, HTTPS 443 through Caddy, firewall and CA export helpers.
- Preserved the Storage port-column layout correction and other 26.1.3 features.
