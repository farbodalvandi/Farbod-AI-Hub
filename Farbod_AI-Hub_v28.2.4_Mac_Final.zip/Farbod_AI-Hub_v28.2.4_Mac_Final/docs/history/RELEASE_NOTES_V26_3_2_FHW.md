# Farbod AI-Hub v26.3.3

- AI Assist can answer direct port-connection questions from the recorded physical cable map.
- SAN switch FC ports and server NIC/HBA ports show the connected asset, destination port, fabric, and notes when recorded.
- Unconnected ports are reported as unconnected in the inventory.
- Port-map answers respect the asset-manager permission.
- Carries forward the FHW branding and offline Ubuntu/Nexus deployment profile from v26.3.1.
