# Farbod AI-Hub v15 — AI Operations Copilot

Version 15 upgrades the assistant from evidence search into an explainable,
multi-specialist operations copilot while preserving the v14 FastAPI runtime,
database, users and uploaded files.

## New capabilities

- Automatic Server, Storage, SAN, VMware and Network specialist routing
- Auto, Ask, Diagnose, Capacity and Runbook workflows
- Evidence-aware confidence score and operational risk classification
- Safety review and approval warning for high-risk requests
- Recommended next steps that stay separate from source facts
- Helpful/not-helpful feedback stored per user conversation
- Agent plan API upgraded to version 15
- Responsive intelligence cards in the assistant workspace

All infrastructure access remains read-only. The copilot can search, analyze
and propose a runbook, but it does not execute device changes.

## Start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run_v15.py
```

Use `FHW_ASSET_PORT=8443 python run_v15.py` when port 443 is unavailable.
Existing writable data under `instance/` and upload directories is retained.
