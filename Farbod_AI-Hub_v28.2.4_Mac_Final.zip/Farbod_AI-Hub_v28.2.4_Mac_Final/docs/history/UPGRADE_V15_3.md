# Farbod AI-Hub v15.3 — Container Edition

Version 15.3 preserves the v15.2 application and adds a hardened Docker Compose
deployment for macOS and Linux.

## Prerequisite

Install Docker Desktop on macOS and wait until the Docker engine is running.
Enable **Start Docker Desktop when you sign in** if the application should start
after a Mac restart. Compose uses `restart: unless-stopped` for the application
and backup containers.

Do not run the native LaunchAgent and Docker stack on port 8000 at the same
time. Stop the v15.2 service before the first Docker setup.

## One-time setup on macOS

1. Extract the ZIP to a permanent folder.
2. Control-click `DOCKER_SETUP.command`, choose **Open**, and confirm macOS.
3. Wait for the image build and health check.
4. Open `http://127.0.0.1:8000` and change the initial admin password.

The setup detects and copies existing v15.2 data from
`~/Library/Application Support/FarbodAIHub` when Docker storage is empty.

## Terminal setup

```bash
cp .env.docker.example .env.docker
mkdir -p docker-data/data docker-data/backups
docker compose --env-file .env.docker up -d --build app backup
```

On macOS, use `DOCKER_SETUP.command` instead so `.env.docker` receives the
correct host UID and GID automatically.

## Daily controls

- `DOCKER_START.command`
- `DOCKER_STOP.command`
- `DOCKER_RESTART.command`
- `DOCKER_STATUS.command`
- `DOCKER_LOGS.command`
- `DOCKER_BACKUP_NOW.command`
- `DOCKER_UPDATE.command`

Stopping or replacing containers does not remove application data. Never add
`-v` to `docker compose down` unless you intentionally want to remove Caddy's
certificate data. Application data and backups are bind-mounted host folders.

## Persistent storage

```text
docker-data/data       Database, encryption key, uploads, knowledge and logs
docker-data/backups    Rotated backup archives
```

The application root filesystem is read-only. Only `/data`, `/backups` and a
temporary in-memory `/tmp` are writable.

## Ollama on the Mac

Ollama stays native on macOS for Metal/GPU acceleration. The application uses:

```text
http://host.docker.internal:11434
```

Edit `.env.docker` and set `FHW_AI_PROVIDER=ollama` after Ollama and the
configured model are ready, then run `DOCKER_RESTART.command`.

## Optional HTTPS

Run `DOCKER_START_HTTPS.command` to enable the Caddy profile on
`https://localhost`. Caddy uses an internal CA, so browsers may require explicit
certificate trust. For enterprise access, replace `docker/Caddyfile` with the
organization's DNS name and trusted CA certificate configuration.

## Security model

- non-root application process using the macOS user's numeric UID/GID;
- all Linux capabilities dropped;
- no-new-privileges enabled;
- read-only application filesystem;
- no Docker socket inside any container;
- application published only on `127.0.0.1` by default;
- secrets and runtime data excluded from the image;
- built-in health checks and graceful stop period;
- a single application replica while SQLite is used.

For multi-node or high-concurrency deployment, migrate SQLite to PostgreSQL
before increasing the number of application replicas.
