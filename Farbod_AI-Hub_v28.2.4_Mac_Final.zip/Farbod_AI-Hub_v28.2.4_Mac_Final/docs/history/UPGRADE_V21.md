# Farbod AI-Hub v21 — 3D Datacenter Digital Twin

Adds a physical Rack View to Digital Twin, driven directly by Asset Workspace data.

- Datacenter / Room filtering and rack/asset search
- Perspective rack visualization with U numbering
- Server/storage/SAN/network health indicators
- Click-through from rack equipment to Asset 360°
- Zoom, fit-view, focus and flat/perspective controls
- Rack capacity and estimated free-U summary
- Unplaced-assets queue for records missing U Position
- Offline-first: no CDN or external 3D dependency required

For best placement, populate Rack and U Position on assets. Rack definitions come from Asset Workspace > Racks.
