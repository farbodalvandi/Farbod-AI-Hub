# Farbod AI-Hub v22 — Datacenter Design Studio

V22 continues directly from v21 and keeps the platform offline-first and Docker-compatible.

## New in v22
- Datacenter Design Studio under Digital Twin
- Drag-and-drop Floor Plan with browser-local saved layout
- Rack Designer with U-level planning tray (non-destructive planning)
- Capacity and estimated power planning dashboard
- Visual cabling map from recorded Cable assets
- What-if Scenario Simulator for rack space, estimated power, FC ports and network ports
- Suggested rack placement based on recorded free U capacity

## Safety / data semantics
Power values in Design Studio are offline planning estimates, not telemetry. Rack planning and floor layout changes do not modify Asset Workspace unless the user later records them there explicitly.
