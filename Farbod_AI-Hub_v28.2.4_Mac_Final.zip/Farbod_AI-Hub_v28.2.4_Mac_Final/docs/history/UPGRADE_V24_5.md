# Farbod AI-Hub 24.5

- Audit and system logs are retained for 30 days. Admins can remove individual entries; user changes record before and after values except passwords.
- Deleted equipment is moved to Recycle Bin for 30 days. Managers and admins can restore the original ID and associated components and relationships. Expired records are purged on startup and when Recycle Bin is opened.
- Server records include First IP Addr, Private IP Addr 1, and Private IP Addr 2. Existing databases acquire the columns automatically.
- Asset 360° includes Edit at the top. Knowledge accepts multiple PDF/Word documents and lets authorized Knowledge users delete documents.
- Login footer uses the FHW company identity. A translucent liquid glass visual layer supports light and dark themes, keyboard focus and reduced motion.

Keep your existing writable `/data` Docker volume during upgrade. Back up the database before replacing a running deployment.
