# Farbod AI-Hub 25.8.1 — Complete — multicolor interface and device port maps

This release replaces the earlier incomplete 25.8.1 preview. Its actual application version and Docker metadata are 25.8.1. The landing Hardware Hub has a new greeting/search area, recorded-health card, metric cards and workspace grid. The dashboard has a recorded-health strip. The common stylesheet now loads in every full-page template, including Knowledge, Equipment and Linux Health, not only pages extending base.html. Appearance now offers Light and Dark only, with a fixed multicolor palette.

All existing application modules, forms, fields, routes and role checks are retained. Health figures come from inventory records; they are not live telemetry. An additive migration creates physical_ports, physical_cables and physical_endpoints; existing inventory and SAN notes are retained. The earlier AI-generated images were concept illustrations, not pixel-identical screenshots of this implementation. No mock gallery or sample records ship in this package.

## Recommended Mac Docker upgrade

1. Keep the current application running so it can create a backup.
2. Extract this corrected release into a separate folder.
3. Run `INSTALL_UPDATE_25_8_1.command` from the new folder and enter the full path of the EXISTING application folder. Alternatively:

   `bash INSTALL_UPDATE_25_8_1.command "/absolute/path/to/existing/FHW_AI-Hub"`

The installer first backs up live data, then copies application source into the existing folder while preserving `.env`, `.env.docker`, Docker data, uploaded files and local Python environments. It rebuilds the image, replaces the containers, and verifies that the running HTTP health endpoint reports 25.8.1. It never runs `docker compose down -v` or deletes persistent volumes.

Use the original installation folder thereafter. Starting a completely separate folder with relative Docker data paths can otherwise appear to create an empty installation.

## Already copied the source into the existing folder?

Run `bash DOCKER_UPDATE.command`. The updated `DOCKER_START.command` and HTTPS launcher also build source before starting. Docker uses cached layers where possible; this release does not force base-image pulls. Existing custom image names in `.env.docker` are honored, but the image is rebuilt from this source.

## Verify

The launcher prints `Verified running Farbod AI-Hub 25.8.1-strong-buttons`. The Hub header/footer and application sidebar display 25.8.1. Page source includes `interface-v25-6.css?v=25.8.1-strong-buttons`. Static asset URLs change with APP_VERSION, so a normal reload fetches the new stylesheet; on Mac use Cmd+Shift+R if an old page remains open.

## Rollback

Keep the original 25.5 ZIP. To return to it, restore its application source into the same installation folder, preserving environment files and persistent data, then rebuild/recreate the Docker services. Older code will not display the new cabling tables. Keep the pre-update backup; restoring that backup discards changes made after it.
