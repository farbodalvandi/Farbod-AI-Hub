"""Session-authenticated Linux Health API. SSH work runs off the ASGI event loop."""
import os
import threading
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from api_v2.main import _require_authenticated_api, _require_csrf
from linux_health_service import diagnose, HostTrustMissing, SSHConnectionFailed, diagnostic_options
import paths

router = APIRouter(prefix="/api/linux-health", tags=["Linux Health"])
_slots = threading.BoundedSemaphore(2)

class Target(BaseModel):
    host: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9.:-]{0,252}$")
    port: int = Field(default=22, ge=1, le=65535)
    username: str = Field(pattern=r"^[a-zA-Z_][a-zA-Z0-9_.-]{0,63}$")
    password: str = Field(min_length=1, max_length=1024)
    selected_checks: list[str] = Field(min_length=1, max_length=211)

@router.post("/diagnose")
async def diagnose_server(body: Target, request: Request):
    user = _require_authenticated_api(request)
    if user["role"] not in {"operator", "manager", "admin"}:
        raise HTTPException(403, "Linux Health access denied")
    _require_csrf(request)
    known_hosts = os.environ.get("FHW_LINUX_HEALTH_KNOWN_HOSTS") or str(Path(paths.data_dir()) / "ssh" / "known_hosts")
    allowed_checks = {item["id"] for item in diagnostic_options()}
    if len(set(body.selected_checks)) != len(body.selected_checks) or not set(body.selected_checks).issubset(allowed_checks):
        raise HTTPException(422, "One or more selected diagnostic checks are invalid")
    if not _slots.acquire(blocking=False):
        raise HTTPException(429, "Diagnostics are busy; try again shortly")
    try:
        result = await run_in_threadpool(diagnose, body.host, body.port, body.username, body.password, known_hosts, body.selected_checks)
        return JSONResponse(result, headers={"Cache-Control": "no-store, private"})
    except HostTrustMissing as exc:
        raise HTTPException(503, str(exc)) from None
    except SSHConnectionFailed as exc:
        raise HTTPException(502, str(exc)) from None
    finally:
        _slots.release()


class CommandEntry(BaseModel):
    label: str = Field(min_length=1, max_length=120)
    command: str = Field(min_length=1, max_length=16000)

def _library_user(request, write=False):
    user = _require_authenticated_api(request)
    if user["role"] not in {"operator", "manager", "admin"}:
        raise HTTPException(403, "Linux Health access denied")
    if write:
        _require_csrf(request)
    return user

@router.get("/commands")
async def command_library(request: Request):
    _library_user(request)
    from linux_health_library import catalogue
    return JSONResponse({"commands": catalogue()}, headers={"Cache-Control": "no-store, private"})

@router.post("/commands")
async def create_command(body: CommandEntry, request: Request):
    _library_user(request, True)
    from linux_health_library import save_command
    try:
        key = save_command(None, body.label, body.command)
        return {"id": key}
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None

@router.put("/commands/{key}")
async def update_command(key: str, body: CommandEntry, request: Request):
    _library_user(request, True)
    from linux_health_library import save_command
    try:
        return {"id": save_command(key, body.label, body.command)}
    except KeyError:
        raise HTTPException(404, "Command not found") from None
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None

@router.delete("/commands/{key}")
async def remove_command(key: str, request: Request):
    _library_user(request, True)
    from linux_health_library import reset_or_delete
    try:
        reset_or_delete(key)
        return {"ok": True}
    except KeyError:
        raise HTTPException(404, "Command not found") from None
