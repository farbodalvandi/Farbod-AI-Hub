"""Persistent Linux Health command catalogue, stored with application data."""
from contextlib import contextmanager
import json
import sqlite3
import uuid
from pathlib import Path
import paths

@contextmanager
def _connect():
    folder = Path(paths.data_dir()) / 'instance'
    folder.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(folder / 'linux_health_commands.sqlite3'), timeout=10)
    conn.execute('CREATE TABLE IF NOT EXISTS commands (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
    try:
        with conn:
            yield conn
    finally:
        conn.close()

def defaults():
    from linux_health_service import CHECKS, QLA_LOG, QLA_PORTS, FC_PATHS, CHRONY
    items = [{'id': k, 'label': label, 'command': cmd, 'kind': kind} for k, label, cmd, kind in CHECKS]
    items += [dict(id='qla', label='QLogic HBA / QLA events', command=QLA_LOG + "\nprintf '\\n--FC-INVENTORY--\\n'\n" + QLA_PORTS + "\nprintf '\\n--SCSI-PATHS--\\n'\n" + FC_PATHS, kind='qla'), dict(id='chrony', label='Chrony source and time quality', command=CHRONY, kind='chrony')]
    return items

def catalogue():
    with _connect() as conn:
        saved = {k: json.loads(v) for k, v in conn.execute('SELECT id,payload FROM commands ORDER BY rowid')}
    items = []
    for original in defaults():
        item = dict(original)
        item.update(saved.pop(item['id'], {}))
        item.update(builtin=True, modified=item['command'] != original['command'], default_command=original['command'])
        items.append(item)
    for key, item in saved.items():
        items.append(dict(item, id=key, builtin=False, modified=True, kind='custom', default_command=None))
    return items

def save_command(key, label, command):
    label, command = label.strip(), command.strip()
    if not label or len(label)>120 or not command or len(command)>16000 or '\x00' in command:
        raise ValueError('Enter a name (1–120 characters) and command (1–16000 characters, no NUL bytes).')
    with _connect() as conn:
        conn.execute('BEGIN IMMEDIATE')
        builtin = {x['id'] for x in defaults()}
        if key is not None and key not in builtin and not conn.execute('SELECT 1 FROM commands WHERE id=?',(key,)).fetchone():
            raise KeyError(key)
        if key is None:
            if conn.execute('SELECT COUNT(*) FROM commands').fetchone()[0] >= 200:
                raise ValueError('Command library limit reached (200 saved entries).')
            key = 'custom_' + uuid.uuid4().hex
        conn.execute('INSERT OR REPLACE INTO commands VALUES (?,?)',(key,json.dumps(dict(label=label,command=command))))
    return key

def reset_or_delete(key):
    with _connect() as conn:
        result = conn.execute('DELETE FROM commands WHERE id=?',(key,))
        if not result.rowcount and key not in {x['id'] for x in defaults()}:
            raise KeyError(key)
