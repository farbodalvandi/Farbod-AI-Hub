"""Configurable SSH diagnostics for the Linux Health workspace."""
import os
import re
from datetime import datetime, timedelta
from pathlib import Path

import paramiko

CHECKS = [
    ("uptime", "Load and uptime", "uptime; cat /proc/loadavg; nproc", "load"),
    ("memory", "Memory and swap", "free -m; vmstat 1 2 | tail -1", "memory"),
    ("filesystem", "Filesystem capacity", "df -P -x tmpfs -x devtmpfs", "disk"),
    ("inode", "Inode", "df -Pi -x tmpfs -x devtmpfs", "inode"),
    ("services", "Failed services", "systemctl --failed --no-legend --no-pager 2>&1 | head -20", "services"),
    ("kernel", "Kernel errors", "journalctl -k -p err --since '-1 hour' --no-pager 2>&1 | tail -30", "kernel"),
    ("network", "Network status", "ip -br link; ip route; ss -s", "network"),
    ("time", "Time synchronization", "timedatectl show -p NTPSynchronized -p Timezone 2>&1", "time"),
    ("multipath", "Storage paths", "if command -v multipath >/dev/null 2>&1; then multipath -ll 2>&1 | head -400; else echo 'multipath unavailable'; fi", "multipath"),
]
EXTRA_CHECKS = [("qla", "QLogic HBA / QLA events"), ("chrony", "Chrony source and time quality")]

def diagnostic_options():
    from linux_health_library import catalogue
    return [{"id": item["id"], "label": item["label"], "default_selected": False} for item in catalogue()]

# Syslog lines often identify the PCI function rather than the FC host number.
# Match that function against the physical device path in sysfs before naming a port.
QLA_LOG = "if [ -r /var/log/messages ]; then date '+%Y-%m-%d %H:%M:%S'; tail -n 10000 /var/log/messages | grep -Ei 'qla2xxx|qla[0-9]+' | tail -n 100 || :; else echo MESSAGES_UNREADABLE; fi"
QLA_PORTS = "for h in /sys/class/fc_host/host*; do [ -d \"$h\" ] || continue; n=${h##*/}; driver=$(cat /sys/class/scsi_host/\"$n\"/proc_name 2>/dev/null); [ \"$driver\" = qla2xxx ] || continue; pci=$(readlink -f \"$h/device\"); printf '%s|%s|%s|%s|%s|%s\\n' \"$n\" \"$(cat \"$h/port_name\" 2>/dev/null)\" \"$(cat \"$h/port_state\" 2>/dev/null)\" \"$(cat \"$h/speed\" 2>/dev/null)\" \"$pci\" \"$driver\"; done"
FC_PATHS = "for d in /sys/class/scsi_device/*; do [ -d \"$d/device/block\" ] || continue; h=${d##*/}; h=${h%%:*}; for b in \"$d\"/device/block/*; do [ -e \"$b\" ] || continue; printf '%s|%s|%s\\n' \"host$h\" \"${b##*/}\" \"${d##*/}\"; done; done"
CHRONY = "if command -v chronyc >/dev/null 2>&1; then chronyc -n tracking 2>&1; printf '\\n--SOURCES--\\n'; chronyc -n sources 2>&1; printf '\\n--SOURCESTATS--\\n'; chronyc -n sourcestats 2>&1; else echo CHRONY_UNAVAILABLE; fi"

def time_report(output):
    if "CHRONY_UNAVAILABLE" in output:
        return "unknown", "chronyc is unavailable; see the basic time synchronization check"
    if "506 Cannot talk to daemon" in output or "permission denied" in output.lower():
        return "unknown", "chronyd could not be queried"
    def field(name):
        match = re.search(r"^" + re.escape(name) + r"\s*:\s*(.+)$", output, re.M | re.I)
        return match.group(1).strip() if match else "unavailable"
    ref, source, offset = field("Reference ID"), field("Ref time (UTC)"), field("Last offset")
    rms, dispersion = field("RMS offset"), field("Root dispersion")
    stats = output.split("--SOURCESTATS--", 1)[-1] if "--SOURCESTATS--" in output else ""
    selected = next((x for x in output.split("--SOURCES--", 1)[-1].split("--SOURCESTATS--", 1)[0].splitlines() if re.match(r"^\s*\^\*", x)), "") if "--SOURCES--" in output else ""
    name = selected.split()[1] if len(selected.split()) > 1 else "unavailable"
    jitter = "unavailable"
    for line in stats.splitlines():
        parts = line.split()
        if name != "unavailable" and len(parts) >= 8 and parts[0] == name:
            jitter = parts[-1]  # chronyc sourcestats Std Dev, an estimate of source jitter
            break
    details = f"RefID: {ref}; selected source: {name}; last offset: {offset}; RMS offset: {rms}; source Std Dev: {jitter}; root dispersion: {dispersion}; ref time: {source}"
    if ref == "unavailable" or source == "unavailable" or not selected:
        return "warning", "No selected external chrony source. " + details
    return "healthy", details

def fc_topology(inventory, scsi_paths, multipath):
    """Correlate Linux FC host, SCSI block name and multipath map where visible."""
    maps = {}
    current = None
    for line in multipath.splitlines():
        header = re.match(r"^(\S+)\s+\(([^)]+)\)\s+dm-\d+", line)
        if header:
            current = {"name": header.group(1), "wwid": header.group(2)}
        device = re.search(r"\b\d+:\d+:\d+:\d+\s+(sd[a-z]+)\b", line)
        if device and current:
            maps[device.group(1)] = current.copy()
    ports = {}
    for line in inventory.splitlines():
        p = line.split("|", 5)
        if len(p) == 6 and re.fullmatch(r"host\d+", p[0]):
            ports[p[0]] = {"host": p[0], "wwpn": p[1], "state": p[2], "speed": p[3], "pci": p[4], "paths": []}
    for line in scsi_paths.splitlines():
        p = line.split("|", 2)
        if len(p) == 3 and p[0] in ports and re.fullmatch(r"[a-zA-Z0-9_.-]+", p[1]):
            ports[p[0]]["paths"].append({"device": p[1], "scsi": p[2], "map": maps.get(p[1])})
    return list(ports.values())

def event_timeline(log_output):
    lines = log_output.splitlines()
    try:
        now = datetime.strptime(lines[0], "%Y-%m-%d %H:%M:%S")
    except (IndexError, ValueError):
        return []
    events = []
    for line in lines[1:]:
        match = re.match(r"^([A-Z][a-z]{2}\s+\d{1,2}\s+\d\d:\d\d:\d\d)\b", line)
        if not match or not re.search(r"error|failed|fault|abort|reset|timeout|link down|offline|loss of sync", line, re.I):
            continue
        try:
            at = datetime.strptime(f"{now.year} {match.group(1)}", "%Y %b %d %H:%M:%S")
            if at > now + timedelta(minutes=5): at = at.replace(year=now.year - 1)
        except ValueError:
            continue
        if now - timedelta(hours=24) <= at <= now + timedelta(minutes=5):
            events.append({"time": at.isoformat(), "source": "QLA / syslog", "message": line[:500]})
    return sorted(events, key=lambda e: e["time"], reverse=True)[:50]

def qla_report(log_output, inventory_output):
    if log_output.startswith("MESSAGES_UNREADABLE"):
        return "unknown", "Cannot read /var/log/messages; grant read access to the diagnostic account", log_output
    lines = log_output.splitlines()
    try:
        now = datetime.strptime(lines[0], "%Y-%m-%d %H:%M:%S")
    except (IndexError, ValueError):
        return "unknown", "Could not read the server clock", log_output
    ports = {}
    for row in inventory_output.splitlines():
        parts = row.split("|", 5)
        if len(parts) == 6 and re.fullmatch(r"host\d+", parts[0]):
            ports[parts[0]] = {"wwpn": parts[1], "state": parts[2], "speed": parts[3], "pci": parts[4]}
    if not ports:
        return "unknown", "No qla2xxx FC ports found in sysfs (or inventory is inaccessible)", log_output + "\n\nFC inventory:\n" + inventory_output

    recent = []
    for line in lines[1:]:
        stamp = re.match(r"^([A-Z][a-z]{2}\s+\d{1,2}\s+\d\d:\d\d:\d\d)\b", line)
        if not stamp:
            continue
        try:
            event = datetime.strptime(f"{now.year} {stamp.group(1)}", "%Y %b %d %H:%M:%S")
            if event > now + timedelta(minutes=5): event = event.replace(year=now.year - 1)
        except ValueError:
            continue
        if now - timedelta(hours=24) <= event <= now + timedelta(minutes=5):
            recent.append(line)
    bad = [line for line in recent if re.search(r"\b(error|failed|fault|abort|reset|timeout|timed out|link down|offline|loss of sync|isp system error)\b", line, re.I)]
    mapping = {}
    for line in bad:
        found = set(re.findall(r"\bhost\d+\b", line)) & ports.keys()
        for host, port in ports.items():
            pci = re.findall(r"\b[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]\b", port["pci"], re.I)
            if pci and re.search(r"\[" + re.escape(pci[-1]) + r"\]", line, re.I):
                found.add(host)
        for host in found: mapping[host] = ports[host]
    evidence = "QLogic FC ports (host | WWPN | state | speed | PCI path):\n" + (inventory_output or "none") + "\n/var/log/messages QLA events in last 24h:\n" + ("\n".join(recent) or "none")
    if bad:
        matched = ", ".join(f"{host} / {port['wwpn']} / {port['state']}" for host, port in sorted(mapping.items()))
        reason = f"{len(bad)} QLA error events in 24h; affected port(s): {matched}" if matched else f"{len(bad)} QLA error events in 24h; physical port could not be mapped from the log"
        return "critical" if matched else "warning", reason, evidence
    if recent:
        return "warning", f"{len(recent)} QLA log events in 24h; no explicit error keyword; review evidence", evidence
    return "healthy", "No QLA events found in the scanned /var/log/messages window (last 24h)", evidence

def judge(kind, output, code):
    if code != 0 or "permission denied" in output.lower():
        return "unknown", "Command failed or access is insufficient"
    try:
        if kind == "load":
            loads = re.search(r"^([\d.]+)\s+[\d.]+\s+[\d.]+\s+\d+/\d+", output, re.M)
            cores = int(output.strip().splitlines()[-1]); ratio = float(loads.group(1)) / cores
            if ratio >= 2: return "critical", f"One-minute load is {ratio:.1f}× CPU count"
            if ratio >= 1: return "warning", f"One-minute load is {ratio:.1f}× CPU count"
            return "healthy", "CPU load is within the initial threshold"
        if kind == "memory":
            line = next(x for x in output.splitlines() if x.startswith("Mem:"))
            p = line.split(); available = int(p[6]); total = int(p[1]); pct = available / total * 100
            return ("critical" if pct < 5 else "warning" if pct < 15 else "healthy"), f"Available memory: {pct:.0f}%"
        if kind in ("disk", "inode"):
            vals = [(int(m.group(1)), row) for row in output.splitlines()[1:] if (m := re.search(r"\s(\d+)%\s+", row))]
            if not vals: return "unknown", "Filesystem data could not be parsed"
            peak, row = max(vals)
            return ("critical" if peak >= 95 else "warning" if peak >= 85 else "healthy"), f"Peak usage: {peak}% ({row.split()[-1]})"
        if kind == "services":
            count = sum(bool(re.search(r"\bfailed\b", x, re.I)) for x in output.splitlines())
            return ("warning" if count else "healthy"), f"{count} failed services"
        if kind == "kernel":
            if "no journal files" in output.lower(): return "unknown", "Kernel journal is unavailable"
            count = len([x for x in output.splitlines() if x.strip() and not x.startswith("--")])
            return ("warning" if count else "healthy"), f"{count} kernel errors in the past hour; review context"
        if kind == "time":
            if "NTPSynchronized=yes" in output: return "healthy", "System time is synchronized"
            if "NTPSynchronized=no" in output: return "warning", "System time is not synchronized"
            return "unknown", "NTP status could not be determined"
        if kind == "multipath":
            if "unavailable" in output: return "unknown", "multipath is unavailable or not in PATH"
            if not output.strip(): return "unknown", "multipath returned no data; check LUNs and permissions"
            if re.search(r"\b(failed|faulty|offline)\b", output, re.I): return "critical", "A failed, faulty, or offline path was found"
            return "healthy", "No explicit path failure found; verify expected path count separately"
        return "unknown", "Network details are available for manual review"
    except (ValueError, IndexError, StopIteration, AttributeError, ZeroDivisionError):
        return "unknown", "Command output could not be parsed"


class HostTrustMissing(Exception):
    pass

class SSHConnectionFailed(Exception):
    pass


def diagnose(host, port, username, password, known_hosts, selected_checks=None):
    """Connect using a verified host key and return per-check evidence."""
    from linux_health_library import catalogue
    library = {item["id"]: item for item in catalogue()}
    selected = set(selected_checks or [])
    allowed = set(library)
    if not selected or not selected.issubset(allowed):
        raise ValueError("Select at least one valid diagnostic check")
    if not Path(known_hosts).is_file():
        raise HostTrustMissing("SSH known_hosts file is missing. Add and verify the server host key first.")
    ssh = paramiko.SSHClient()
    try:
        ssh.load_host_keys(known_hosts)
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
        ssh.connect(host, port=port, username=username, password=password,
                    timeout=8, auth_timeout=8, banner_timeout=8, allow_agent=False, look_for_keys=False)
        results = []
        for key, label, command, kind in CHECKS:
            if key not in selected or library[key]["modified"]:
                continue
            try:
                _, stdout, stderr = ssh.exec_command(command, timeout=12)
                stdout.channel.settimeout(12)
                output = (stdout.read(65536) + stderr.read(4096)).decode("utf-8", "replace")[:50000 if key == "multipath" else 12000]
                code = stdout.channel.recv_exit_status()
                status, reason = judge(kind, output, code)
            except Exception:
                status, reason, output = "unknown", "Command timed out or failed to run", ""
            results.append({"id": key, "label": label, "status": status, "reason": reason, "evidence": output})
        log_output = ""
        inventory_output = ""
        scsi_paths = ""
        if "qla" in selected and not library["qla"]["modified"]:
            try:
                _, log_out, _ = ssh.exec_command(QLA_LOG, timeout=12)
                log_out.channel.settimeout(12)
                log_output = log_out.read(65536).decode("utf-8", "replace")
                _, inv_out, _ = ssh.exec_command(QLA_PORTS, timeout=12)
                inv_out.channel.settimeout(12)
                inventory_output = inv_out.read(16384).decode("utf-8", "replace")
                status, reason, evidence = qla_report(log_output, inventory_output)
            except Exception:
                status, reason, evidence = "unknown", "Could not collect QLA logs or FC inventory", ""
            results.append({"id": "qla", "label": "QLogic HBA / QLA events", "status": status, "reason": reason, "evidence": evidence[:30000]})
            try:
                _, out, _ = ssh.exec_command(FC_PATHS, timeout=12)
                out.channel.settimeout(12)
                scsi_paths = out.read(32768).decode("utf-8", "replace")
            except Exception:
                scsi_paths = ""
        storage = next((item["evidence"] for item in results if item["id"] == "multipath"), "")
        topology = fc_topology(inventory_output, scsi_paths, storage) if "qla" in selected else []
        if "chrony" in selected and not library["chrony"]["modified"]:
            try:
                _, out, _ = ssh.exec_command(CHRONY, timeout=12)
                out.channel.settimeout(12)
                chrony_output = out.read(32768).decode("utf-8", "replace")
                chrony_status, chrony_reason = time_report(chrony_output)
            except Exception:
                chrony_output, chrony_status, chrony_reason = "", "unknown", "Could not query chronyc"
            results.append({"id": "chrony", "label": "Chrony source and time quality", "status": chrony_status,
                            "reason": chrony_reason, "evidence": chrony_output[:12000]})
        # Edited/custom scripts use execution status, never the original health parser.
        for key, item in library.items():
            if key not in selected or not item["modified"]:
                continue
            code = None
            try:
                _, stdout, stderr = ssh.exec_command(item["command"], timeout=12)
                stdout.channel.settimeout(12)
                output = (stdout.read(65536) + stderr.read(4096)).decode("utf-8", "replace")[:50000]
                code = stdout.channel.recv_exit_status()
                status = "unknown" if code == 0 else "warning"
                reason = "Command completed (exit 0). Review output; no automatic health verdict for edited/custom commands." if code == 0 else f"Command failed (exit {code}). Review output."
            except Exception:
                status, reason, output = "unknown", "Command timed out or failed to run", ""
            results.append(dict(id=key, label=item["label"], status=status, reason=reason, evidence=output, exit_code=code))
        for result in results:
            item = library[result["id"]]
            result["label"] = item["label"]
            result["command"] = item["command"]
        overall = ("critical" if any(x["status"] == "critical" for x in results) else
                   "warning" if any(x["status"] == "warning" for x in results) else
                   "unknown" if any(x["status"] == "unknown" for x in results) else "healthy")
        return {"host": host, "overall": overall, "checked_at": datetime.now().astimezone().isoformat(),
                "checks": results, "fc_topology": topology, "timeline": event_timeline(log_output) if "qla" in selected else []}
    except (paramiko.SSHException, OSError, EOFError) as exc:
        raise SSHConnectionFailed(f"SSH connection failed ({type(exc).__name__}); verify host key, network and credentials") from None
    finally:
        ssh.close()
