#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
service_label="com.fhw.aihub"
backup_label="com.fhw.aihub.backup"
agent_dir="$HOME/Library/LaunchAgents"
service_plist="$agent_dir/$service_label.plist"
backup_plist="$agent_dir/$backup_label.plist"

cd "$project_dir"
if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

data_dir="${FHW_DATA_DIR:-$HOME/Library/Application Support/FarbodAIHub}"
backup_dir="${FHW_BACKUP_DIR:-$HOME/Library/Application Support/FarbodAIHub Backups}"
port="${FHW_ASSET_PORT:-8000}"
host="${FHW_ASSET_HOST:-127.0.0.1}"
scheme="http"
if [[ "${FHW_ASSET_SSL:-0}" != "0" ]]; then scheme="https"; fi
app_url="$scheme://$host:$port"
mkdir -p "$data_dir/logs" "$data_dir/runtime" "$backup_dir" "$agent_dir"

pause_terminal() {
  if [[ -t 0 ]]; then read -r -p "Press Return to close…" _; fi
}
