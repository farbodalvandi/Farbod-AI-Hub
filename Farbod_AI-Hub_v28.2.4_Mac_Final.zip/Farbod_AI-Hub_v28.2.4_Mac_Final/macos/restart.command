#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
if [[ ! -f "$service_plist" ]]; then echo "Service is not installed. Run install_service.command first."; pause_terminal; exit 1; fi
launchctl print "gui/$UID/$service_label" >/dev/null 2>&1 || launchctl bootstrap "gui/$UID" "$service_plist"
launchctl kickstart -k "gui/$UID/$service_label"
echo "Farbod AI-Hub restart requested."
pause_terminal
