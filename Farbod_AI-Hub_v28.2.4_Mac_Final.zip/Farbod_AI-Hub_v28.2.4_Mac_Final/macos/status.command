#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
echo "Farbod AI-Hub v28.2.4"
if launchctl print "gui/$UID/$service_label" >/dev/null 2>&1; then echo "Service: loaded"; else echo "Service: stopped / not loaded"; fi
if curl -fsS "$app_url/healthz" >/dev/null 2>&1; then echo "Health: OK"; echo "URL: $app_url"; else echo "Health: unavailable"; fi
echo "Data: $data_dir"
echo "Logs: $data_dir/logs"
echo "Backups: $backup_dir"
pause_terminal
