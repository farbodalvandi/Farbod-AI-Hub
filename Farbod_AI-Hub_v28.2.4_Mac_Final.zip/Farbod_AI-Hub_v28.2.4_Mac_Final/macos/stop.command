#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"
if launchctl print "gui/$UID/$service_label" >/dev/null 2>&1; then launchctl bootout "gui/$UID/$service_label"; fi
echo "Farbod AI-Hub stopped. Auto Start remains installed and Start can load it again."
pause_terminal
