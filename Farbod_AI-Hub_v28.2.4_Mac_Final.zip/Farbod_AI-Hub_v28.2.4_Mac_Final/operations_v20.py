"""Farbod AI-Hub v20 control plane.

The control plane is deliberately safe-by-default: connectors are read-only,
agents create auditable plans, and medium/high-risk jobs require approval.
"""

from __future__ import annotations

import json
import os
import platform
from dataclasses import dataclass, asdict
from datetime import datetime, timezone


VERSION = "20.0"


@dataclass(frozen=True)
class AgentDefinition:
    key: str
    name: str
    icon: str
    domain: str
    purpose: str
    state: str = "Ready"


AGENTS = (
    AgentDefinition("health", "Health Agent", "activity", "Operations", "Correlates health, alerts and recent changes."),
    AgentDefinition("inventory", "Inventory Agent", "boxes", "Assets", "Finds missing, duplicate and inconsistent inventory data."),
    AgentDefinition("firmware", "Firmware Agent", "cpu", "Lifecycle", "Builds evidence-backed firmware readiness plans."),
    AgentDefinition("capacity", "Capacity Agent", "graph-up-arrow", "Planning", "Forecasts capacity from recorded observations."),
    AgentDefinition("san", "SAN Agent", "bezier2", "Storage Fabric", "Analyzes fabrics, paths, zoning and redundancy."),
    AgentDefinition("virtualization", "Virtualization Agent", "layers", "Compute", "Reviews hosts, clusters and dependency risk."),
    AgentDefinition("security", "Security Agent", "shield-check", "Governance", "Reviews access, configuration and audit evidence."),
    AgentDefinition("runbook", "Runbook Agent", "journal-code", "Automation", "Produces controlled, reversible execution plans."),
)


CONNECTOR_TYPES = (
    {"key": "redfish", "name": "HPE iLO / Redfish", "icon": "server", "protocol": "HTTPS", "capability": "Inventory + Health"},
    {"key": "oneview", "name": "HPE OneView / Synergy", "icon": "grid-3x3-gap", "protocol": "REST", "capability": "Frames + Profiles"},
    {"key": "vmware", "name": "VMware vCenter", "icon": "layers", "protocol": "SDK / API", "capability": "Hosts + Clusters"},
    {"key": "dell_storage", "name": "Dell Unity / PowerStore", "icon": "device-ssd", "protocol": "REST", "capability": "Arrays + Capacity"},
    {"key": "huawei_storage", "name": "Huawei OceanStor", "icon": "database", "protocol": "REST", "capability": "Pools + Health"},
    {"key": "brocade", "name": "Brocade Fabric OS", "icon": "diagram-3", "protocol": "REST / SSH", "capability": "Fabric + Ports"},
    {"key": "snmp", "name": "SNMP Infrastructure", "icon": "router", "protocol": "SNMPv3", "capability": "Metrics + Events"},
)


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_schema(db) -> None:
    conn = db.get_conn()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS v20_connectors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            connector_type TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            mode TEXT NOT NULL DEFAULT 'read-only',
            status TEXT NOT NULL DEFAULT 'Not configured',
            last_sync TEXT,
            created_by TEXT,
            created_at TEXT NOT NULL,
            UNIQUE(connector_type, endpoint)
        );
        CREATE TABLE IF NOT EXISTS v20_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            agent_key TEXT NOT NULL,
            action TEXT NOT NULL,
            target TEXT,
            risk TEXT NOT NULL DEFAULT 'low',
            status TEXT NOT NULL DEFAULT 'planned',
            approval_required INTEGER NOT NULL DEFAULT 0,
            requested_by TEXT,
            approved_by TEXT,
            evidence_json TEXT NOT NULL DEFAULT '[]',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS v20_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            severity TEXT NOT NULL DEFAULT 'info',
            source TEXT NOT NULL,
            title TEXT NOT NULL,
            details TEXT,
            correlation_key TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS v20_jobs_status ON v20_jobs(status, id DESC);
        CREATE INDEX IF NOT EXISTS v20_events_created ON v20_events(id DESC);
        """
    )
    conn.commit()
    conn.close()


def list_connectors(db):
    conn = db.get_conn()
    rows = conn.execute("SELECT * FROM v20_connectors ORDER BY id DESC").fetchall()
    conn.close()
    return rows


def add_connector(db, name, connector_type, endpoint, username):
    if connector_type not in {item["key"] for item in CONNECTOR_TYPES}:
        raise ValueError("Unsupported connector type")
    if not name.strip() or not endpoint.strip():
        raise ValueError("Name and endpoint are required")
    conn = db.get_conn()
    cur = conn.execute(
        "INSERT INTO v20_connectors(name,connector_type,endpoint,created_by,created_at) VALUES(?,?,?,?,?)",
        (name.strip(), connector_type, endpoint.strip(), username, utcnow()),
    )
    conn.commit()
    connector_id = cur.lastrowid
    conn.close()
    record_event(db, "info", "Connector Framework", f"Connector registered: {name.strip()}", endpoint.strip(), f"connector:{connector_id}")
    return connector_id


def mark_connector_sync(db, connector_id, username):
    now = utcnow()
    conn = db.get_conn()
    connector = conn.execute("SELECT * FROM v20_connectors WHERE id=?", (connector_id,)).fetchone()
    if connector is None:
        conn.close()
        raise ValueError("Connector not found")
    conn.execute("UPDATE v20_connectors SET status='Discovery queued',last_sync=? WHERE id=?", (now, connector_id))
    conn.commit()
    conn.close()
    job_id = create_job(
        db,
        title=f"Discover {connector['name']}",
        agent_key="inventory",
        action="read-only discovery",
        target=connector["endpoint"],
        risk="low",
        username=username,
        evidence=["Connector metadata", "Read-only policy", "Audit trail enabled"],
    )
    return job_id


def create_job(db, title, agent_key, action, target, risk, username, evidence=None):
    valid_agents = {agent.key for agent in AGENTS}
    if agent_key not in valid_agents:
        raise ValueError("Unknown agent")
    risk = risk if risk in {"low", "medium", "high", "critical"} else "medium"
    approval = int(risk in {"medium", "high", "critical"})
    status = "awaiting_approval" if approval else "queued"
    now = utcnow()
    conn = db.get_conn()
    cur = conn.execute(
        """INSERT INTO v20_jobs
           (title,agent_key,action,target,risk,status,approval_required,requested_by,evidence_json,created_at,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (title.strip(), agent_key, action.strip(), target.strip(), risk, status, approval,
         username, json.dumps(evidence or [], ensure_ascii=False), now, now),
    )
    conn.commit()
    job_id = cur.lastrowid
    conn.close()
    record_event(db, "warning" if approval else "info", "Agent Control Plane", title.strip(), f"Risk: {risk}; status: {status}", f"job:{job_id}")
    return job_id


def list_jobs(db, limit=100):
    conn = db.get_conn()
    rows = conn.execute("SELECT * FROM v20_jobs ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    conn.close()
    return rows


def transition_job(db, job_id, transition, username, is_admin=False):
    conn = db.get_conn()
    row = conn.execute("SELECT * FROM v20_jobs WHERE id=?", (job_id,)).fetchone()
    if row is None:
        conn.close()
        raise ValueError("Job not found")
    if transition == "approve":
        if not is_admin:
            conn.close()
            raise PermissionError("Administrator approval is required")
        if row["status"] != "awaiting_approval":
            conn.close()
            raise ValueError("Only waiting jobs can be approved")
        new_status, approved_by = "queued", username
    elif transition == "cancel":
        if row["status"] in {"completed", "cancelled"}:
            conn.close()
            raise ValueError("Job is already closed")
        new_status, approved_by = "cancelled", row["approved_by"]
    else:
        conn.close()
        raise ValueError("Unsupported transition")
    conn.execute(
        "UPDATE v20_jobs SET status=?,approved_by=?,updated_at=? WHERE id=?",
        (new_status, approved_by, utcnow(), job_id),
    )
    conn.commit()
    conn.close()
    record_event(db, "info", "Approval Gate", f"Job #{job_id} {new_status}", f"Actor: {username}", f"job:{job_id}")


def record_event(db, severity, source, title, details="", correlation_key=""):
    conn = db.get_conn()
    conn.execute(
        "INSERT INTO v20_events(severity,source,title,details,correlation_key,created_at) VALUES(?,?,?,?,?,?)",
        (severity, source, title, details, correlation_key, utcnow()),
    )
    conn.commit()
    conn.close()


def list_events(db, limit=30):
    conn = db.get_conn()
    rows = conn.execute("SELECT * FROM v20_events ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    conn.close()
    return rows


def _asset_counts(db):
    counts = {}
    for table in db.SCHEMAS:
        counts[table] = len(db.list_assets(table))
    return counts


def platform_snapshot(db):
    counts = _asset_counts(db)
    jobs = list_jobs(db, 200)
    connectors = list_connectors(db)
    events = list_events(db, 8)
    pending = sum(1 for job in jobs if job["status"] == "awaiting_approval")
    active = sum(1 for job in jobs if job["status"] in {"queued", "running"})
    return {
        "version": VERSION,
        "assets": sum(counts.values()),
        "counts": counts,
        "connectors": len(connectors),
        "pending_approvals": pending,
        "active_jobs": active,
        "agents": [asdict(agent) for agent in AGENTS],
        "events": [dict(event) for event in events],
        "runtime": "Docker" if os.path.exists("/.dockerenv") else "Native",
        "platform": platform.machine(),
    }


def health_payload(db):
    ensure_schema(db)
    connectors = list_connectors(db)
    jobs = list_jobs(db, 200)
    return {
        "status": "ok",
        "service": "FarbodAIHub-ControlPlane",
        "version": VERSION,
        "mode": "human-in-the-loop",
        "agents": len(AGENTS),
        "connectors": len(connectors),
        "pending_approvals": sum(1 for job in jobs if job["status"] == "awaiting_approval"),
    }
