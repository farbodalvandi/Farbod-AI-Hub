"""Offline RAID capacity estimation and a deterministic, resumable chat wizard.

Equal-sized disks; classic RAID 10 uses two-way mirrors. Controller limits,
filesystem/metadata overhead, compression and deduplication are not estimated.
"""
import re
from decimal import Decimal, InvalidOperation

LEVELS = ('0', '1', '5', '6', '10', '50', '60')
UNITS = {'GB': 10**9, 'TB': 10**12, 'GIB': 2**30, 'TIB': 2**40}
DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٫', '01234567890123456789.')


def normalized(value):
    return str(value).translate(DIGITS).strip()


def integer(value, label, minimum=0):
    text = normalized(value)
    if not re.fullmatch(r'[0-9]+', text) or not minimum <= int(text) <= 10000:
        raise ValueError(f'{label}: enter a whole number from {minimum} to 10000.')
    return int(text)


def raid_level(value):
    text = re.sub(r'\s+', '', normalized(value).upper()).replace('RAID', '').replace('رید', '')
    text = {'1+0': '10', '5+0': '50', '6+0': '60'}.get(text, text)
    if text not in LEVELS:
        raise ValueError('Choose RAID 0, 1, 5, 6, 10, 50 or 60.')
    return text


def calculate(level, disks, capacity, unit='TB', groups=2, spares=0):
    level = raid_level(level)
    disks = integer(disks, 'Total disks', 1)
    spares = integer(spares, 'Hot spares')
    unit = normalized(unit).upper()
    if unit not in UNITS:
        raise ValueError('Capacity unit must be GB, TB, GiB or TiB.')
    try:
        size = Decimal(normalized(capacity))
    except InvalidOperation:
        raise ValueError('Enter a positive capacity per disk.') from None
    if not size.is_finite() or size < Decimal("0.000001") or size > 1000000:
        raise ValueError('Capacity per disk must be between 0.000001 and 1000000.')
    active = disks - spares
    minimum = {'0': 2, '1': 2, '5': 3, '6': 4, '10': 4, '50': 6, '60': 8}[level]
    if active < minimum:
        raise ValueError(f'RAID {level} requires at least {minimum} active disks, excluding hot spares.')
    groups = integer(groups, 'RAID groups', 2) if level in ('50', '60') else 1
    if level == '10' and active % 2:
        raise ValueError('RAID 10 requires an even number of active disks (two disks per mirror).')
    if level in ('50', '60'):
        group_min = 3 if level == '50' else 4
        if active % groups or active // groups < group_min:
            raise ValueError(f'RAID {level}: active disks must divide equally into {groups} groups, with at least {group_min} disks per group.')
    data_disks = {'0': active, '1': 1, '5': active-1, '6': active-2,
                  '10': active//2, '50': active-groups, '60': active-2*groups}[level]
    tolerance = {'0': 'None. Any disk failure loses the array.',
                 '1': f'Up to {active-1} disk failures in one {active}-way mirror.',
                 '5': 'One disk failure in the array.', '6': 'Two disk failures in the array.',
                 '10': 'One failure per mirror pair; two failures in the same pair lose the array.',
                 '50': 'One failure per RAID 5 group; two in the same group lose the array.',
                 '60': 'Two failures per RAID 6 group; three in the same group lose the array.'}[level]
    disk_bytes = size * UNITS[unit]
    raw = disks * disk_bytes
    usable = data_disks * disk_bytes
    parity = (active-data_disks) * disk_bytes
    spare = spares * disk_bytes
    formulas = {'0': 'N × D', '1': 'D (one N-way mirror)', '5': '(N − 1) × D',
                '6': '(N − 2) × D', '10': '(N / 2) × D', '50': '(N − G) × D', '60': '(N − 2G) × D'}
    return dict(level=level, disks=disks, active_disks=active, spares=spares, groups=groups,
                capacity=float(size), unit={'GIB':'GiB', 'TIB':'TiB'}.get(unit,unit),
                raw_bytes=float(raw), usable_bytes=float(usable), overhead_bytes=float(parity),
                spare_bytes=float(spare), usable_tb=float(usable/10**12), usable_tib=float(usable/2**40),
                raw_tb=float(raw/10**12), overhead_tb=float(parity/10**12), spare_tb=float(spare/10**12),
                efficiency=float(usable/raw*100), tolerance=tolerance, formula=formulas[level])


def starts_wizard(q):
    q = normalized(q).lower()
    has_raid = bool(re.search(r'\braid\b|رید', q))
    return has_raid and (bool(re.search(r'\b(create|build|calculate|calculator|plan|configure|setup|start)\b|محاسبه|بساز|ساخت|می.?خوام', q)) or q in ('raid', 'رید'))


def parse_capacity(q):
    q = normalized(q).lower().replace('ترابایت','tb').replace('گیگابایت','gb')
    match = re.fullmatch(r'(\d+(?:\.\d+)?|\.\d+)\s*(tb|gb|tib|gib)?', q)
    if not match:
        raise ValueError('Enter the capacity of ONE disk, for example 1.92 TB or 960 GB. A number without a unit means TB.')
    return match[1], (match[2] or 'TB').upper()


def prompt(state):
    fa = state['language'] == 'fa'
    prompts = {
        'disks': ('How many disks will be in the RAID? (Exclude hot spares.)', 'چند دیسک در RAID دارید؟ دیسک‌های Hot Spare را حساب نکنید.'),
        'capacity': ('What is the capacity of ONE disk? Example: 1.92 TB or 960 GB. Without a unit, TB is assumed.', 'ظرفیت هر دیسک چقدر است؟ مثال: 1.92 TB یا 960 GB. عدد بدون واحد، TB در نظر گرفته می‌شود.'),
        'level': ('Which RAID level? Choose 0, 1, 5, 6, 10, 50 or 60.', 'کدام RAID؟ یکی از 0، 1، 5، 6، 10، 50 یا 60 را انتخاب کنید.'),
        'groups': ('How many equal RAID groups (spans)? Enter at least 2.', 'چند گروه RAID هم‌اندازه (Span) دارید؟ حداقل ۲ گروه لازم است.')}
    text = prompts[state['step']][int(fa)]
    return text + ('\nبرای لغو «لغو» و برای شروع مجدد «شروع مجدد» بنویسید.' if fa else '\nType cancel to stop, or restart to begin again.')


def dialog(q, state=None):
    """Return (answer, next_state, calculation), or None for normal AI routing."""
    command = normalized(q).lower()
    if state and command in ('cancel', 'stop', 'exit', 'لغو', 'خروج'):
        return ('محاسبه لغو شد.' if state['language']=='fa' else 'RAID calculation cancelled.'), None, None
    if starts_wizard(q) or (state and command in ('restart', 'start over', 'شروع مجدد')):
        state = {'step':'disks', 'language': 'fa' if re.search('[\u0600-\u06ff]',q) else (state or {}).get('language','en')}
        return prompt(state), state, None
    if not state:
        return None
    state = dict(state)
    try:
        if state['step'] == 'disks':
            value = re.sub(r'\s*(disks?|drives?|دیسک)\s*$', '', command)
            state['disks'] = integer(value, 'Disks', 2)
            state['step'] = 'capacity'
        elif state['step'] == 'capacity':
            capacity, unit = parse_capacity(q)
            # Validate finite, positive capacity with the shared calculation engine.
            calculate('0', state['disks'], capacity, unit)
            state.update(capacity=capacity, unit=unit, step='level')
        elif state['step'] == 'level':
            state['level'] = raid_level(q)
            if state['level'] in ('50','60'):
                if state['disks'] < (6 if state['level']=='50' else 8):
                    raise ValueError('RAID 50 needs at least 6 disks; RAID 60 needs at least 8. Choose another level or restart.')
                state['step'] = 'groups'
            else:
                result = calculate(state['level'],state['disks'],state['capacity'],state['unit'])
                return format_answer(result,state['language']), None, result
        elif state['step'] == 'groups':
            groups = integer(q, 'RAID groups', 2)
            result = calculate(state['level'],state['disks'],state['capacity'],state['unit'],groups)
            return format_answer(result,state['language']), None, result
    except ValueError as exc:
        prefix = 'ورودی معتبر نیست: ' if state['language']=='fa' else ''
        return prefix + str(exc) + '\n\n' + prompt(state), state, None
    return prompt(state), state, None


def format_answer(r, language='en'):
    topology = f"{r['disks']} × {r['capacity']:g} {r['unit']} · RAID {r['level']}"
    if r['level'] in ('50','60'):
        topology += f" · {r['groups']} groups × {r['active_disks']//r['groups']} disks"
    if language == 'fa':
        return (f"{topology}\nظرفیت قابل استفاده: {r['usable_tb']:,.4f} TB ≈ {r['usable_tib']:,.4f} TiB\n"
                f"ظرفیت خام: {r['raw_tb']:,.4f} TB\nفضای افزونگی: {r['overhead_tb']:,.4f} TB\n"
                f"بهره‌وری: {r['efficiency']:.2f}%\nفرمول: {r['formula']}\n"
                'N = تعداد دیسک فعال، D = ظرفیت هر دیسک، G = تعداد گروه‌ها.\n'
                'ظرفیت تخمینی قبل از فرمت و متادیتا است. دیسک‌ها هم‌اندازه فرض شده‌اند. RAID جایگزین بکاپ نیست.\n'
                'برای محاسبه جدید بنویسید: می‌خوام RAID بسازم')
    return (f"{topology}\nUsable capacity: {r['usable_tb']:,.4f} TB ≈ {r['usable_tib']:,.4f} TiB\n"
            f"Raw capacity: {r['raw_tb']:,.4f} TB\nRedundancy overhead: {r['overhead_tb']:,.4f} TB\n"
            f"Efficiency: {r['efficiency']:.2f}%\nFault tolerance: {r['tolerance']}\n"
            f"Formula: {r['formula']} (N = active disks, D = disk capacity, G = groups).\n"
            'Estimate before formatting and metadata. Equal-sized disks assumed. RAID is not a backup.\n'
            'For another calculation, say: I want to create a RAID.')


def assistant_payload(answer, state, calculation):
    return dict(answer=answer, provider='Offline RAID Calculator', assets=[], files=[], warning='',
                confidence=100, recommendations=[], activity=[{'agent':'RAID Calculator','text':'Local deterministic calculation; no model or network required.'}],
                orchestration={'mode':'RAID calculator','risk':'Read-only','agents':['RAID Calculator']},
                raid={'active':bool(state), 'step':state['step'] if state else None, 'result':calculation})
