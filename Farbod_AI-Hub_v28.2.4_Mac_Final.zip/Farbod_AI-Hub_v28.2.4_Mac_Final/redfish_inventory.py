"""Read-only Redfish import with owner-bound, expiring and conflict-checked previews."""
import base64, json, ssl, time, secrets, ipaddress, urllib.request, urllib.error
from urllib.parse import urlsplit, unquote
from contextlib import closing
import database as db

FIELDS=('manufacturer','model','serial_number','firmware','cpu','ram','ilo_ip')
class RedfishError(ValueError):pass
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):raise RedfishError('Redirects are not permitted for authenticated Redfish requests.')

def validate_ip(host):
    try:ip=ipaddress.ip_address(host)
    except ValueError:raise RedfishError('Enter an iLO IPv4 or IPv6 address, not a URL or hostname.')
    if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
        raise RedfishError('Loopback, link-local, multicast and reserved addresses are not allowed.')
    return '['+str(ip)+']' if ip.version==6 else str(ip)

def safe_path(path):
    u=urlsplit(str(path));decoded=unquote(u.path)
    if u.scheme or u.netloc or u.query or u.fragment or not decoded.startswith('/redfish/v1/') or '..' in decoded.split('/') or '\\' in decoded:
        raise RedfishError('Device returned an invalid Redfish resource path.')
    return u.path

def fetch(ip,user,password,verify=True,system_path='',get=None):
    host=validate_ip(ip)
    if not user or not password:raise RedfishError('Username and password are required.')
    context=ssl.create_default_context() if verify else ssl._create_unverified_context()
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect(),urllib.request.HTTPSHandler(context=context))
    auth='Basic '+base64.b64encode((user+':'+password).encode()).decode()
    def request(path):
        path=safe_path(path)
        if get:return get(path)
        req=urllib.request.Request('https://'+host+path,headers={'Accept':'application/json','Authorization':auth})
        try:
            with opener.open(req,timeout=10) as response:
                data=response.read(2*1024*1024+1)
            if len(data)>2*1024*1024:raise RedfishError('Redfish response exceeds 2 MiB.')
            result=json.loads(data)
            if not isinstance(result,dict):raise RedfishError('Redfish response is not an object.')
            return result
        except urllib.error.HTTPError as exc:raise RedfishError(f'Redfish HTTP {exc.code}. Check credentials and permissions.') from None
        except (urllib.error.URLError,TimeoutError,ssl.SSLError):raise RedfishError('Redfish connection or TLS verification failed. Check the address, certificate and network.') from None
        except (json.JSONDecodeError,UnicodeError):raise RedfishError('Device did not return valid JSON.') from None
    root=request('/redfish/v1/Systems/')
    members=[safe_path(m['@odata.id']) for m in (root.get('Members') or []) if isinstance(m,dict) and m.get('@odata.id')]
    if not members:raise RedfishError('No ComputerSystem resources found.')
    if len(members)>16:raise RedfishError('More than 16 systems returned; use a dedicated compute iLO endpoint.')
    if len(members)>1 and not system_path:return {'systems':members,'fields':{},'observations':{}}
    path=system_path or members[0]
    if path not in members:raise RedfishError('Select a system from the returned collection.')
    d=request(path);cpu=d.get('ProcessorSummary') or {};ram=d.get('MemorySummary') or {}
    proposal={'manufacturer':d.get('Manufacturer'),'model':d.get('Model'),'serial_number':d.get('SerialNumber'),
      'firmware':d.get('BiosVersion'),'cpu':f"{cpu.get('Count')} x {cpu.get('Model')}" if cpu.get('Count') and cpu.get('Model') else cpu.get('Model'),
      'ram':f"{ram['TotalSystemMemoryGiB']} GiB" if ram.get('TotalSystemMemoryGiB') is not None else None,'ilo_ip':ip}
    fields={k:str(v)[:1000] for k,v in proposal.items() if v is not None and str(v).strip()}
    return {'systems':members,'fields':fields,'observations':{'system_path':path,'power_state':str(d.get('PowerState') or 'Unknown'),
        'health':str((d.get('Status') or {}).get('Health') or 'Unknown'),'tls_verified':bool(verify),'read_at':time.time()}}

def preview(asset_id,user,result):
    row=db.get_asset('servers',asset_id)
    if row is None:raise RedfishError('Server not found.')
    old=dict(row);fields=result['fields']
    if old.get('serial_number') and fields.get('serial_number') and old['serial_number'].strip().casefold()!=fields['serial_number'].strip().casefold():
        raise RedfishError('Serial number does not match the selected server. Verify the target before importing.')
    token=secrets.token_urlsafe(32)
    with closing(db.get_conn()) as c,c:
        c.execute('DELETE FROM redfish_previews_v27 WHERE expires_at<?',(time.time(),))
        c.execute('INSERT INTO redfish_previews_v27 VALUES(?,?,?,?,?,?,?,?)',(token,user,'servers',asset_id,json.dumps(old),json.dumps(fields),json.dumps(result['observations']),time.time()+900))
    return token

def load_preview(token,user):
    with closing(db.get_conn()) as c:r=c.execute('SELECT * FROM redfish_previews_v27 WHERE token=? AND username=? AND expires_at>?',(token,user,time.time())).fetchone()
    if not r:raise RedfishError('Preview expired or does not belong to this account. Read the device again.')
    r=dict(r)
    for key in ('before','proposal','observations'):r[key]=json.loads(r[key+'_json'])
    return r

def apply(token,user,selected):
    if not selected or not set(selected)<=set(FIELDS):raise RedfishError('Select one or more allowed fields.')
    with closing(db.get_conn()) as c,c:
        c.execute('BEGIN IMMEDIATE')
        r=c.execute('SELECT * FROM redfish_previews_v27 WHERE token=? AND username=? AND expires_at>?',(token,user,time.time())).fetchone()
        if not r:raise RedfishError('Preview expired, already applied or owned by another account.')
        before=json.loads(r['before_json']);proposal=json.loads(r['proposal_json'])
        current=c.execute('SELECT * FROM servers WHERE id=? AND deleted_at IS NULL',(r['asset_id'],)).fetchone()
        if not current:raise RedfishError('Server no longer exists.')
        for key in selected:
            if key not in proposal:raise RedfishError('A selected field was not returned by Redfish.')
            if current[key]!=before.get(key):raise RedfishError('Inventory changed after preview. Read the device again to avoid overwriting newer data.')
        if current['serial_number']!=before.get('serial_number'):raise RedfishError('Server identity changed after preview.')
        c.create_function('audit_actor',0,lambda:user)
        c.execute('UPDATE servers SET '+','.join('"'+k+'"=?' for k in selected)+",updated_at=strftime('%Y-%m-%dT%H:%M:%f','now') WHERE id=?",(*[proposal[k] for k in selected],r['asset_id']))
        c.execute('DELETE FROM redfish_previews_v27 WHERE token=?',(token,))
        return r['asset_id']
