"""Unified FastAPI/ASGI launcher for Farbod AI-Hub v24.8.2."""
from app import asgi_app, HOST, PORT, USE_SSL, CERT_FILE, KEY_FILE, TRUST_PROXY, _ensure_self_signed_cert
import uvicorn

if __name__ == "__main__":
    tls = USE_SSL and _ensure_self_signed_cert()
    uvicorn.run(asgi_app, host=HOST, port=PORT,
                ssl_certfile=CERT_FILE if tls else None,
                ssl_keyfile=KEY_FILE if tls else None,
                proxy_headers=TRUST_PROXY)
