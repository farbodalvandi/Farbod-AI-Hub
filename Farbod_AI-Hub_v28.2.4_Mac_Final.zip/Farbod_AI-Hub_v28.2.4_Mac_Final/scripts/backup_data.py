#!/usr/bin/env python3
"""Create a consistent, rotated backup of Farbod AI-Hub application data."""
from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # keep the data utility usable in minimal recovery environments
    def load_dotenv(*args, **kwargs):
        return False

PROJECT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_DIR / ".env", override=False)


def resolved(name: str, default: Path) -> Path:
    value = os.environ.get(name)
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve() if value else default.resolve()


DATA_DIR = resolved("FHW_DATA_DIR", PROJECT_DIR)
BACKUP_DIR = resolved("FHW_BACKUP_DIR", Path.home() / "Library/Application Support/FarbodAIHub Backups")
RETENTION = max(1, int(os.environ.get("FHW_BACKUP_RETENTION", "14")))
INCLUDE_ISO = os.environ.get("FHW_BACKUP_INCLUDE_ISO", "0").lower() not in {"0", "false", "no", ""}


def add_tree(archive: zipfile.ZipFile, root: Path, prefix: str) -> int:
    if not root.exists():
        return 0
    count = 0
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if not INCLUDE_ISO and "isos" in path.parts:
            continue
        archive.write(path, Path(prefix) / path.relative_to(root))
        count += 1
    return count


def main() -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    # Microseconds avoid overwriting the current archive when an immediate
    # restore first creates its safety snapshot in the same second.
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    target = BACKUP_DIR / f"FarbodAIHub_Backup_{stamp}.zip"
    db_path = DATA_DIR / "instance/dcam.db"
    manifest = {"created_utc": stamp, "version": "28.1.3", "data_directory": str(DATA_DIR),
                "includes_iso": INCLUDE_ISO, "files": 0}
    with tempfile.TemporaryDirectory(prefix="fhw-backup-") as temporary:
        snapshot = Path(temporary) / "dcam.db"
        if db_path.exists():
            with sqlite3.connect(db_path) as source, sqlite3.connect(snapshot) as destination:
                source.backup(destination)
        pending = target.with_suffix(".zip.partial")
        with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            if snapshot.exists():
                archive.write(snapshot, "instance/dcam.db")
                manifest["files"] += 1
            secret = DATA_DIR / "instance/secret.key"
            if secret.exists():
                archive.write(secret, "instance/secret.key")
                manifest["files"] += 1
            for folder in ("knowledge", "equipment_files", "bank_connection_info", "subobject_files", "profile_images"):
                archive.writestr(folder + "/", b"")  # Preserve empty directories during restore.
                manifest["files"] += add_tree(archive, DATA_DIR / folder, folder)
            if INCLUDE_ISO:
                archive.writestr("instance/isos/", b"")
                manifest["files"] += add_tree(archive, DATA_DIR / "instance/isos", "instance/isos")
            archive.writestr("backup-manifest.json", json.dumps(manifest, indent=2))
        # Do not expose an incomplete archive if the process is interrupted.
        with zipfile.ZipFile(pending, "r") as archive:
            bad_member = archive.testzip()
            if bad_member:
                pending.unlink(missing_ok=True)
                raise RuntimeError(f"Backup verification failed at {bad_member}")
        os.replace(pending, target)
    backups = sorted(BACKUP_DIR.glob("FarbodAIHub_Backup_*.zip"), reverse=True)
    for old in backups[RETENTION:]:
        old.unlink(missing_ok=True)
    print(f"Backup created: {target} ({manifest['files']} data files; retention {RETENTION})")
    return target


if __name__ == "__main__":
    main()
