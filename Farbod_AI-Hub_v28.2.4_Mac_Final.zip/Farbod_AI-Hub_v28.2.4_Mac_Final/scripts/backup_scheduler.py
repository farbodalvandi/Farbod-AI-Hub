#!/usr/bin/env python3
"""Run a due configured backup; safe to tick from the app and Docker service."""
from __future__ import annotations

import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR))
import backup_manager


def tick() -> None:
    settings = backup_manager.load_settings()
    if not settings.get("enabled") or settings.get("schedule") not in {"daily", "weekly"}:
        return
    now = datetime.now()
    try:
        hour, minute = (int(part) for part in settings.get("time", "02:00").split(":"))
        weekday = int(settings.get("weekday", 6))
    except (TypeError, ValueError):
        return
    if not (0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= weekday <= 6):
        return
    if now.hour * 60 + now.minute < hour * 60 + minute:
        return
    if settings["schedule"] == "weekly" and now.weekday() != weekday:
        return
    key = now.date().isoformat() if settings["schedule"] == "daily" else f"{now.isocalendar().year}-W{now.isocalendar().week:02d}"
    status = backup_manager.load_status()
    if status.get("last_scheduled_key") == key:
        return
    lock = Path(backup_manager.settings_path().parent) / "backup-scheduler.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        # Recover a lock left behind by an abruptly terminated scheduler.
        try:
            owner_pid = int(lock.read_text(encoding="ascii").strip())
            os.kill(owner_pid, 0)
            return
        except (OSError, ValueError):
            lock.unlink(missing_ok=True)
            try:
                descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                return
    os.write(descriptor, str(os.getpid()).encode("ascii"))
    os.close(descriptor)
    try:
        # Recheck after obtaining the cross-process lock.
        status = backup_manager.load_status()
        if status.get("last_scheduled_key") == key:
            return
        backup_manager.save_status({**status, "last_scheduled_key": key,
                                   "last_attempt_at": now.astimezone().isoformat(),
                                   "result": "running"})
        env = os.environ.copy()
        env.update({"FHW_BACKUP_DIR": settings["directory"],
                    "FHW_BACKUP_RETENTION": str(settings["retention"]),
                    "FHW_BACKUP_INCLUDE_ISO": "1" if settings.get("include_iso") else "0"})
        try:
            completed = subprocess.run([sys.executable, str(PROJECT_DIR / "scripts" / "backup_data.py")],
                                       cwd=PROJECT_DIR, env=env, capture_output=True, text=True, timeout=24 * 3600)
            ok = completed.returncode == 0
            output = (completed.stdout or completed.stderr).strip()[-2000:]
            backup_manager.save_status({**backup_manager.load_status(),
                "result": "success" if ok else "error", "message": output,
                "last_success_at": datetime.now().astimezone().isoformat() if ok else status.get("last_success_at")})
        except Exception as exc:
            backup_manager.save_status({**backup_manager.load_status(), "result": "error", "message": str(exc)[:2000]})
    finally:
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    tick()
