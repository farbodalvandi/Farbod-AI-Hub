#!/usr/bin/env python3
"""Restore a verified Farbod AI-Hub archive. Stop all app/worker processes first."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

DATA_ITEMS = ("knowledge", "equipment_files", "bank_connection_info", "subobject_files", "profile_images", "instance/isos")


def validate(archive: zipfile.ZipFile) -> list[str]:
    names = archive.namelist()
    if "backup-manifest.json" not in names or "instance/dcam.db" not in names:
        raise ValueError("Archive is missing its manifest or SQLite database.")
    if archive.testzip():
        raise ValueError("Archive CRC verification failed.")
    for info in archive.infolist():
        path = PurePosixPath(info.filename)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("Archive contains an unsafe path.")
        if info.filename == "backup-manifest.json" or info.filename in {"instance/dcam.db", "instance/secret.key"}:
            continue
        if not any(info.filename == folder or info.filename.startswith(folder + "/") for folder in DATA_ITEMS):
            raise ValueError(f"Archive contains an unexpected path: {info.filename}")
        if info.file_size > 8 * 1024 * 1024 * 1024:
            raise ValueError("Archive contains a file larger than the 8 GB restore limit.")
    return names


def restore(backup: Path, data_dir: Path) -> None:
    backup = backup.resolve(strict=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(backup) as archive:
        validate(archive)
        manifest = json.loads(archive.read("backup-manifest.json"))
        with tempfile.TemporaryDirectory(prefix="fhw-restore-", dir=data_dir) as temp_name:
            stage = Path(temp_name)
            for info in archive.infolist():
                if info.is_dir():
                    stage.joinpath(*PurePosixPath(info.filename).parts).mkdir(parents=True, exist_ok=True)
                    continue
                target = stage.joinpath(*PurePosixPath(info.filename).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, target.open("wb") as dest:
                    shutil.copyfileobj(source, dest, 1024 * 1024)
            db_check = stage / "instance/dcam.db"
            with sqlite3.connect(f"file:{db_check}?mode=ro", uri=True) as connection:
                if connection.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise ValueError("The database in this backup failed SQLite integrity check.")
            # Preserve current data before changing any files.
            os.environ["FHW_DATA_DIR"] = str(data_dir)
            from backup_data import main as create_backup
            safety_copy = create_backup()
            print(f"Safety backup created: {safety_copy}")
            for folder in DATA_ITEMS:
                if folder == "instance/isos" and not manifest.get("includes_iso"):
                    continue
                incoming = stage / folder
                destination = data_dir / folder
                replacement = data_dir / f".{folder}.restore-new"
                previous = data_dir / f".{folder}.restore-old"
                shutil.rmtree(replacement, ignore_errors=True)
                if incoming.exists():
                    shutil.copytree(incoming, replacement)
                else:
                    replacement.mkdir(parents=True)
                if previous.exists():
                    shutil.rmtree(previous)
                if destination.exists():
                    os.replace(destination, previous)
                os.replace(replacement, destination)
            instance = data_dir / "instance"
            instance.mkdir(exist_ok=True)
            for name in ("secret.key", "dcam.db"):
                incoming = stage / "instance" / name
                if incoming.exists():
                    temp_file = instance / f".{name}.restore-new"
                    shutil.copy2(incoming, temp_file)
                    os.replace(temp_file, instance / name)
            print(f"Restored backup created at {manifest.get('created_utc', 'unknown UTC time')} into {data_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup", required=True, type=Path)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    restore(args.backup, args.data_dir.resolve())
