#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

if [[ ! -x .venv/bin/python ]]; then
  echo "Virtual environment not found. Run ./scripts/setup_macos.sh first." >&2
  exit 1
fi

host="${FHW_ASSET_HOST:-0.0.0.0}"
port="${FHW_ASSET_PORT:-443}"
export FHW_ASSET_HOST="$host" FHW_ASSET_PORT="$port"
exec .venv/bin/python run_v20.py
