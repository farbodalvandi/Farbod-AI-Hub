(() => {
  'use strict';
  const level = document.getElementById('raid-level');
  const groupField = document.getElementById('raid-groups-field');
  const groups = document.getElementById('raid-groups');
  function update() {
    const nested = ['50','60'].includes(level.value);
    groupField.hidden = !nested;
    groups.disabled = !nested;
    groups.required = nested;
  }
  level.addEventListener('change', update);
  update();
})();
