/* 28.0.0: Glassy Light and Cream Light; retired Forest migrates to Glassy Light. */
(function(){
'use strict';
const root=document.documentElement;
const palettes=[
 ['frosted-dark','Frosted Dark'],
 ['frosted-pearl','Frosted Pearl'],
 ['soft-glass','Glassy Light',['#e8edf4','#f4f7fb','#ffffff','#304d78']],
 ['cream','Cream Light',['#eeede2','#f8f6ee','#ffffff','#943e24']],
 ['steel','Steel Blue',['#06141B','#11212D','#253745','#4A5C6A','#9BA8AB','#CCD0CF']],
];
const read=k=>{try{return localStorage.getItem(k)}catch(_){return null}};
const write=(k,v)=>{try{localStorage.setItem(k,v)}catch(_){}};
const text=s=>typeof window.uiText==='function'?window.uiText(s):s;
function apply(id,persist){
 if(['forest','rose'].includes(id))id='soft-glass';
 if(['dark','midnight-amber'].includes(id))id='steel';
 if(!palettes.some(p=>p[0]===id))id='cream';
 const mode=['soft-glass','cream','frosted-pearl'].includes(id)?'light':'dark';
 root.dataset.theme=mode;root.dataset.themeMode=mode;root.dataset.themePreset=id;
 delete root.dataset.accent;
 if(persist){write('fhw-palette-v27',id);write('fhw-theme',mode);write('fhw-theme-mode',mode);write('fhw-theme-preset',id);}
 document.querySelectorAll('[data-palette-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.paletteChoice===id)));
 document.querySelectorAll('[data-theme-trigger]').forEach(b=>{b.title=text(palettes.find(p=>p[0]===id)[1]);const i=b.querySelector('[data-theme-icon]');if(i&&i.tagName.toLowerCase()!=='svg')i.outerHTML='<svg data-theme-icon aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 1.4-3.4 1.5 1.5 0 0 1 1.1-2.6H17a4 4 0 0 0 4-4c0-4.4-4-8-9-8Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="11" cy="7" r=".8"/><circle cx="15.5" cy="8.5" r=".8"/></svg>';});
}
apply(read('fhw-palette-v27')||read('fhw-theme-preset')||'frosted-dark',false);
let trigger;
function close(focus){const p=document.getElementById('themePopover');if(p)p.hidden=true;document.querySelectorAll('[data-theme-trigger]').forEach(b=>b.setAttribute('aria-expanded','false'));if(focus&&trigger)trigger.focus();}
function build(){
 if(document.getElementById('themePopover'))return;
 const p=document.createElement('section');p.id='themePopover';p.className='theme-popover';p.hidden=true;p.setAttribute('aria-label',text('Theme'));
 p.innerHTML=`<div class="theme-popover-head"><div><strong>${text('Theme')}</strong><small>${text('Appearance is saved on this device.')}</small></div><button type="button" class="theme-popover-close" aria-label="${text('Close theme settings')}">×</button></div><div class="palette-options">${palettes.map(([id,label])=>`<button type="button" class="theme-mode-choice palette-choice" data-palette-choice="${id}"><span>${text(label)}</span></button>`).join('')}</div>`;
 document.body.appendChild(p);p.querySelector('.theme-popover-close').addEventListener('click',()=>close(true));p.querySelectorAll('[data-palette-choice]').forEach(b=>b.addEventListener('click',()=>apply(b.dataset.paletteChoice,true)));
 apply(root.dataset.themePreset,false);
}
document.addEventListener('DOMContentLoaded',()=>{
 build();document.querySelectorAll('[data-theme-trigger]').forEach(b=>{b.setAttribute('aria-controls','themePopover');b.setAttribute('aria-expanded','false');b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const p=document.getElementById('themePopover');if(!p.hidden){close(false);return;}trigger=b;p.hidden=false;b.setAttribute('aria-expanded','true');p.querySelector('[aria-pressed="true"]')?.focus();});});
 document.addEventListener('click',e=>{const p=document.getElementById('themePopover');if(p&&!p.contains(e.target)&&!e.target.closest('[data-theme-trigger]'))close(false);});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close(true);});
});
window.addEventListener('storage',e=>{if(e.key==='fhw-palette-v27')apply(e.newValue,false);});
})();
