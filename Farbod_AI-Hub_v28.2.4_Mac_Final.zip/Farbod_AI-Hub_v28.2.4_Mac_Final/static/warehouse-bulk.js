/* Filters preserve selected rows; submit reports total selection, including hidden rows. */
document.querySelectorAll('[data-bulk-issue]').forEach(form=>{
  const rows=[...form.querySelectorAll('[data-stock-row]')], search=form.querySelector('[data-unit-search]');
  function update(){
    let count=0,units=0;
    rows.forEach(row=>{const selected=row.querySelector('[type=checkbox]').checked,qty=row.querySelector('[type=number]');qty.disabled=!selected;if(selected){count++;units+=Number(qty.value)||0}});
    form.querySelector('[data-selection-count]').textContent=`${count} / ${rows.length} · ${units} ${document.documentElement.lang==='fa'?'واحد انتخاب‌شده':'units selected'}`;
    form.querySelector('[data-issue-submit]').disabled=!count;
  }
  search.addEventListener('input',()=>{const q=search.value.trim().toLocaleLowerCase();rows.forEach(row=>row.hidden=!row.textContent.toLocaleLowerCase().includes(q))});
  form.querySelector('[data-select-visible]').addEventListener('click',()=>{rows.filter(r=>!r.hidden).forEach(r=>r.querySelector('[type=checkbox]').checked=true);update()});
  form.querySelector('[data-clear-selection]').addEventListener('click',()=>{rows.forEach(r=>r.querySelector('[type=checkbox]').checked=false);update()});
  form.addEventListener('change',update);form.addEventListener('input',update);update();
});
