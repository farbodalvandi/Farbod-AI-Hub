import os, tempfile, sys, io
os.environ['FHW_DATA_DIR']=tempfile.mkdtemp(prefix='hub-columns-')
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import database as db
# Construct the baseline schema and a pre-upgrade row.
for spec in db.BASE_SCHEMAS.values(): spec['fields']=[f for f in spec['fields'] if f[0]!='owner']
db.init_db()
old=db.create_asset('servers',{'model':'Legacy','power_count':'2'},'admin')
for spec in db.BASE_SCHEMAS.values(): spec['fields'].insert(4,('owner','Owner','text',None))
import app
from openpyxl import load_workbook
client=app.app.test_client()
with client.session_transaction() as session:
    session.update(username='admin',_csrf_token='test-token',search_csrf='test-token')
assert db.get_asset('servers',old)['model']=='Legacy'
for table in db.SCHEMAS:
    assert 'owner' in db.get_asset('servers',old).keys()
    response=client.post('/assets/'+table+'/columns',data={'csrf':'test-token','action':'add','label':'Service Team','field_type':'text'})
    assert response.status_code==302,(table,response.text)
    key=db.custom_fields(table)[0]['field_key']
    row_id=db.create_asset(table,{'owner':'Farbod',key:'Operations','power_count':'2','port_count':'32'},'admin')
    assert db.get_asset(table,row_id)[key]=='Operations'
    page=client.get('/assets/'+table)
    assert page.status_code==200,(table,page.text[:1000])
    assert 'Service Team' in page.text and 'Farbod' in page.text
    assert client.get(f'/assets/{table}/{row_id}/edit').status_code==200
    csv=client.get('/export/'+table+'.csv')
    assert csv.status_code==200 and 'Operations' in csv.text
    excel=client.get('/export/'+table+'.xlsx')
    assert excel.status_code==200
    rows=list(load_workbook(io.BytesIO(excel.content)).active.values)
    assert any('Operations' in row for row in rows)
    db.init_db()
    assert any(f[0]==key for f in db.SCHEMAS[table]['fields'])
    r=client.post('/assets/'+table+'/columns',data={'csrf':'test-token','action':'remove','field_key':key,'confirmed':'no'})
    assert db.custom_fields(table)
    r=client.post('/assets/'+table+'/columns',data={'csrf':'test-token','action':'remove','field_key':key,'confirmed':'yes'})
    assert not db.custom_fields(table)
    assert db.get_asset(table,row_id)[key]=='Operations'
    assert all(f[0]!=key for f in db.SCHEMAS[table]['fields'])
    try: db.remove_custom_field(table,'owner','admin')
    except ValueError: pass
    else: raise AssertionError('built-in removal allowed')
    print('PASS',table,'CRUD/forms/CSV/Excel/restart/confirmation')
assert client.post('/assets/servers/columns',data={'action':'add','label':'Bad'}).status_code==403
print('PASS migration and CSRF')
