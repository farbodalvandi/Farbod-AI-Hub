import csv
import io
import time
from contextlib import closing
import pytest
import database as db

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(db,'BASE_DIR',str(tmp_path))
    monkeypatch.setattr(db,'DB_FILE',str(tmp_path/'instance'/'test.db'))
    db.init_db()
    from app import app
    with closing(db.get_conn()) as conn,conn:
        conn.execute("INSERT OR IGNORE INTO users(username,password_hash,role,full_name,active) VALUES ('equipment-admin','unused','admin','Admin',1)")
    c=app.test_client()
    with c.session_transaction() as sess:
        sess.update(username='equipment-admin',last_activity=int(time.time()),_csrf_token='csrf-test')
    return c

def post(c,path,**data):
    result=c.post(path,data=dict(csrf='csrf-test',**data),follow_redirects=False)
    assert result.status_code in (302,303,307),result.text
    return result

def test_equipment_empty_bank_create_edit_export_delete(client):
    assert client.get('/equipment').status_code==200
    post(client,'/equipment/bank',name='QA Profiles')
    post(client,'/equipment/bank',name='QA Profiles')  # Duplicate must not leave SQLite locked.
    bank=next(b['id'] for b in db.list_equipment_banks() if b['name']=='QA Profiles')
    assert client.get(f'/equipment?bank={bank}').status_code==200
    post(client,'/equipment/subcategory',bank_id=str(bank),name='Servers')
    post(client,'/equipment/subcategory',bank_id=str(bank),name='Servers')  # Duplicate recovery.
    sub=db.list_equipment_subcategories(bank)[0]['id']
    url=f'/equipment?bank={bank}&sub={sub}'
    assert client.get(url).status_code==200
    post(client,'/equipment/record',subcategory_id=str(sub),name='Rack Server',model='DL380',serial_number='SN-1')
    row=db.list_equipment_records(sub)[0]
    page=client.get(url+f'&edit={row["id"]}')
    assert page.status_code==200 and 'SN-1' in page.text
    post(client,'/equipment/record',subcategory_id=str(sub),record_id=str(row['id']),name='Updated Server',model='DL380 Gen11',serial_number='SN-1')
    exported=client.get(f'/equipment/records/{sub}.csv')
    assert exported.status_code==200
    rows=list(csv.DictReader(io.StringIO(exported.content.decode('utf-8-sig'))))
    assert rows[0]['name']=='Updated Server' and rows[0]['model']=='DL380 Gen11'
    post(client,f'/equipment/record/{row["id"]}/delete')
    assert not db.list_equipment_records(sub)
    assert client.get(url).status_code==200

@pytest.mark.parametrize('kind',['csv','xlsx'])
def test_import_profiles(client,kind):
    bank=db.create_equipment_bank('Import Bank');sub=db.create_equipment_subcategory(bank['id'],'Imported')
    if kind=='csv': payload=b'name,model,serial_number\nImported Server,DL360,IMPORT-1\n'
    else:
        from openpyxl import Workbook
        wb=Workbook();wb.active.append(['name','model','serial_number']);wb.active.append(['Imported Server','DL360','IMPORT-1'])
        out=io.BytesIO();wb.save(out);payload=out.getvalue()
    response=client.post('/equipment/records/import',data={'csrf':'csrf-test','subcategory_id':str(sub['id'])},files={'file':('profiles.'+kind,payload)},follow_redirects=False)
    assert response.status_code in (302,303,307),response.text
    rows=db.list_equipment_records(sub['id'])
    assert len(rows)==1 and rows[0]['serial_number']=='IMPORT-1'
    page=client.get(f'/equipment?bank={bank["id"]}&sub={sub["id"]}')
    assert page.status_code==200 and 'Imported Server' in page.text
