"""Regression checks for HTML served through a TLS-terminating Docker proxy."""
from html.parser import HTMLParser
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from webcore import WebApp, render_template, request, url_for

ROOT = Path(__file__).resolve().parents[1]


class Page(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.assets, self.login_token = [], None
        self.in_login = False
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'form':
            self.in_login = attrs.get('id') == 'login-form'
        if tag == 'input' and self.in_login and attrs.get('name') == 'csrf':
            self.login_token = attrs.get('value')
        if tag in ('script', 'img', 'link'):
            url = attrs.get('src') or attrs.get('href')
            if url:
                self.assets.append(url)

    def handle_endtag(self, tag):
        if tag == 'form':
            self.in_login = False


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv('FHW_SECURE_COOKIES', '1')
    app = WebApp('https-test', str(ROOT / 'templates'), str(ROOT / 'static'))
    app.secret_key = 'test-only-session-key-not-for-deployment'
    app.templates.env.filters['tr'] = lambda value: value
    app.templates.env.globals.update(
        _=lambda value: value, current_user=None, APP_VERSION='26.3.3',
        ui_language='en', ui_direction='ltr',
    )

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            return {'csrf_accepted': True}
        return render_template('login.html')

    @app.route('/hardware-hub')
    def hardware_hub():
        return 'hub'

    @app.route('/language', methods=['POST'])
    def set_language():
        return 'ok'

    @app.route('/online')
    def online_users_api():
        return {'users': []}

    @app.route('/photo/<int:user_id>')
    def profile_photo(user_id):
        return 'photo'

    @app.route('/probe')
    def probe():
        return {'url': url_for('login', next='/hardware-hub?a=1&b=2')}

    async def internal_http(scope, receive, send):
        if scope['type'] == 'http':
            scope = dict(scope, scheme='http')
            scope['headers'] = list(scope['headers']) + [(b'x-forwarded-proto', b'https')]
        await app.fastapi(scope, receive, send)

    with TestClient(internal_http, base_url='https://10.100.1.220') as instance:
        yield instance


def test_login_assets_keep_browser_origin_and_are_available(client):
    response = client.get('/login')
    assert response.status_code == 200
    page = Page(response.text)
    assert len(page.assets) > 10
    assert "default-src 'self'" in response.headers['content-security-policy']
    for asset in page.assets:
        assert asset.startswith('/static/') and not asset.startswith('//'), asset
        loaded = client.get(asset)
        assert loaded.status_code == 200, asset
        if '.css' in asset:
            assert loaded.headers['content-type'].startswith('text/css')


def test_form_csrf_works_without_javascript_and_rejects_missing_token(client):
    response = client.get('/login')
    token = Page(response.text).login_token
    assert token
    assert 'secure' in response.headers['set-cookie'].lower()
    assert client.post('/login', data={'username': 'test'}).status_code == 403
    assert client.post('/login', data={'csrf': 'wrong-token'}).status_code == 403
    accepted = client.post('/login', data={'csrf': token})
    assert accepted.status_code == 200
    assert accepted.json()['csrf_accepted'] is True


def test_internal_links_preserve_query_encoding(client):
    assert client.get('/probe').json()['url'] == '/login?next=%2Fhardware-hub%3Fa%3D1%26b%3D2'
