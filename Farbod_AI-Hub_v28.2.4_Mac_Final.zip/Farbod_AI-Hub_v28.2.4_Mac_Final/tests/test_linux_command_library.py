import importlib
import io
import pytest
import linux_health_library as library
import linux_health_service as service

@pytest.fixture
def store(tmp_path, monkeypatch):
    monkeypatch.setenv('FHW_DATA_DIR', str(tmp_path))
    return tmp_path

def test_persist_edit_reset_and_delete(store):
    original = library.catalogue()
    assert len(original) == 11
    key = library.save_command(None, 'Custom automation', 'printf hello')
    importlib.reload(library)
    assert any(x['id'] == key for x in library.catalogue())
    library.save_command('memory', 'RAM detail', 'free -h')
    changed = next(x for x in library.catalogue() if x['id']=='memory')
    assert changed['modified'] and changed['command']=='free -h'
    assert not next(x for x in service.diagnostic_options() if x['id']==key)['default_selected']
    library.reset_or_delete('memory')
    assert next(x for x in library.catalogue() if x['id']=='memory') == original[1]
    library.reset_or_delete(key)
    assert len(library.catalogue()) == 11
    with pytest.raises(KeyError):library.save_command('missing', 'x','pwd')
    with pytest.raises(ValueError):library.save_command(None,' ','pwd')
    with pytest.raises(ValueError):library.save_command(None,'x','\x00')

def test_selected_custom_and_edited_commands_execute(store, monkeypatch):
    known=store/'known_hosts';known.write_text('test')
    key=library.save_command(None,'Custom','printf custom')
    library.save_command('qla','Custom QLA','printf qla')
    calls=[]
    class Stream(io.BytesIO):
        def __init__(self):super().__init__(b'test output');self.channel=self
        def settimeout(self,x):pass
        def recv_exit_status(self):return 0
    class SSH:
        def load_host_keys(self,x):pass
        def set_missing_host_key_policy(self,x):pass
        def connect(self,*a,**kw):pass
        def close(self):pass
        def exec_command(self,command,**kw):calls.append(command);return None,Stream(),io.BytesIO(b'')
    monkeypatch.setattr(service.paramiko,'SSHClient',SSH)
    result=service.diagnose('host',22,'user','pw',str(known),[key,'qla'])
    assert set(calls)=={'printf custom','printf qla'}
    assert len(result['checks'])==2
    assert all(x['status']=='unknown' and x['exit_code']==0 and x['command'] in calls for x in result['checks'])
    assert result['fc_topology']==[]

def test_library_api_permissions_validation_and_crud(store, monkeypatch):
    import sys, types, importlib.util
    from fastapi import FastAPI, HTTPException
    from fastapi.testclient import TestClient
    from pathlib import Path
    auth = types.ModuleType('api_v2.main')
    def authenticated(request):
        role=request.headers.get('X-Test-Role')
        if not role:raise HTTPException(401,'Login required')
        return {'role':role}
    def csrf(request):
        if request.headers.get('X-CSRF-Token')!='test':raise HTTPException(403,'CSRF required')
    auth._require_authenticated_api=authenticated
    auth._require_csrf=csrf
    monkeypatch.setitem(sys.modules,'api_v2.main',auth)
    spec=importlib.util.spec_from_file_location('isolated_linux_health_api',Path(service.__file__).with_name('linux_health_api.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    app=FastAPI();app.include_router(module.router);client=TestClient(app)
    url='/api/linux-health/commands';body={'label':'My check','command':'uname -a'}
    assert client.get(url).status_code==401
    assert client.get(url,headers={'X-Test-Role':'viewer'}).status_code==403
    headers={'X-Test-Role':'operator'}
    assert client.post(url,headers=headers,json=body).status_code==403
    headers['X-CSRF-Token']='test'
    response=client.post(url,headers=headers,json=body);assert response.status_code==200
    key=response.json()['id']
    assert any(x['id']==key for x in client.get(url,headers=headers).json()['commands'])
    assert client.put(url+'/'+key,headers=headers,json={'label':'Changed','command':'pwd'}).status_code==200
    assert client.put(url+'/missing',headers=headers,json=body).status_code==404
    assert client.post(url,headers=headers,json={'label':'','command':'pwd'}).status_code==422
    assert client.delete(url+'/'+key,headers=headers).status_code==200
