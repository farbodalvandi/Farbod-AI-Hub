"""Exercise the real Mac launcher with controlled Docker/HTTPS responses."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]
VERSION = re.search(r'^APP_VERSION = "([^"]+)"', (ROOT / 'app.py').read_text(), re.M)[1]

@pytest.mark.parametrize('payload,success', [
    ({'version': VERSION, 'build': VERSION + '-automation-enterprise'}, True),
    ({'version': '28.0.0', 'build': '28.0.0-automation-enterprise'}, False),
    ({'version': VERSION, 'build': 'wrong-build'}, False),
    ({}, False),
])
def test_start_opens_browser_only_after_matching_https_release(tmp_path, payload, success):
    project = tmp_path / 'project'
    (project / 'docker-macos').mkdir(parents=True)
    for name in ['common.sh', 'start.command']:
        shutil.copy2(ROOT / 'docker-macos' / name, project / 'docker-macos' / name)
    shutil.copy2(ROOT / 'app.py', project / 'app.py')
    binpath = tmp_path / 'bin'; binpath.mkdir()
    scripts = {
        'docker': '#!/bin/bash\nprintf "%s\\n" "$*" >> "$CALLS"\nexit 0\n',
        'curl': '#!/bin/bash\nprintf "%s\\n" "$MOCK_HEALTH"\n',
        'open': '#!/bin/bash\nprintf "%s" "$1" > "$OPENED"\n',
        'sleep': '#!/bin/bash\nexit 0\n',
    }
    for name, body in scripts.items():
        path = binpath / name; path.write_text(body); path.chmod(0o755)
    env = dict(os.environ, PATH=str(binpath) + ':' + os.environ['PATH'],
               MOCK_HEALTH=json.dumps(payload), OPENED=str(tmp_path/'opened'), CALLS=str(tmp_path/'calls'))
    result = subprocess.run(['bash', str(project/'docker-macos/start.command')], env=env,
                            capture_output=True, text=True, timeout=10, stdin=subprocess.DEVNULL)
    assert (result.returncode == 0) is success, result.stdout + result.stderr
    assert (tmp_path/'opened').exists() is success
    if success:
        assert (tmp_path/'opened').read_text() == 'https://localhost'
        assert VERSION + ' ' + VERSION + '-automation-enterprise' in (tmp_path/'calls').read_text()
    else:
        assert 'HTTPS verification failed' in result.stdout

@pytest.mark.parametrize('old', ['28.0.0', '28.1.0', '27.0.7', '28.2.0', '28.2.1', '28.2.2', '28.2.3'])
def test_existing_image_tag_upgrades_without_changing_data_path(tmp_path, old):
    project = tmp_path/'project'; (project/'docker-macos').mkdir(parents=True)
    shutil.copy2(ROOT/'docker-macos/common.sh', project/'docker-macos/common.sh')
    shutil.copy2(ROOT/'app.py', project/'app.py')
    config = project/'.env.docker'
    config.write_text(f"FHW_DOCKER_IMAGE=farbod-ai-hub:{old}\nFHW_DOCKER_DATA_DIR='/Users/test/My Data'\n")
    subprocess.run(['bash', '-c', 'source "$1"', 'test', str(project/'docker-macos/common.sh')], check=True)
    assert f'FHW_DOCKER_IMAGE=farbod-ai-hub:{VERSION}' in config.read_text()
    assert "FHW_DOCKER_DATA_DIR='/Users/test/My Data'" in config.read_text()
