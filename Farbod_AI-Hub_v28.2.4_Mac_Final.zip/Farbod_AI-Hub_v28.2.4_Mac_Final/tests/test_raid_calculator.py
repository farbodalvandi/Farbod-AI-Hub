"""Capacity, workflow persistence, validation and authorization regressions."""
import pytest
import database as db
from raid_calculator import calculate, dialog
from tests.test_v2488 import warehouse_db, client_for


@pytest.mark.parametrize('level,n,size,groups,expected',[
    ('0',8,'1.92',2,15.36), ('1',2,'1.92',2,1.92), ('1',4,'2',2,2),
    ('5',8,'1.92',2,13.44), ('6',8,'1.92',2,11.52),
    ('10',8,'1.92',2,7.68), ('50',12,'2',3,18), ('60',12,'2',3,12)])
def test_known_capacities(level,n,size,groups,expected):
    r=calculate(level,n,size,groups=groups)
    assert r['usable_tb']==pytest.approx(expected)
    assert r['raw_bytes']==r['usable_bytes']+r['overhead_bytes']+r['spare_bytes']
    assert r['usable_tib']==pytest.approx(expected*10**12/2**40)


def test_spares_and_binary_units():
    assert calculate('6',9,'960','GB',spares=1)['usable_tb']==5.76
    assert calculate('5',3,'1','TiB')['usable_tib']==2
    assert calculate('1',2,'1024','GiB')['usable_tib']==1
    assert calculate('5','۸','۱٫۹۲')['usable_tb']==13.44


@pytest.mark.parametrize('kwargs',[
    {'disks':'3.5'}, {'disks':True}, {'disks':0}, {'disks':10001},
    {'capacity':0}, {'capacity':-1}, {'capacity':'NaN'}, {'capacity':'Infinity'},
    {'capacity':'1e999'}, {'capacity':'1e-999'}, {'unit':'PB'}, {'spares':9}, {'spares':-1},
    {'level':'10','disks':5}, {'level':'6','disks':3}, {'level':'50','disks':7},
    {'level':'60','disks':10,'groups':3}, {'level':'50','groups':1}, {'level':'99'}])
def test_invalid_input(kwargs):
    data=dict(level='5',disks=8,capacity=2);data.update(kwargs)
    with pytest.raises(ValueError):calculate(**data)


def test_dialog_order_retry_cancel_and_farsi():
    answer,state,_=dialog('i want to create a raid')
    assert state['step']=='disks'
    _,bad,_=dialog('eight',state);assert bad['step']=='disks'
    _,state,_=dialog('8 disks',state);assert state['step']=='capacity'
    _,state,_=dialog('1.92 TB',state);assert state['step']=='level'
    answer,state,r=dialog('RAID 6',state)
    assert state is None and r['usable_tb']==11.52 and '11.5200 TB' in answer
    assert dialog('how much RAM do my servers have?') is None
    _,state,_=dialog('می‌خوام RAID بسازم')
    _,state,_=dialog('۸',state)
    _,state,_=dialog('۱٫۹۲ ترابایت',state)
    answer,state,r=dialog('۶',state)
    assert 'ظرفیت قابل استفاده' in answer and r['usable_tb']==11.52
    _,state,_=dialog('create raid')
    assert dialog('cancel',state)[1] is None


def test_nested_dialog_and_validation():
    state=None
    for q in ['create raid','12','2 TB','60']:
        _,state,r=dialog(q,state)
    assert state['step']=='groups'
    _,bad,_=dialog('5',state);assert bad['step']=='groups'
    _,state,r=dialog('3',state)
    assert state is None and r['usable_tb']==12


def test_form_and_persistent_chat(warehouse_db, monkeypatch):
    import app as module
    monkeypatch.setattr(module.search_service,'start_sync',lambda *a,**k:False)
    monkeypatch.setattr(module.InfrastructureAgent,'run',lambda *a,**k:pytest.fail('RAID must not call an LLM/search agent'))
    client=client_for('admin')
    assert module.app.test_client().get('/raid-calculator').status_code in (302,303,307)
    assert client.get('/raid-calculator').status_code==200
    assert '/raid-calculator' in client.get('/hardware-hub').text
    assert client.post('/raid-calculator',data={'level':'5'}).status_code==403
    data=dict(csrf='csrf-test',level='6',disks='8',capacity='1.92',unit='TB',spares='0',groups='2')
    assert '11.5200' in client.post('/raid-calculator',data=data).text
    bad=client.post('/raid-calculator',data=dict(data,disks='3'))
    assert 'at least 4 active disks' in bad.text and 'raid-usable' not in bad.text
    headers={'X-CSRF-Token':'csrf-test'}
    assert client.post('/ai-assistant/query',json={'q':'create raid'}).status_code==403
    response=client.post('/ai-assistant/query',headers=headers,json={'q':'i want to create a raid'})
    assert response.status_code==200,response.text
    r=response.json();cid=r['conversation_id'];assert r['raid']['step']=='disks'
    for q,step in [('8','capacity'),('1.92 TB','level')]:
        db.init_db();client=client_for('admin')
        response=client.post('/ai-assistant/query',headers=headers,json={'q':q,'conversation_id':cid})
        assert response.status_code==200,response.text
        assert response.json()['raid']['step']==step
    other=client_for('operator')
    assert other.post('/ai-assistant/query',headers=headers,json={'q':'RAID 6','conversation_id':cid}).status_code==404
    assert db.get_ai_raid_state(cid,'test-operator') is None
    r=client.post('/ai-assistant/query',headers=headers,json={'q':'RAID 6','conversation_id':cid}).json()
    assert r['raid']['result']['usable_tb']==11.52
    assert db.get_ai_raid_state(cid,'test-admin') is None
    assert len(r['history'])==8
