from pathlib import Path
import unittest

import yaml


ROOT = Path(__file__).resolve().parents[1]


class ContainerDefinitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.compose = yaml.safe_load((ROOT / "compose.yaml").read_text(encoding="utf-8"))

    def test_application_container_is_hardened_and_persistent(self):
        app = self.compose["services"]["app"]
        self.assertTrue(app["read_only"])
        self.assertIn("ALL", app["cap_drop"])
        self.assertIn("no-new-privileges:true", app["security_opt"])
        self.assertIn("/data", " ".join(app["volumes"]))
        self.assertIn("/backups", " ".join(app["volumes"]))
        self.assertNotIn("/var/run/docker.sock", " ".join(app["volumes"]))
        self.assertEqual(app["restart"], "unless-stopped")

    def test_backup_and_https_are_isolated_services(self):
        backup = self.compose["services"]["backup"]
        self.assertTrue(backup["healthcheck"]["disable"])
        self.assertEqual(backup["entrypoint"], ["/app/docker/backup-loop.sh"])
        caddy = self.compose["services"]["caddy"]
        self.assertIn("https", caddy["profiles"])
        self.assertNotIn("/var/run/docker.sock", " ".join(caddy["volumes"]))

    def test_v20_worker_is_hardened_and_health_checked(self):
        worker = self.compose["services"]["worker"]
        self.assertEqual(worker["command"], ["python", "/app/worker_v20.py"])
        self.assertTrue(worker["read_only"])
        self.assertIn("ALL", worker["cap_drop"])
        self.assertIn("worker-heartbeat", " ".join(worker["healthcheck"]["test"]))

    def test_image_uses_non_root_runtime_and_excludes_secrets(self):
        dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
        ignored = (ROOT / ".dockerignore").read_text(encoding="utf-8").splitlines()
        self.assertIn("USER fhw", dockerfile)
        self.assertIn("HEALTHCHECK", dockerfile)
        for item in (".env", "instance", "docker-data"):
            self.assertIn(item, ignored)


if __name__ == "__main__":
    unittest.main()
