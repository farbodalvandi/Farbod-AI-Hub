import io
import uuid
import zipfile
from contextlib import closing
from pathlib import Path
import pytest
from openpyxl import Workbook, load_workbook
import database as db
from warehouse import receive_serialized, create_item, move_stock, list_inventory
from file_preview import workbook_page
from tests.test_v2488 import warehouse_db, client_for, movement


def receipt(n=10, **kwargs):
    data=dict(name='DL380-gen10',manufacturer='HPE',model='DL380 Gen10',description='Delivery 10',
              movement_date='2026-10-25',quantity=str(n),serial_numbers=[f'SN-{i}' for i in range(n)],
              asset_tags=[f'FA-{i}' for i in range(n)],request_token=uuid.uuid4().hex)
    data.update(kwargs)
    return data


def test_serialized_receipt_group_and_individual_issue(warehouse_db):
    data=receipt();group=receive_serialized(data,'admin')
    assert receive_serialized(data,'admin')==group
    with closing(db.get_conn()) as conn:
        rows=conn.execute('SELECT * FROM warehouse_items WHERE group_id=?',(group,)).fetchall()
        assert len(rows)==10 and len({r['asset_tag'] for r in rows})==10
        assert len({r['code'] for r in rows})==10
        assert conn.execute('SELECT count(*) FROM warehouse_movements').fetchone()[0]==10
        parents=list_inventory(conn)
        assert len(parents)==1 and parents[0]['quantity']==10
        assert list_inventory(conn,'FA-7')[0]['quantity']==10
    move_stock(rows[4]['id'],movement(1,'OUT'),'admin')
    with closing(db.get_conn()) as conn:
        assert list_inventory(conn)[0]['quantity']==9
        assert conn.execute('SELECT quantity FROM warehouse_items WHERE id=?',(rows[4]['id'],)).fetchone()[0]==0
    client=client_for('admin')
    page=client.get(f'/warehouse/groups/{group}')
    assert page.status_code==200
    for i in range(10): assert f'SN-{i}' in page.text and f'FA-{i}' in page.text
    assert 'data-serialized-receipt' in client.get('/warehouse').text


@pytest.mark.parametrize('changes',[
    dict(asset_tags=['FA-0']),dict(serial_numbers=['SN-0']*10),dict(asset_tags=['FA-0']*10),
    dict(quantity='0'),dict(quantity='201')])
def test_bad_batch_is_atomic(warehouse_db,changes):
    with pytest.raises(ValueError):receive_serialized(receipt(**changes),'admin')
    with closing(db.get_conn()) as conn:
        assert conn.execute('SELECT count(*) FROM warehouse_items').fetchone()[0]==0
        assert conn.execute('SELECT count(*) FROM warehouse_movements').fetchone()[0]==0


def test_duplicate_receipt_and_existing_serial(warehouse_db):
    data=receipt(2);group=receive_serialized(data,'admin')
    with pytest.raises(ValueError):receive_serialized(dict(data,description='changed'),'admin')
    with pytest.raises(ValueError):receive_serialized(receipt(2),'admin')
    with pytest.raises(ValueError):create_item(dict(name='Duplicate',description='D',serial_number='sn-0'),'admin')
    db.init_db();db.init_db()
    with closing(db.get_conn()) as conn:
        assert conn.execute('SELECT sum(quantity) FROM warehouse_items WHERE group_id=?',(group,)).fetchone()[0]==2


def test_legacy_serials_are_grouped_without_ledger_changes(warehouse_db):
    ids=[create_item(dict(name='Legacy',description='D',serial_number=f'Legacy-{i}'),'admin') for i in range(2)]
    for i in ids:move_stock(i,movement(1),'admin')
    with closing(db.get_conn()) as conn,conn:
        conn.execute('UPDATE warehouse_items SET group_id=NULL')
        before=[tuple(r) for r in conn.execute('SELECT * FROM warehouse_movements')]
    db.init_db()
    with closing(db.get_conn()) as conn:
        assert len(list_inventory(conn))==1
        assert [tuple(r) for r in conn.execute('SELECT * FROM warehouse_movements')]==before


def test_legacy_repair_migration_and_resolution(warehouse_db):
    server=db.create_asset('servers',dict(model='DL380',status='Faulty'),'admin')
    with closing(db.get_conn()) as conn,conn:
        conn.execute('DROP TABLE asset_maintenance_logs')
        conn.execute("""CREATE TABLE asset_maintenance_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_table TEXT NOT NULL,asset_id INTEGER NOT NULL,event_date TEXT NOT NULL,description TEXT NOT NULL,
            severity TEXT NOT NULL CHECK(severity IN ('yellow','orange','red')),created_by TEXT NOT NULL,created_at TEXT NOT NULL)""")
        conn.execute("INSERT INTO asset_maintenance_logs VALUES(23,'servers',?,'2026-10-04','Old failure','red','admin','2026-10-04')",(server,))
    db.init_db();db.init_db()
    client=client_for('admin')
    assert 'data-repair-state="red"' in client.get(f'/assets/servers/{server}').text
    response=client.post(f'/assets/servers/{server}/edit',data=dict(csrf='csrf-test',model='DL380',status='Faulty',maintenance_severity='green',maintenance_date='2026-10-05'),follow_redirects=False)
    assert response.status_code in (302,303,307)
    assert db.get_asset('servers',server)['status']=='Resolved'
    page=client.get(f'/assets/servers/{server}').text
    assert 'data-repair-state="green"' in page and 'data-repair-state="red"' not in page
    assert 'Old failure' in page
    assert any(log['id']==23 for log in db.list_maintenance_logs('servers',server))
    from app import _asset_health
    assert _asset_health(db.get_asset('servers',server))=='healthy'


def test_neutral_change_and_status_resolution(warehouse_db):
    server=db.create_asset('servers',dict(model='DL380',status='Active'),'admin')
    db.add_maintenance_log('servers',server,'2026-10-04','Failed RAM','red','admin')
    db.add_maintenance_log('servers',server,'2026-10-05','Replaced RAM','change','admin')
    assert db.get_asset('servers',server)['status']=='Faulty'
    db.update_asset('servers',server,dict(model='DL380',status='Resolved'),'admin')
    client=client_for('admin');page=client.get(f'/assets/servers/{server}')
    assert 'data-repair-state="green"' in page.text
    export=client.get(f'/assets/servers/{server}/changes.xlsx')
    assert export.status_code==200
    book=load_workbook(io.BytesIO(export.content));assert book.active.max_row==3
    assert 'Replaced RAM' in [row[1].value for row in book.active.iter_rows()]


def test_excel_all_sheets_pagination_and_escaped_cells(tmp_path,warehouse_db,monkeypatch):
    import app as module
    monkeypatch.setattr(module,'EQUIPMENT_FILE_DIR',str(tmp_path))
    book=Workbook();ws=book.active;ws.title='First'
    for i in range(101): ws.append([f'row-{i}', '<script>alert(1)</script>' if i==0 else i])
    book.create_sheet('Second').append(['SECOND-SHEET'])
    book.save(tmp_path/'sample.xlsx')
    assert workbook_page(tmp_path/'sample.xlsx')['has_next']
    last=workbook_page(tmp_path/'sample.xlsx',page=2)
    assert not last['has_next'] and len(last['rows'])==1
    bank=db.create_equipment_bank('Test');sub=db.create_equipment_subcategory(bank['id'],'Test')
    row=db.add_equipment_file(sub['id'],'sample.xlsx','sample.xlsx','Excel',100,'admin','Test file')
    client=client_for('admin');url=f"/equipment/file/{row['id']}"
    page=client.get(url)
    assert page.status_code==200 and 'row-0' in page.text
    assert '&lt;script&gt;alert(1)&lt;/script&gt;' in page.text and '<script>alert(1)</script>' not in page.text
    assert 'SECOND-SHEET' in client.get(url+'?sheet=1').text
    original=client.get(url+'?download=1')
    assert original.content==(tmp_path/'sample.xlsx').read_bytes()
    assert 'attachment' in original.headers['content-disposition']
    assert module.app.test_client().get(url,follow_redirects=False).status_code in (302,303,307)


def test_knowledge_pdf_headers_and_word_tables(warehouse_db,tmp_path,monkeypatch):
    import app as module
    from pypdf import PdfWriter
    from docx import Document
    monkeypatch.setattr(module,'KNOWLEDGE_DIR',str(tmp_path))
    pdf=PdfWriter();pdf.add_blank_page(width=300,height=300);pdf.write(tmp_path/'test.pdf')
    row=db.add_knowledge_file('servers','test.pdf','test.pdf','PDF',100,'application/pdf','admin')
    client=client_for('admin');page=client.get(f"/knowledge/file/{row['id']}")
    assert page.status_code==200 and '<iframe' in page.text and 'Open PDF in a new tab' in page.text
    raw=client.get(f"/knowledge/raw/{row['id']}")
    assert raw.status_code==200 and raw.headers['x-frame-options']=='SAMEORIGIN'
    assert "frame-ancestors 'self'" in raw.headers['content-security-policy']
    assert client.get('/warehouse').headers['x-frame-options']=='DENY'
    doc=Document();doc.add_paragraph('WORD-PARAGRAPH');doc.add_table(rows=1,cols=1).cell(0,0).text='WORD-TABLE';doc.save(tmp_path/'test.docx')
    row=db.add_knowledge_file('servers','test.docx','test.docx','Word',100,'application/octet-stream','admin')
    page=client.get(f"/knowledge/file/{row['id']}")
    assert page.status_code==200 and 'WORD-PARAGRAPH' in page.text and 'WORD-TABLE' in page.text
    assert '<iframe' not in page.text


def test_knowledge_rejects_rs_files(warehouse_db,tmp_path,monkeypatch):
    import app as module
    import search_service
    monkeypatch.setattr(module,'KNOWLEDGE_DIR',str(tmp_path/'knowledge'))
    catalog=io.BytesIO(b'PK\x03\x04legacy catalog')
    client=client_for('admin')
    response=client.post('/knowledge/upload',data={
        'csrf':'csrf-test','category':'server','description':'Legacy HPE catalog',
        'file':(catalog,'sample.RS')
    },content_type='multipart/form-data',follow_redirects=True)
    assert response.status_code==200 and '0 document(s) uploaded; 1 unsupported file(s) skipped' in response.text
    assert db.list_knowledge_files('server')==[]
    legacy=db.add_knowledge_file('server','legacy.RS','legacy.RS','Legacy',4,'application/zip','admin')
    assert not any(d['source']=='Knowledge' and d['name']=='legacy.RS' for d in search_service.catalog())
    assert db.get_knowledge_file(legacy['id']) is not None


@pytest.mark.parametrize('port_count',[32,56,96])
def test_san_switch_port_map_and_connection_persistence(warehouse_db,port_count):
    switch=db.create_asset('san_switches',dict(manufacturer='Brocade',model='G620',port_count=str(port_count),fabric='A'),'admin')
    client=client_for('admin')
    page=client.get(f'/assets/san_switches/{switch}')
    assert page.status_code==200 and f'{port_count} ports' in page.text
    assert f'Port {port_count:02d}' in page.text
    response=client.post(f'/assets/san_switches/{switch}/ports/{port_count}',data={
        'csrf':'csrf-test','destination':'DL380 Gen12 / HBA1 P1','fabric':'Fabric A','notes':'WWPN 10:00:00:00:00:00:00:01'
    },follow_redirects=True)
    assert response.status_code==200 and 'DL380 Gen12 / HBA1 P1' in response.text
    assert f'Port {port_count:02d}' in response.text
    row=db.san_ports_for_switch(switch)[0]
    assert row['port_number']==port_count and row['fabric']=='Fabric A'
    with pytest.raises(ValueError,match='Invalid SAN port'):
        db.save_san_port(switch,port_count+1,'outside','A','','admin')


def test_knowledge_bulk_delete_is_category_scoped(warehouse_db,tmp_path,monkeypatch):
    import app as module
    monkeypatch.setattr(module,'KNOWLEDGE_DIR',str(tmp_path))
    paths=[]
    for name,category in [('manual-a.pdf','server'),('manual-b.docx','server'),('keep.pdf','storage')]:
        (tmp_path/name).write_bytes(b'test')
        row=db.add_knowledge_file(category,name,name,'test',4,'application/octet-stream','admin')
        if category=='server': paths.append(row)
        else: keep=row
    client=client_for('admin')
    page=client.get('/knowledge?category=server')
    assert page.status_code==200 and 'knowledge-bulk-delete-form' in page.text and 'Select all' in page.text
    response=client.post('/knowledge/bulk-delete',data={'csrf':'csrf-test','category':'server','file_ids':[str(r['id']) for r in paths]+[str(keep['id'])]},follow_redirects=True)
    assert response.status_code==200 and '2 document(s) deleted' in response.text
    assert db.get_knowledge_file(keep['id']) is not None and (tmp_path/'keep.pdf').exists()
    assert all(db.get_knowledge_file(r['id']) is None and not (tmp_path/r['stored_name']).exists() for r in paths)


def test_knowledge_batch_upload_returns_per_file_results(warehouse_db,tmp_path,monkeypatch):
    import app as module
    monkeypatch.setattr(module,'KNOWLEDGE_DIR',str(tmp_path/'knowledge'))
    client=client_for('admin')
    uploads=[]
    for title in ('Catalog A','Catalog B'):
        stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('catalog.html',f'<html><body><h1>{title}</h1></body></html>')
        stream.seek(0)
        response=client.post('/knowledge/upload',headers={'X-Knowledge-Batch':'1'},data={
            'csrf':'csrf-test','category':'server','description':'HPE catalog',
            'file':(stream,f"{title.replace(' ','_')}.RS")
        },content_type='multipart/form-data')
        assert response.status_code==200 and response.json['saved']==1
        uploads.extend(response.json['results'])
    assert [item['status'] for item in uploads]==['saved','saved']
    assert len(db.list_knowledge_files('server'))==2


def test_batch_post_and_csrf(warehouse_db):
    client=client_for('admin');data=receipt(10)
    assert client.post('/warehouse/serialized',data=data).status_code==403
    result=client.post('/warehouse/serialized',data=dict(data,csrf='csrf-test'),follow_redirects=False)
    assert result.status_code in (302,303,307)
    assert '/warehouse/groups/' in result.headers['location']
    assert client.get(result.headers['location']).status_code==200
