"""Regression checks for the 25.8.5 interface and release identity."""
import pytest
from tests.test_v2488 import warehouse_db, client_for

@pytest.mark.parametrize('path', ['/hardware-hub','/dashboard','/knowledge','/equipment','/linux-health','/warehouse','/monitoring','/ai-assistant','/operations','/operations/agents','/operations/connectors','/operations/jobs','/operations/digital-twin','/design-studio','/diagram','/users'])
def test_real_pages_load_new_interface(warehouse_db, path):
    response = client_for('admin').get(path)
    assert response.status_code == 200, (path, response.status_code)
    assert 'interface-v25-6.css?v=25.8.5' in response.text
    assert 'data-interface="25.8.5"' in response.text

def test_release_and_stylesheet(warehouse_db):
    client = client_for('admin')
    assert client.get('/healthz').json()['version'] == '26.3.3'
    css = client.get('/static/interface-v25-6.css?v=25.8.5')
    assert css.status_code == 200
    assert '.v256-health' in css.text
    home = client.get('/hardware-hub').text
    assert 'v256-release' in home and '25.8.5' in home
    for path in ['/knowledge', '/equipment', '/linux-health', '/dashboard']:
        assert path in home

def test_soft_glass_theme_and_non_overlapping_copilot(warehouse_db):
    client=client_for('admin')
    home=client.get('/hardware-hub').text
    assert 'soft-glass-theme.css' in home
    assert 'Soft Glass' in home
    nav=home.split('<nav class="v256-quick-nav"',1)[1].split('</nav>',1)[0]
    assert nav.count('<a ') == 1 and 'Command Center' in nav
    assert home.index('class="v12-launch copilot-top-strip"') < home.index('<main class="spatial-hub-main">')
    css=client.get('/static/soft-glass-theme.css').text
    assert 'html[data-theme-preset="soft-glass"]' in css
    copilot=client.get('/static/interface-v25-6.css').text
    assert 'position:relative!important' in copilot and 'max-height:42px!important' in copilot


def test_midnight_amber_theme_is_available_and_persistable():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    controller = (root / "static/theme-v24-6.js").read_text()
    css = (root / "static/soft-glass-theme.css").read_text()
    assert 'data-theme-preset-choice="midnight-amber"' in controller
    assert "midnight-amber" in controller
    assert 'html[data-theme-preset="midnight-amber"]' in css
    assert "26.3.3-https-login" in (root / "app.py").read_text()

def test_reference_refresh_and_appearance_choices_are_wired():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    controller = (root / "static/theme-v24-6.js").read_text()
    refresh = (root / "static/design-refresh-v25-9.css").read_text()
    base = (root / "templates/base.html").read_text()
    hub = (root / "templates/hardware_hub.html").read_text()
    assert "allowedModes=['light','dark','system']" in controller
    assert "fhw-accent" in controller and "data-accent-choice" in controller
    assert 'design-refresh-v25-9.css' in base and 'design-refresh-v25-9.css' in hub
    assert '.approved-dashboard .cc-metric:nth-child(1)' in refresh
    assert 'prefers-reduced-motion:reduce' in refresh


def test_requested_ui_refinements_are_present():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    base = (root / "templates/base.html").read_text()
    login = (root / "templates/login.html").read_text()
    hub = (root / "templates/hardware_hub.html").read_text()
    dashboard = (root / "templates/dashboard.html").read_text()
    login_css = (root / "static/login-refresh.css").read_text()
    shared_css = (root / "static/soft-glass-theme.css").read_text()
    assert base.index("sidebar-bottom") < base.index("online-users-panel") < base.index("logout-link")
    assert "login-utility-controls" in login and "_language_switch.html" in login
    assert "One clear view of every system" not in login_css
    assert "ds22-shell" in shared_css and "#263f69" in shared_css
    assert 'class="hub-language-switch"' in hub
    assert "ISO & Visio Library" not in dashboard and "isoUploadModal" not in dashboard
