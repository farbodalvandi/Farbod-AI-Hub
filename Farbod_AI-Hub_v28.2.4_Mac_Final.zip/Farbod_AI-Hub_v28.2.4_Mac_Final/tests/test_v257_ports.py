import pytest
import database as db
import port_map as pm
from tests.test_v2488 import warehouse_db,client_for

@pytest.fixture
def devices(warehouse_db):
    return (db.create_asset('servers',{'model':'DL380','serial_number':'S1'},'admin'),db.create_asset('storage',{'model':'Unity','serial_number':'ST1'},'admin'),db.create_asset('san_switches',{'model':'G620','port_count':'32'},'admin'))

def test_bidirectional_persistence_and_disconnect(devices):
    server,storage,san=devices
    pm.connect('servers',server,'HBA1 / P1','san_switches',san,'FC12','Fabric A','WWPN test','admin')
    assert pm.mappings('servers',server)['HBA1 / P1']['target_port']=='FC12'
    assert pm.mappings('san_switches',san)['FC12']['target_id']==server
    pm.disconnect('san_switches',san,'FC12','admin')
    assert pm.mappings('servers',server)=={} and pm.mappings('san_switches',san)=={}

def test_conflicts_and_type_validation_are_atomic(devices):
    server,storage,san=devices
    pm.connect('servers',server,'HBA1 / P1','san_switches',san,'FC12','A','','admin')
    with pytest.raises(ValueError,match='already connected'):
        pm.connect('storage',storage,'A / FC1','san_switches',san,'FC12','','','admin')
    assert pm.mappings('storage',storage)=={}
    with pytest.raises(ValueError,match='incompatible'):
        pm.connect('servers',server,'PSU1','storage',storage,'A / FC1','','','admin')
    with pytest.raises(ValueError):pm.connect('servers',server,'missing','storage',storage,'A / FC1','','','admin')

def test_configurable_ports_and_connected_protection(devices):
    server,storage,san=devices
    pm.configure('storage',storage,'Shelf / SAS1','SAS','Shelf 1',False,'admin')
    pm.configure('servers',server,'PSU2','Power','Power B',True,'admin')
    assert 'PSU2' not in pm.ports('servers',server)
    pm.connect('servers',server,'HBA1 / P1','san_switches',san,'FC12','','','admin')
    with pytest.raises(ValueError,match='Disconnect'):
        pm.configure('servers',server,'HBA1 / P1','FC','HBA',True,'admin')

def test_authenticated_panels_and_post_flow(devices):
    server,storage,san=devices;client=client_for('admin')
    for table,i,expected in [('servers',server,'HBA1 / P1'),('storage',storage,'Controller A'),('san_switches',san,'FC32')]:
        response=client.get(f'/assets/{table}/{i}/port-map')
        assert response.status_code==200 and expected in response.text
    base=f'/assets/servers/{server}/port-map'
    assert client.get(base+'?port=HBA1+%2F+P1&target=san_switches:'+str(san)).status_code==200
    data=dict(port='HBA1 / P1',target=f'san_switches:{san}',target_port='FC12',fabric='Fabric A',notes='<script>alert(1)</script>')
    assert client.post(base,data=data).status_code==403
    response=client.post(base,data=dict(data,csrf='csrf-test'),follow_redirects=True)
    assert response.status_code==200 and 'FC12' in response.text
    assert '<script>alert(1)</script>' not in response.text
    assert '&lt;script&gt;alert(1)&lt;/script&gt;' in response.text
    reverse=client.get(f'/assets/san_switches/{san}?port=12')
    assert reverse.status_code==200 and 'HBA1 / P1' in reverse.text
    assert client.post(base,data=dict(csrf='csrf-test',port='HBA1 / P1',action='disconnect')).status_code in (302,303,307)
    assert not pm.mappings('san_switches',san)

def test_network_switch_capacity_and_used_destination_filter(devices):
    server,storage,san=devices
    sw24=db.create_asset('network',{'model':'Access 24','port_count':'24'},'admin')
    sw48=db.create_asset('network',{'model':'Access 48','port_count':'48'},'admin')
    assert len(pm.ports('network',sw24))==24
    assert len(pm.ports('network',sw48))==48
    pm.connect('servers',server,'NIC / P1','network',sw24,'Port24','','','admin')
    response=client_for('admin').get(f'/assets/servers/{server}/port-map?port=NIC+%2F+P1&target=network:{sw24}')
    assert response.status_code==200 and 'Port24 · Ethernet' not in response.text
    with pytest.raises(ValueError,match='already connected'):
        pm.connect('storage',storage,'A / ETH1','network',sw24,'Port24','','','admin')

def test_read_only_access_and_invalid_asset(devices):
    server,storage,san=devices;client=client_for('operator')
    assert client.get(f'/assets/servers/{server}/port-map').status_code==200
    assert client.post(f'/assets/servers/{server}/port-map',data={'csrf':'csrf-test','action':'disconnect','port':'iLO'}).status_code==403
    assert client.get('/assets/nothing/1/port-map').status_code==404

def test_schema_upgrade_preserves_legacy_notes(devices):
    server,storage,san=devices
    db.save_san_port(san,1,'old destination','A','legacy WWPN','admin')
    db.init_db()
    assert db.san_ports_for_switch(san)[0]['destination']=='old destination'
    response=client_for('admin').get(f'/assets/san_switches/{san}/port-map')
    assert 'old destination' in response.text

def test_inline_panels_and_complete_build(devices):
    server,storage,san=devices
    client=client_for('admin')
    for table,i in [('servers',server),('storage',storage)]:
        page=client.get(f'/assets/{table}/{i}')
        assert page.status_code==200 and 'jack-socket' in page.text and 'Device panel &amp; port map' in page.text
    assert client.get('/healthz').json()['build']=='28.2.4-automation-enterprise'
