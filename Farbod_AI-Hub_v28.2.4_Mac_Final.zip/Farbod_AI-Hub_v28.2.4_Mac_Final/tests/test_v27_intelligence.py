from contextlib import closing
from datetime import date,timedelta
from io import BytesIO
import time
import pytest
import database as db
import port_map as pm
import asset_intelligence as ai
import redfish_inventory as rf
from tests.test_v2488 import warehouse_db,client_for

@pytest.fixture
def topology(warehouse_db):
    s=db.create_asset('servers',{'model':'QA Server','serial_number':'TEST-27','power_count':'2','ilo_ip':'10.20.1.5','rack':'QA-R1'},'admin')
    u1=db.create_asset('ups',{'model':'UPS-A'},'admin');u2=db.create_asset('ups',{'model':'UPS-B'},'admin')
    f1=db.create_asset('san_switches',{'model':'SAN-A','fabric':'Fabric A','port_count':'32'},'admin')
    f2=db.create_asset('san_switches',{'model':'SAN-B','fabric':'Fabric B','port_count':'32'},'admin')
    return s,u1,u2,f1,f2

def test_power_unknown_shared_and_diverse(topology):
    s,a,b,_,_=topology;key=('servers',s)
    assert ai.redundancy(key)['power']['state']=='unknown'
    db.set_power_assignment(*key,1,a,'admin')
    assert ai.impact(('ups',a))['affected'][0]['state']=='unknown'
    db.set_power_assignment(*key,2,a,'admin')
    assert ai.redundancy(key)['power']['state']=='shared_risk'
    assert ai.impact(('ups',a))['affected'][0]['state']=='all_recorded_power_sources_lost'
    db.set_power_assignment(*key,2,b,'admin')
    assert ai.redundancy(key)['power']['state']=='recorded_diversity'
    assert ai.impact(('ups',a))['affected'][0]['state']=='remaining_recorded_source'
    db.delete_asset('ups',b,'admin')
    assert ai.redundancy(key)['power']['state']=='unknown'

def test_fc_fabrics_and_cable_history(topology):
    s,_,_,a,b=topology;key=('servers',s)
    pm.connect(*key,'HBA1 / P1','san_switches',a,'FC1','A','','engineer')
    assert ai.redundancy(key)['fc']['state']=='shared_risk'
    pm.connect(*key,'HBA2 / P1','san_switches',b,'FC1','Fabric B','','engineer')
    assert ai.redundancy(key)['fc']['state']=='recorded_diversity'
    assert ai.impact(('san_switches',a))['affected'][0]['state']=='remaining_recorded_path'
    pm.disconnect(*key,'HBA2 / P1','engineer')
    for k in (key,('san_switches',b)):
        assert ai.history(k)[0]['kind']=='cable_disconnect'
        assert ai.history(k)[0]['actor']=='engineer'
    pm.connect(*key,'HBA2 / P1','san_switches',b,'FC1','A','','engineer')
    assert ai.redundancy(key)['fc']['state']=='unknown'

def test_duplicates_lifecycle_and_audit(topology):
    s,a,b,_,_=topology;key=('servers',s)
    db.create_asset('servers',{'model':'duplicate','serial_number':'test-27','ilo_ip':'10.20.1.5'},'admin')
    kinds={f['kind'] for f in ai.quality() if f['key']==key}
    assert {'duplicate_ip','duplicate_serial'}<=kinds
    assert 'unmapped_ports' not in kinds
    before=len(ai.history(key));row=dict(db.get_asset(*key));row['model']='Updated'
    db.update_asset(*key,row,'editor-user');event=ai.history(key)[0]
    assert event['actor']=='editor-user' and any(x['before']=='QA Server' and x['after']=='Updated' for x in event['changes'])
    db.update_asset(*key,row,'editor-user');assert len(ai.history(key))==before+1
    ai.save_lifecycle(key,{'purchase_date':'2020-01-01','next_service':date.today().isoformat(),'warranty_end':(date.today()-timedelta(days=1)).isoformat(),'reminder_days':'30'},'admin')
    assert {x['state'] for x in ai.reminders()}=={'due','overdue'}
    with pytest.raises(ValueError):ai.save_lifecycle(key,{'purchase_date':'2025-01-01','warranty_end':'2024-01-01'},'admin')
    assert ai.history(key)[0]['kind']=='lifecycle'
    db.set_power_assignment(*key,1,a,'admin');n=len(ai.history(key))
    db.set_power_assignment(*key,1,a,'admin');assert len(ai.history(key))==n
    db.init_db();assert db.get_asset(*key)['model']=='Updated' and len(ai.history(key))==n

def rf_result():return {'fields':{'model':'Read model','serial_number':'TEST-27','ram':'128 GiB','ilo_ip':'10.20.1.5'},'observations':{'health':'OK','power_state':'On','tls_verified':True}}

def test_redfish_preview_ownership_replay_and_conflict(topology):
    s,*_=topology;token=rf.preview(s,'admin',rf_result())
    with pytest.raises(ValueError):rf.apply(token,'other',['model'])
    with pytest.raises(ValueError):rf.apply(token,'admin',[])
    assert db.get_asset('servers',s)['model']=='QA Server'
    rf.apply(token,'admin',['ram']);row=db.get_asset('servers',s)
    assert row['ram']=='128 GiB' and row['model']=='QA Server' and row['rack']=='QA-R1'
    with pytest.raises(ValueError):rf.apply(token,'admin',['ram'])
    token=rf.preview(s,'admin',rf_result());row=dict(row);row['model']='Concurrent change';db.update_asset('servers',s,row,'other')
    with pytest.raises(ValueError,match='changed'):rf.apply(token,'admin',['model'])
    assert db.get_asset('servers',s)['model']=='Concurrent change'
    token=rf.preview(s,'admin',rf_result())
    with closing(db.get_conn()) as c,c:c.execute('UPDATE redfish_previews_v27 SET expires_at=? WHERE token=?',(time.time()-1,token))
    with pytest.raises(ValueError):rf.load_preview(token,'admin')
    mismatch=rf_result();mismatch['fields']['serial_number']='OTHER'
    with pytest.raises(ValueError,match='Serial'):rf.preview(s,'admin',mismatch)

def test_redfish_read_only_parser_and_paths():
    calls=[]
    def get(path):
        calls.append(path)
        return {'Members':[{'@odata.id':'/redfish/v1/Systems/1'}]} if path.endswith('/Systems/') else {'Manufacturer':'HPE','Model':'Fixture','SerialNumber':'FIXTURE','MemorySummary':{'TotalSystemMemoryGiB':256},'Status':{'Health':'OK'}}
    result=rf.fetch('10.20.1.5','reader','secret',get=get)
    assert calls==['/redfish/v1/Systems/','/redfish/v1/Systems/1']
    assert result['fields']['ram']=='256 GiB' and 'firmware' not in result['fields']
    assert 'secret' not in str(result)
    for path in ['https://example.com/steal','//example.com/redfish/v1','/redfish/v1/../bad','/redfish/v1/%2e%2e/bad','/redfish/v1/a?x=1']:
        with pytest.raises(ValueError):rf.safe_path(path)
    for ip in ['127.0.0.1','169.254.169.254','https://ilo','example.com']:
        with pytest.raises(ValueError):rf.validate_ip(ip)

def test_routes_csrf_permissions_shortcuts_and_qr(topology):
    s,*_=topology;admin=client_for('admin');url=f'/asset-tools/servers/{s}'
    for path in ['/asset-tools','/asset-tools/quality','/asset-tools/impact?table=ups&id=1','/asset-tools/search?q=TEST-27',url,url+'/redfish']:
        response=admin.get(path);assert response.status_code==200,(path,response.text[:200])
        assert 'data-workspace="assets"' in response.text
    assert admin.post(url,data={'next_service':'2030-01-01'}).status_code==403
    assert admin.post(url,data={'csrf':'csrf-test','next_service':'2030-01-01'}).status_code in (302,303,307)
    assert admin.post(url+'/favorite',data={'csrf':'csrf-test','favorite':'1'}).status_code in (302,303,307)
    admin.get(f'/assets/servers/{s}')
    home=admin.get('/hardware-hub').text
    assert home.count('class="workspace-card')==14 and '<aside class="app-sidebar">' not in home and 'hub-quick-access' not in home
    assert admin.post('/hub-shortcuts/workspaces',data={'csrf':'csrf-test','path':'/raid-calculator','favorite':'1'}).status_code in (302,303,307)
    with closing(db.get_conn()) as c:
        assert c.execute("SELECT favorite FROM user_workspaces_v27 WHERE username='test-admin' AND path='/raid-calculator'").fetchone()[0]==1
    operator=client_for('operator')
    assert operator.get(url).status_code==200
    assert operator.post(url,data={'csrf':'csrf-test'}).status_code==403
    assert operator.get(url+'/redfish').status_code==403
    assert 'QA Server' not in operator.get('/hardware-hub').text
    png=admin.get(url+'/qr.png?base=https://192.168.10.5')
    assert png.status_code==200 and png.content.startswith(b'\x89PNG')
    assert admin.get(url+'/qr.png?base=javascript:bad').status_code==400
    from asset_workflows import qr_target
    # This needs url_for's request context, validated through the QR page instead.
    page=admin.get(url+'?base=https://192.168.10.5').text
    assert f'https://192.168.10.5/assets/servers/{s}' in page
    from app import app
    assert app.test_client().get(url+'/report.pdf').status_code in (302,303,307)
    pdf=admin.get(url+'/report.pdf');assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
    from pypdf import PdfReader
    text=' '.join(p.extract_text() for p in PdfReader(BytesIO(pdf.content)).pages)
    assert 'TEST-27' in text and 'Lifecycle' in text and 'Automatic change history' in text

def test_redfish_form_apply_selected_fields(topology,monkeypatch):
    s,*_=topology;admin=client_for('admin');url=f'/asset-tools/servers/{s}/redfish'
    monkeypatch.setattr(rf,'fetch',lambda *args,**kw:rf_result()|{'systems':['/redfish/v1/Systems/1']})
    page=admin.post(url,data={'csrf':'csrf-test','ip':'10.20.1.5','username':'reader','password':'unique-secret','verify':'1'})
    assert page.status_code==200 and 'Review proposed changes' in page.text and 'unique-secret' not in page.text
    import re
    token=re.search(r'name="token" value="([^"]+)"',page.text).group(1)
    response=admin.post('/asset-tools/redfish/apply',data={'csrf':'csrf-test','token':token,'fields':['ram']})
    assert response.status_code in (302,303,307)
    assert db.get_asset('servers',s)['ram']=='128 GiB'
    assert ai.history(('servers',s))[0]['actor']=='test-admin'

def test_assistant_failure_is_grounded(topology):
    s,a,*_=topology;db.set_power_assignment('servers',s,1,a,'admin')
    assert 'unknown' in ai.assistant_answer(f'What if UPS #{a} fails?')
    assert ai.assistant_answer('What RAM does DL380 support?') is None
    admin=client_for('admin')
    response=admin.post('/ai-assistant/query',json={'q':f'What if UPS #{a} fails?'},headers={'X-CSRF-Token':'csrf-test'})
    assert response.status_code==200 and response.json()['provider']=='Recorded inventory analysis'
    assert 'unknown' in response.json()['answer']
