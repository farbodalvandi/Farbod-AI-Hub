from tests.test_v2488 import warehouse_db, client_for
import database as db
import asset_workflows

def test_quality_group_detail_filter_and_identity(warehouse_db,monkeypatch):
    a=db.create_asset('servers',{'model':'Same name'},'admin')
    b=db.create_asset('servers',{'model':'Same name'},'admin')
    findings=[{'key':('servers',a),'label':'Same name','kind':'incomplete','detail':'Missing owner'}, {'key':('servers',a),'label':'Same name','kind':'power_unknown','detail':'Missing UPS'}, {'key':('servers',b),'label':'Same name','kind':'incomplete','detail':'Missing serial'}]
    monkeypatch.setattr(asset_workflows.intelligence,'quality',lambda:findings)
    c=client_for('admin');page=c.get('/asset-tools/quality')
    assert page.status_code==200
    assert page.text.count('class="quality-equipment-link"')==2
    assert 'Missing owner' not in page.text
    detail=c.get(f'/asset-tools/quality?table=servers&id={a}')
    assert detail.status_code==200 and 'Missing owner' in detail.text and 'Missing UPS' in detail.text and 'Missing serial' not in detail.text
    assert 'Back to Data Quality' in detail.text
    filtered=c.get(f'/asset-tools/quality?table=servers&id={a}&kind=incomplete')
    assert 'Missing owner' in filtered.text and 'Missing UPS' not in filtered.text
    assert 'kind=incomplete' in filtered.text
    assert c.get('/asset-tools/quality?table=servers&id=999999').status_code==404

def test_warehouse_toolbar_and_home(warehouse_db):
    c=client_for('admin');w=c.get('/warehouse')
    assert w.status_code==200
    assert w.text.index('warehouse-toolbar')<w.text.index('Search code, name')
    assert 'id="warehouse-register"' in w.text and 'id="warehouse-batch"' in w.text
    h=c.get('/hardware-hub')
    assert h.status_code==200 and 'hub-quick-access' not in h.text and 'hub-section-title' not in h.text
