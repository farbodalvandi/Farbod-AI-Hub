from datetime import datetime, timezone

import automation_center
from tests.test_v2488 import client_for, warehouse_db


def test_read_only_quality_scan_is_saved_and_audited(tmp_path, monkeypatch, warehouse_db):
    monkeypatch.setattr('paths.runtime_dir', lambda: str(tmp_path / 'runtime'))
    emitted = []
    findings = [
        {'kind': 'incomplete', 'label': 'Server 1', 'detail': 'Missing owner', 'key': ['servers', 1]},
        {'kind': 'duplicate_ip', 'label': 'Server 2', 'detail': 'IP is shared', 'key': ['servers', 2]},
    ]
    result = automation_center.run(
        __import__('paths'), lambda: findings,
        lambda *event: emitted.append(event), actor='qa-admin', scheduled=True,
    )
    state = automation_center.load(__import__('paths'))
    assert result['finding_count'] == 2
    assert result['status'] == 'attention'
    assert result['counts'] == {'incomplete': 1, 'duplicate_ip': 1}
    assert state['last_scheduled_key'] == datetime.now().astimezone().strftime('%Y-%m-%d')
    assert state['runs'][0]['actor'] == 'qa-admin'
    assert emitted and emitted[0][0] == 'warning'


def test_scheduler_does_not_repeat_a_due_scan_same_day():
    now = datetime(2026, 10, 22, 15, 0, tzinfo=timezone.utc)
    config = {'enabled': True, 'schedule': 'daily', 'time': '14:00',
              'weekday': 3, 'last_scheduled_key': '2026-10-21'}
    assert automation_center._due(config, now)
    config['last_scheduled_key'] = '2026-10-22'
    assert not automation_center._due(config, now)
    config.update(schedule='weekly', weekday=2, last_scheduled_key='2026-10-21')
    assert not automation_center._due(config, now)


def test_automation_center_routes_allow_configuration_and_manual_scan(tmp_path, monkeypatch, warehouse_db):
    import asset_workflows
    monkeypatch.setattr(asset_workflows.paths, 'runtime_dir', lambda: str(tmp_path / 'runtime'))
    monkeypatch.setattr(asset_workflows.intelligence, 'quality', lambda: [])
    client = client_for('admin')
    page = client.get('/operations/automation')
    assert page.status_code == 200
    assert 'Automation Center' in page.text
    saved = client.post('/operations/automation', data={
        'csrf': 'csrf-test', 'action': 'settings', 'enabled': 'on',
        'schedule': 'daily', 'time': '02:15', 'weekday': '6',
    }, follow_redirects=True)
    assert saved.status_code == 200 and 'Automation schedule saved.' in saved.text
    run = client.post('/operations/automation', data={
        'csrf': 'csrf-test', 'action': 'run',
    }, follow_redirects=True)
    assert run.status_code == 200 and 'Inventory quality scan completed.' in run.text
    assert automation_center.load(asset_workflows.paths)['runs'][0]['status'] == 'clear'
    operator = client_for('operator')
    denied = operator.post('/operations/automation', data={
        'csrf': 'csrf-test', 'action': 'settings', 'schedule': 'weekly',
        'time': '02:00', 'weekday': '6',
    })
    assert denied.status_code == 403
