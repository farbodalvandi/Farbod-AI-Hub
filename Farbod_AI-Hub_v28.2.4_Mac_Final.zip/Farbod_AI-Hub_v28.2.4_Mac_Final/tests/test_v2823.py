from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import uuid
import pytest
from openpyxl import load_workbook
import database as db
import port_map as pm
import asset_intelligence as ai
from warehouse import receive_serialized, move_stock, create_item
from warehouse_reports import issue_bulk, report_rows
from tests.test_v2488 import warehouse_db, client_for


def receipt(n=2, **kw):
    d=dict(name='Test switch',manufacturer='Brand',model='Model',description='Shipment',quantity=str(n),
           serial_numbers=['']*n, asset_tags=['']*n, request_token=uuid.uuid4().hex,movement_date='2026-10-25')
    d.update(kw);return d

def movement(q=1,d='IN',**kw):
    values=dict(direction=d,quantity=str(q),notes='Movement',movement_date='2026-10-25',request_token=uuid.uuid4().hex)
    values.update(kw);return values

def units():
    with closing(db.get_conn()) as c: return c.execute('SELECT * FROM warehouse_items ORDER BY id').fetchall()

def bulk(ids,**kw):
    d=dict(item_ids=[str(i) for i in ids],notes='Deliver to rack',movement_date='2026-10-25',request_token=uuid.uuid4().hex)
    d.update(kw);return d

@pytest.mark.parametrize('table',['network','san_switches'])
@pytest.mark.parametrize('count',[1,8,32,100,128,256])
def test_capacity_and_panel(warehouse_db,table,count):
    i=db.create_asset(table,dict(model='switch',port_count=str(count)),'admin')
    assert len(pm.ports(table,i))==count
    client=client_for('admin');r=client.get(f'/assets/{table}/{i}')
    assert r.status_code==200 and f'{count} ports' in r.text
    if table=='san_switches': db.save_san_port(i,count,'Target','A','','admin')

@pytest.mark.parametrize('table',['network','san_switches'])
@pytest.mark.parametrize('count',['0','257','1.5','-1','abc',''])
def test_invalid_capacity(warehouse_db,table,count):
    with pytest.raises(ValueError):db.create_asset(table,{'port_count':count},'admin')

def test_icb_connections_and_remove_guard(warehouse_db):
    i=db.create_asset('hpe_synergy_servers',{'model':'Synergy',**{f'icb_{n}_notes':f'Module {n}' for n in range(1,7)}},'admin')
    assert len(pm.ports('hpe_synergy_servers',i))==96
    net=db.create_asset('network',{'port_count':'256'},'admin');san=db.create_asset('san_switches',{'port_count':'256'},'admin')
    pm.connect('hpe_synergy_servers',i,'ICB6 / NIC8','network',net,'Port256','','','admin')
    pm.connect('hpe_synergy_servers',i,'ICB6 / FC8','san_switches',san,'FC256','A','','admin')
    assert pm.mappings('network',net)['Port256']['target_port']=='ICB6 / NIC8'
    client=client_for('admin')
    assert 'ICB6 / FC8' in client.get(f'/assets/hpe_synergy_servers/{i}').text
    assert 'Module 6' in client.get(f'/assets/hpe_synergy_servers/{i}/port-map').text
    with pytest.raises(ValueError):db.update_asset('hpe_synergy_servers',i,{'icb_6_notes':''},'admin')
    for t,r in [('network',net),('san_switches',san)]:
        with pytest.raises(ValueError):db.update_asset(t,r,{'port_count':'255'},'admin')
    db.update_asset('hpe_synergy_servers',i,{'icb_6_notes':'New label'},'admin')
    assert pm.mappings('hpe_synergy_servers',i)['ICB6 / FC8']['target_id']==san

def test_unused_server_ports_not_findings(warehouse_db):
    i=db.create_asset('servers',{'model':'Server','serial_number':'S','rack':'A1'},'admin')
    assert not any(f['key']==('servers',i) and (f['kind']=='unmapped_ports' or f['kind'].startswith('fc_')) for f in ai.quality())
    net=db.create_asset('network',{'port_count':'8'},'admin')
    pm.connect('servers',i,'NIC / P1','network',net,'Port1','','','admin')
    assert not any(f['key']==('servers',i) and f['kind']=='unmapped_ports' for f in ai.quality())

def test_optional_identifiers_unique_and_unit_balance(warehouse_db):
    d=receipt(12);g=receive_serialized(d,'admin');assert receive_serialized(d,'admin')==g
    rows=units();assert len(rows)==12 and len({r['code'] for r in rows})==12
    assert all(r['quantity']==1 and r['group_id']==g for r in rows)
    with pytest.raises(ValueError): move_stock(rows[0]['id'],movement(),'admin')
    receive_serialized(receipt(2,serial_numbers=['S1',''],asset_tags=['','T1']),'admin')
    for kw in [dict(serial_numbers=['s1','']),dict(asset_tags=['t1','']),dict(serial_numbers=['x','X']),dict(asset_tags=['y','Y'])]:
        with pytest.raises(ValueError): receive_serialized(receipt(**kw),'admin')
    assert len(units())==14

@pytest.mark.parametrize('date',['','2026-02-30','2026-2-2','bad'])
def test_date_required_all_flows(warehouse_db,date):
    item=create_item({'name':'Parts','description':'Parts'},'admin')
    with pytest.raises(ValueError):move_stock(item,movement(movement_date=date),'admin')
    with pytest.raises(ValueError):receive_serialized(receipt(movement_date=date),'admin')
    with pytest.raises(ValueError):issue_bulk(bulk([item],movement_date=date),'admin')
    assert not report_rows({})

def test_bulk_100_atomic_replay_and_reports(warehouse_db):
    receive_serialized(receipt(100),'admin'); ids=[r['id'] for r in units()]
    invalid=bulk(ids+[999999])
    with pytest.raises(ValueError):issue_bulk(invalid,'admin')
    assert sum(r['quantity'] for r in units())==100
    data=bulk(ids,notes='=HYPERLINK("bad")')
    assert issue_bulk(data,'admin');assert not issue_bulk(data,'admin')
    with pytest.raises(ValueError):issue_bulk(dict(data,movement_date='2026-10-24'),'admin')
    assert sum(r['quantity'] for r in units())==0
    assert len(report_rows({}))==200
    assert len(report_rows({'direction':'OUT'}))==100
    assert len(report_rows({'item_id':str(ids[0])}))==2
    assert not report_rows({'date_from':'2026-10-26'})
    client=client_for('admin')
    response=client.get('/warehouse/report?direction=OUT&format=xlsx');assert response.status_code==200
    wb=load_workbook(BytesIO(response.content));assert wb.active.max_row==101
    assert wb.active['O2'].data_type=='s' and wb.active['O2'].value.startswith('=HYPERLINK')
    assert '200' in client.get('/warehouse/report').text

def test_concurrent_bulk_issue(warehouse_db):
    receive_serialized(receipt(),'admin');ids=[r['id'] for r in units()]
    def issue(_):
        try:return issue_bulk(bulk(ids),'admin')
        except ValueError:return False
    with ThreadPoolExecutor(max_workers=2) as pool:assert sorted(pool.map(issue,range(2)))==[False,True]
    assert len(report_rows({'direction':'OUT'}))==2

def test_bulk_quantity_and_permissions(warehouse_db):
    i=create_item({'name':'Cable','description':'Bulk'},'admin');move_stock(i,movement(12),'admin')
    d=bulk([i],**{f'quantity_{i}':'8'})
    assert issue_bulk(d,'admin') and units()[0]['quantity']==4
    admin=client_for('admin')
    for url in ['/warehouse','/warehouse/bulk-issue','/warehouse/report',f'/warehouse/{i}']:assert admin.get(url).status_code==200
    assert admin.post('/warehouse/bulk-issue',data=dict(bulk([i]),csrf='bad')).status_code==403
    viewer=client_for('operator')
    assert viewer.get('/warehouse/report').status_code==200
    assert viewer.get('/warehouse/bulk-issue').status_code==403
    assert viewer.post('/warehouse/bulk-issue',data=dict(bulk([i]),csrf='csrf-test')).status_code==403

def test_legacy_migration_no_ledger_rewrite(warehouse_db):
    i=create_item({'name':'Legacy','description':'Legacy'},'admin')
    with closing(db.get_conn()) as c,c:
        c.execute("INSERT INTO warehouse_movements(item_id,direction,quantity,before_qty,after_qty,notes,username,created_at,request_token) VALUES (?,'IN',1,0,1,'old','admin','2020-01-02T12:00:00','old-token')",(i,))
        c.execute('ALTER TABLE warehouse_movements DROP COLUMN movement_date')
        before=[dict(r) for r in c.execute('SELECT * FROM warehouse_movements')]
    db.init_db();db.init_db()
    with closing(db.get_conn()) as c:assert [{k:r[k] for k in r.keys() if k!='movement_date'} for r in c.execute('SELECT * FROM warehouse_movements')]==before
    row=report_rows({})[0];assert row['movement_date'] is None and row['event_date']=='2020-01-02'


def test_bulk_http_100_and_group_filter(warehouse_db):
    group=receive_serialized(receipt(100),'admin')
    ids=[r['id'] for r in units()]
    receive_serialized(receipt(1,name='Other'),'admin')
    client=client_for('admin')
    page=client.get(f'/warehouse/bulk-issue?group_id={group}')
    assert page.status_code==200 and page.text.count('name="item_ids"')==100
    data=dict(bulk(ids),csrf='csrf-test')
    bad=client.post('/warehouse/bulk-issue',data=dict(data,movement_date=''),follow_redirects=False)
    assert bad.status_code==400 and sum(r['quantity'] for r in units())==101
    response=client.post('/warehouse/bulk-issue',data=data,follow_redirects=False)
    assert response.status_code in (302,303,307)
    assert len(report_rows({'group_id':str(group),'direction':'OUT'}))==100
    assert sum(r['quantity'] for r in units())==1
