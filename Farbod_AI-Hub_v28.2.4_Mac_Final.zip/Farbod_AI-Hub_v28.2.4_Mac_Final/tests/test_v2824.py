import pytest
from pydantic import ValidationError
from tests.test_v2488 import warehouse_db, client_for
import linux_health_service as service
import linux_health_library as library

def test_pages_and_unchecked(warehouse_db,monkeypatch,tmp_path):
    monkeypatch.setenv('FHW_DATA_DIR',str(tmp_path))
    key=library.save_command(None,'My custom check','uname -a')
    client=client_for('admin')
    page=client.get('/linux-health');assert page.status_code==200
    assert '/linux-health/command-library' in page.text
    assert 'id="commandEditor"' not in page.text and 'id="commandLibrary"' not in page.text
    assert ' checked' not in page.text and key in page.text
    assert all(not c['default_selected'] for c in service.diagnostic_options())
    page=client.get('/linux-health/command-library');assert page.status_code==200
    assert 'id="commandEditor"' in page.text and 'id="commandFilter"' in page.text
    assert 'linux-health/app.js' not in page.text
    assert client_for('operator').get('/linux-health/command-library').status_code==200

def test_explicit_selection_required(monkeypatch,tmp_path):
    from linux_health_api import Target
    payload=dict(host='server',username='user',password='pw')
    for extra in ({},{'selected_checks':[]}):
        with pytest.raises(ValidationError):Target(**payload,**extra)
    assert Target(**payload,selected_checks=['memory']).selected_checks==['memory']
    monkeypatch.setenv('FHW_DATA_DIR',str(tmp_path))
    def fail():raise AssertionError('SSH must not start without explicit selection')
    monkeypatch.setattr(service.paramiko,'SSHClient',fail)
    for selected in (None,[],['missing']):
        with pytest.raises(ValueError):service.diagnose('server',22,'user','pw','missing',selected)
