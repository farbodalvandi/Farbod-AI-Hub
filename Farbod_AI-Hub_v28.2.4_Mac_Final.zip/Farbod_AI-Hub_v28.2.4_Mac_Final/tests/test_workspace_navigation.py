import re
import pytest
from tests.test_v2488 import warehouse_db, client_for
from workspace_navigation import workspace_section

@pytest.mark.parametrize('path,section',[
 ('/assets/servers/15/edit','assets'),('/assets/san_switches/3/port-map','assets'),
 ('/warehouse/groups/8','warehouse'),('/operations/digital-twin/3d','twin'),
 ('/design-studio','twin'),('/diagram','map'),('/operations/jobs','ai'),
 ('/ai-assistant/conversation/2/feedback','ai'),('/equipment/bank-connection','equipment'),
 ('/backups/prepare-restore/example.zip','backup'),('/raid-calculator','raid'),
 ('/hardware-hub','hub')])
def test_direct_route_ownership(path,section):
    assert workspace_section(path)==section

def test_hub_has_cards_without_application_sidebar(warehouse_db):
    page=client_for('admin').get('/hardware-hub')
    assert page.status_code==200
    assert page.text.count('class="workspace-card')==14
    assert '<aside class="app-sidebar">' not in page.text
    assert 'sidebar-collapse"' not in page.text
    assert 'class="neu-metrics"' not in page.text
    assert 'class="neu-search"' not in page.text
    assert 'profile-admin-link' in page.text

@pytest.mark.parametrize('route,workspace,expected,forbidden',[
 ('/dashboard','assets',['/assets/servers','/lookups'],['/operations/digital-twin','/raid-calculator','/backups']),
 ('/raid-calculator','raid',['/raid-calculator'],['/assets/servers','/monitoring','/backups']),
 ('/operations/digital-twin','twin',['/operations/digital-twin/3d','/design-studio'],['/diagram','/raid-calculator','/warehouse']),
 ('/diagram','map',['/diagram'],['/operations/digital-twin','/assets/servers']),
 ('/backups','backup',['/backups'],['/users','/raid-calculator','/monitoring']),
 ('/ai-assistant','ai',['/operations/agents','/operations/jobs'],['/monitoring','/backups','/assets/servers']),
 ('/monitoring','monitoring',['/monitoring'],['/operations/agents','/raid-calculator']),
 ('/warehouse','warehouse',['/warehouse'],['/assets/servers','/backups']),
 ('/settings','admin',['/settings','/users'],['/backups','/raid-calculator']),
])
def test_section_menu_stays_scoped(warehouse_db,route,workspace,expected,forbidden):
    page=client_for('admin').get(route)
    assert page.status_code==200,page.text[:200]
    nav=re.search(r'<nav class="sidebar-nav.*?</nav>',page.text,re.S).group(0)
    assert f'data-workspace="{workspace}"' in nav
    assert '/hardware-hub' in nav
    for href in expected:assert f'href="{href}"' in nav
    for href in forbidden:assert f'href="{href}"' not in nav

def test_viewer_does_not_gain_admin_links(warehouse_db):
    client=client_for('viewer')
    home=client.get('/hardware-hub').text
    assert 'profile-admin-link' not in home
    assert 'href="/backups"' not in home
    assert '<aside class="app-sidebar">' not in home

def test_login_has_explanation_and_accessible_form(warehouse_db):
    import app
    html=app.app.test_client().get('/login').text
    for marker in ['focus-story','Connected assets','Infrastructure AI','Plan and protect','for="username"','for="password"','name="csrf"','autocomplete="current-password"']:
        assert marker in html
