"""Transactional warehouse ledger. Stock codes and posted movements are immutable."""
import re
import json
import hashlib
import secrets
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
import database as db
from auth import current_user, role_required
from webcore import request, render_template, redirect, url_for, flash, abort


def ensure_schema(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS warehouse_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE COLLATE NOCASE,
        name TEXT NOT NULL, manufacturer TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '', serial_number TEXT NOT NULL DEFAULT '',
        location TEXT NOT NULL DEFAULT '', description TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
        created_by TEXT NOT NULL, created_at TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS warehouse_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL REFERENCES warehouse_items(id),
        direction TEXT NOT NULL CHECK(direction IN ('IN','OUT')),
        quantity INTEGER NOT NULL CHECK(quantity > 0),
        before_qty INTEGER NOT NULL CHECK(before_qty >= 0),
        after_qty INTEGER NOT NULL CHECK(after_qty >= 0),
        notes TEXT NOT NULL CHECK(length(trim(notes)) > 0),
        counterparty TEXT NOT NULL DEFAULT '', reference TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL, created_at TEXT NOT NULL,
        request_token TEXT NOT NULL UNIQUE)''')
    if 'movement_date' not in {r[1] for r in conn.execute('PRAGMA table_info(warehouse_movements)')}:
        conn.execute('ALTER TABLE warehouse_movements ADD COLUMN movement_date TEXT')
    conn.execute('CREATE TABLE IF NOT EXISTS warehouse_issues (token TEXT PRIMARY KEY, payload_hash TEXT NOT NULL)')
    conn.execute("""CREATE TABLE IF NOT EXISTS warehouse_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT, group_key TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL, manufacturer TEXT NOT NULL, model TEXT NOT NULL)""")
    columns = {row[1] for row in conn.execute('PRAGMA table_info(warehouse_items)')}
    if 'asset_tag' not in columns:
        conn.execute("ALTER TABLE warehouse_items ADD COLUMN asset_tag TEXT NOT NULL DEFAULT ''")
    if 'group_id' not in columns:
        conn.execute("ALTER TABLE warehouse_items ADD COLUMN group_id INTEGER REFERENCES warehouse_groups(id)")
    conn.execute("""CREATE TABLE IF NOT EXISTS warehouse_receipts (
        token TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, group_id INTEGER NOT NULL)""")
    conn.execute('CREATE INDEX IF NOT EXISTS warehouse_group_items ON warehouse_items(group_id)')
    # Older serial records keep their IDs, stock codes, quantities and ledger.
    for row in conn.execute("SELECT * FROM warehouse_items WHERE trim(serial_number)<>'' AND group_id IS NULL").fetchall():
        group_id = ensure_group(conn,row['name'],row['manufacturer'],row['model'])
        conn.execute('UPDATE warehouse_items SET group_id=? WHERE id=?',(group_id,row['id']))
    conn.execute('CREATE INDEX IF NOT EXISTS warehouse_history ON warehouse_movements(item_id,id DESC)')
    for action in ('UPDATE', 'DELETE'):
        conn.execute(f'''CREATE TRIGGER IF NOT EXISTS warehouse_no_{action.lower()}
            BEFORE {action} ON warehouse_movements BEGIN
            SELECT RAISE(ABORT, 'Posted movements cannot be changed; post a compensating movement'); END''')
    conn.execute('''CREATE TRIGGER IF NOT EXISTS warehouse_code_immutable
        BEFORE UPDATE OF code ON warehouse_items BEGIN
        SELECT RAISE(ABORT, 'Stock code cannot be changed'); END''')


def clean(value, label, limit=200, required=False):
    value = str(value or '').strip()
    if (required and not value) or len(value) > limit:
        raise ValueError(f'{label} is required and must be at most {limit} characters.' if required else f'{label} must be at most {limit} characters.')
    return value


def movement_date(data):
    value = clean(data.get('movement_date'), 'Movement date', 10, True)
    if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise ValueError('Enter a valid movement date (YYYY-MM-DD).')
    try:
        datetime.strptime(value, '%Y-%m-%d')
    except ValueError:
        raise ValueError('Enter a valid movement date (YYYY-MM-DD).')
    return value


def create_item(data, username):
    code = clean(data.get('code'), 'Stock code', 64) or 'WH-' + secrets.token_hex(6).upper()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{1,63}', code):
        raise ValueError('Stock code: use 2–64 letters, numbers, dots, underscores or hyphens.')
    fields = [clean(data.get(k), label, limit, required) for k,label,limit,required in (
        ('name','Equipment name',200,True), ('manufacturer','Brand',100,False),
        ('model','Model',200,False), ('serial_number','Serial number',200,False),
        ('location','Location',200,False), ('description','Description',5000,True))]
    now = datetime.now(timezone.utc).isoformat()
    tag = clean(data.get('asset_tag'), 'Asset tag', 200)
    with closing(db.get_conn()) as conn, conn:
        conn.execute('BEGIN IMMEDIATE')
        if fields[3] and any(fields[3].casefold() == r[0].strip().casefold() for r in conn.execute("SELECT serial_number FROM warehouse_items WHERE serial_number<>''")):
            raise ValueError('This serial number is already registered.')
        if tag and any(tag.casefold() == r[0].strip().casefold() for r in conn.execute("SELECT asset_tag FROM warehouse_items WHERE asset_tag<>''")):
            raise ValueError('This asset tag is already registered.')
        try:
            item_id = conn.execute('''INSERT INTO warehouse_items
                (code,name,manufacturer,model,serial_number,location,description,created_by,created_at)
                VALUES (?,?,?,?,?,?,?,?,?)''', [code.upper(), *fields, username, now]).lastrowid
        except sqlite3.IntegrityError as exc:
            raise ValueError('This stock code already exists. Choose a different code.') from exc
        conn.execute('UPDATE warehouse_items SET asset_tag=? WHERE id=?',(tag,item_id))
        if fields[3]:
            group_id = ensure_group(conn,fields[0],fields[1],fields[2])
            conn.execute('UPDATE warehouse_items SET group_id=?,asset_tag=? WHERE id=?',(group_id,tag,item_id))
        conn.execute('INSERT INTO system_log(username,action,details,created_at) VALUES (?,?,?,?)',
                     (username,'warehouse_item_create' ,f'{code.upper()}: {fields[0]}',now))
    return item_id


def move_stock(item_id, data, username):
    event_date = movement_date(data)
    direction = data.get('direction')
    raw_qty = str(data.get('quantity', '')).strip()
    if direction not in ('IN', 'OUT') or not re.fullmatch(r'[0-9]{1,9}', raw_qty) or int(raw_qty) < 1:
        raise ValueError('Choose IN or OUT and enter a positive whole quantity (maximum 999999999).')
    quantity = int(raw_qty)
    notes = clean(data.get('notes'), 'Movement description', 5000, True)
    party = clean(data.get('counterparty'), 'Supplier / recipient / destination', 200)
    reference = clean(data.get('reference'), 'Reference', 200)
    token = clean(data.get('request_token'), 'Submission token', 128, True)
    now = datetime.now(timezone.utc).isoformat()
    with closing(db.get_conn()) as conn, conn:
        conn.execute('BEGIN IMMEDIATE')
        previous = conn.execute('SELECT * FROM warehouse_movements WHERE request_token=?', (token,)).fetchone()
        if previous:
            if (previous['item_id'],previous['direction'],previous['quantity'],previous['notes'],previous['counterparty'],previous['reference'],previous['username'],previous['movement_date']) != (item_id,direction,quantity,notes,party,reference,username,event_date):
                raise ValueError('Submission token already used. Reload this page before recording a different movement.')
            return False
        item = conn.execute('SELECT * FROM warehouse_items WHERE id=?',(item_id,)).fetchone()
        if item is None: raise ValueError('Equipment not found.')
        after = item['quantity'] + (quantity if direction == 'IN' else -quantity)
        if after < 0: raise ValueError('Insufficient stock. Outgoing quantity exceeds current balance.')
        if after > 999999999: raise ValueError('Stock balance exceeds the supported maximum.')
        if (item['serial_number'] or item['asset_tag'] or item['group_id']) and after > 1:
            raise ValueError('A serialized item can hold only one unit. Create separate codes for separate serial numbers.')
        conn.execute('UPDATE warehouse_items SET quantity=? WHERE id=?',(after,item_id))
        conn.execute('''INSERT INTO warehouse_movements
            (item_id,direction,quantity,before_qty,after_qty,notes,counterparty,reference,username,created_at,request_token,movement_date)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
            (item_id,direction,quantity,item['quantity'],after,notes,party,reference,username,now,token,event_date))
        conn.execute('INSERT INTO system_log(username,action,details,created_at) VALUES (?,?,?,?)',
            (username,'warehouse_'+direction.lower(),f"{item['code']} | {quantity} | {item['quantity']} -> {after} | {notes}",now))
    return True


def ensure_group(conn,name,manufacturer,model):
    key = json.dumps([str(x).strip().casefold() for x in (name,manufacturer,model)],ensure_ascii=False)
    conn.execute('INSERT OR IGNORE INTO warehouse_groups(group_key,name,manufacturer,model) VALUES(?,?,?,?)',
                 (key,name,manufacturer,model))
    return conn.execute('SELECT id FROM warehouse_groups WHERE group_key=?',(key,)).fetchone()[0]


def list_inventory(conn,q=''):
    all_items = conn.execute('SELECT * FROM warehouse_items ORDER BY id DESC').fetchall()
    groups = {}
    query = q.casefold()
    for row in all_items:
        key = ('group',row['group_id']) if row['group_id'] else ('item',row['id'])
        if key not in groups:
            groups[key] = dict(row,quantity=0,unit_count=0,matched=False)
        item = groups[key]
        item['quantity'] += row['quantity']
        item['unit_count'] += 1
        item['matched'] |= query in ' '.join(str(row[k]) for k in ('code','name','manufacturer','model','serial_number','asset_tag','location')).casefold()
    return [item for item in groups.values() if item['matched']]


def receive_serialized(data,username):
    event_date = movement_date(data)
    name = clean(data.get('name'),'Equipment name',200,True)
    manufacturer = clean(data.get('manufacturer'),'Brand',100)
    model = clean(data.get('model'),'Model',200)
    location = clean(data.get('location'),'Location',200)
    description = clean(data.get('description'),'Receipt description',5000,True)
    token = clean(data.get('request_token'),'Submission token',128,True)
    raw_qty = str(data.get('quantity',''))
    if not raw_qty.isdigit() or not 1 <= int(raw_qty) <= 200:
        raise ValueError('Enter a quantity from 1 to 200.')
    quantity = int(raw_qty)
    getlist = data.getlist if hasattr(data,'getlist') else lambda key: data.get(key,[])
    serials = [clean(x,'Serial number',200) for x in getlist('serial_numbers')]
    tags = [clean(x,'Asset tag',200) for x in getlist('asset_tags')]
    if len(serials) != quantity or len(tags) != quantity:
        raise ValueError('Enter one serial number and one asset tag for every unit.')
    if len({x.casefold() for x in serials if x}) != sum(bool(x) for x in serials) or len({x.casefold() for x in tags if x}) != sum(bool(x) for x in tags):
        raise ValueError('Serial numbers and asset tags must be unique within this receipt.')
    payload = json.dumps([name,manufacturer,model,location,description,serials,tags,username,event_date],ensure_ascii=False)
    fingerprint = hashlib.sha256(payload.encode()).hexdigest()
    now = datetime.now(timezone.utc).isoformat()
    with closing(db.get_conn()) as conn,conn:
        conn.execute('BEGIN IMMEDIATE')
        prior = conn.execute('SELECT * FROM warehouse_receipts WHERE token=?',(token,)).fetchone()
        if prior:
            if prior['payload_hash'] != fingerprint:
                raise ValueError('Submission token already used. Reload the page for a new receipt.')
            return prior['group_id']
        existing_serials = {r[0].strip().casefold() for r in conn.execute("SELECT serial_number FROM warehouse_items WHERE serial_number<>''")}
        existing_tags = {r[0].strip().casefold() for r in conn.execute("SELECT asset_tag FROM warehouse_items WHERE asset_tag<>''")}
        if any(x and x.casefold() in existing_serials for x in serials):
            raise ValueError('A serial number is already registered. Open its existing record to receive it again.')
        if any(x and x.casefold() in existing_tags for x in tags):
            raise ValueError('An asset tag is already registered. Asset tags must be unique.')
        group_id = ensure_group(conn,name,manufacturer,model)
        for i,(serial,tag) in enumerate(zip(serials,tags)):
            code = 'WH-'+secrets.token_hex(8).upper()
            item_id = conn.execute("""INSERT INTO warehouse_items
                (code,name,manufacturer,model,serial_number,asset_tag,group_id,location,description,quantity,created_by,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,1,?,?)""",
                (code,name,manufacturer,model,serial,tag,group_id,location,description,username,now)).lastrowid
            move_token = 'batch-'+hashlib.sha256((token+':'+str(i)).encode()).hexdigest()
            conn.execute("""INSERT INTO warehouse_movements
                (item_id,direction,quantity,before_qty,after_qty,notes,counterparty,reference,username,created_at,request_token,movement_date)
                VALUES (?,'IN',1,0,1,?,'',?,?,?,?,?)""",
                (item_id,description,'Serialized receipt',username,now,move_token,event_date))
        conn.execute('INSERT INTO warehouse_receipts VALUES(?,?,?)',(token,fingerprint,group_id))
        conn.execute('INSERT INTO system_log(username,action,details,created_at) VALUES(?,?,?,?)',
                     (username,'warehouse_serialized_receipt',f'Group #{group_id}: {quantity} serialized units',now))
    return group_id


def home_context(q='',form=None,error=None,batch_form=None):
    with closing(db.get_conn()) as conn:
        items = list_inventory(conn,q)
        totals = conn.execute('SELECT count(*) codes,coalesce(sum(quantity),0) units FROM warehouse_items').fetchone()
    batch_form = batch_form or {}
    serials = batch_form.getlist('serial_numbers') if hasattr(batch_form,'getlist') else []
    tags = batch_form.getlist('asset_tags') if hasattr(batch_form,'getlist') else []
    return dict(items=items,totals=totals,q=q,form=form or {},error=error,
                batch_form=batch_form,batch_rows=list(zip(serials,tags)),
                batch_token=batch_form.get('request_token') or secrets.token_urlsafe(32))


def register_routes(app, module_required):
    from warehouse_reports import register_routes as register_reports
    register_reports(app, module_required)
    @app.route('/warehouse')
    @module_required('warehouse')
    def warehouse_home():
        q = request.args.get('q','').strip()[:200]
        return render_template('warehouse.html',**home_context(q))

    @app.route('/warehouse/items', methods=['POST'])
    @module_required('warehouse')
    @role_required('editor')
    def warehouse_create():
        try:
            item_id = create_item(request.form,current_user()['username'])
        except ValueError as exc:
            return render_template('warehouse.html',**home_context(form=request.form,error=str(exc))),400
        flash('Equipment registered with zero balance. Record a receipt to add stock.','success')
        return redirect(url_for('warehouse_item',item_id=item_id))

    @app.route('/warehouse/<int:item_id>', methods=['GET','POST'])
    @module_required('warehouse')
    def warehouse_item(item_id):
        error = None
        form = {}
        if request.method == 'POST':
            if db.ROLE_LEVEL.get(current_user()['role'],0) < db.ROLE_LEVEL['editor']: abort(403)
            form = request.form
            try:
                posted = move_stock(item_id,form,current_user()['username'])
            except ValueError as exc:
                error = str(exc)
            else:
                flash('Stock movement recorded.' if posted else 'This movement was already recorded; balance unchanged.','success')
                return redirect(url_for('warehouse_item',item_id=item_id))
        with closing(db.get_conn()) as conn:
            item = conn.execute('SELECT * FROM warehouse_items WHERE id=?',(item_id,)).fetchone()
            if item is None: abort(404)
            movements = conn.execute('SELECT * FROM warehouse_movements WHERE item_id=? ORDER BY id DESC',(item_id,)).fetchall()
        return render_template('warehouse_item.html',item=item,movements=movements,
            request_token=secrets.token_urlsafe(32),form=form,error=error),400 if error else 200

    @app.route('/warehouse/serialized', methods=['POST'])
    @module_required('warehouse')
    @role_required('editor')
    def warehouse_receive_serialized():
        try:
            group_id = receive_serialized(request.form,current_user()['username'])
        except ValueError as exc:
            return render_template('warehouse.html',**home_context(error=str(exc),batch_form=request.form)),400
        flash('Receipt saved. Each unit has its own stock code; serial number and asset tag are optional.','success')
        return redirect(url_for('warehouse_group',group_id=group_id))

    @app.route('/warehouse/groups/<int:group_id>')
    @module_required('warehouse')
    def warehouse_group(group_id):
        with closing(db.get_conn()) as conn:
            group = conn.execute('SELECT * FROM warehouse_groups WHERE id=?',(group_id,)).fetchone()
            if group is None: abort(404)
            units = conn.execute('SELECT * FROM warehouse_items WHERE group_id=? ORDER BY id',(group_id,)).fetchall()
        return render_template('warehouse_group.html',group=group,units=units,
            quantity=sum(unit['quantity'] for unit in units),batch_form=dict(group),batch_rows=[],batch_token=secrets.token_urlsafe(32))
