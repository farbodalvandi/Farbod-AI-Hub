"""Dated warehouse reports and atomic, replay-safe bulk issues."""
from contextlib import closing
from datetime import datetime, timezone
from io import BytesIO
import hashlib
import json
import secrets
import database as db
from auth import current_user, role_required
from webcore import request, render_template, redirect, url_for, flash, send_file
from warehouse import clean, movement_date


def issue_bulk(data, username):
    date = movement_date(data)
    notes = clean(data.get('notes'), 'Movement description', 5000, True)
    party = clean(data.get('counterparty'), 'Recipient / destination', 200)
    reference = clean(data.get('reference'), 'Reference', 200)
    token = clean(data.get('request_token'), 'Submission token', 128, True)
    raw_ids = data.getlist('item_ids') if hasattr(data, 'getlist') else data.get('item_ids', [])
    if not isinstance(raw_ids, (list, tuple)) or not 1 <= len(raw_ids) <= 1000:
        raise ValueError('Select from 1 to 1000 stock records.')
    selected = []
    for raw in raw_ids:
        value = str(raw)
        qty = str(data.get('quantity_' + value, '1')).strip()
        if not value.isascii() or not value.isdecimal() or not qty.isascii() or not qty.isdecimal() or not 1 <= int(qty) <= 999999999:
            raise ValueError('Invalid stock record or quantity.')
        selected.append((int(value), int(qty)))
    if len({i for i, q in selected}) != len(selected):
        raise ValueError('Select each stock record only once.')
    selected.sort()
    digest = hashlib.sha256(json.dumps([selected, date, notes, party, reference, username], ensure_ascii=False).encode()).hexdigest()
    now = datetime.now(timezone.utc).isoformat()
    with closing(db.get_conn()) as conn, conn:
        conn.execute('BEGIN IMMEDIATE')
        prior = conn.execute('SELECT payload_hash FROM warehouse_issues WHERE token=?', (token,)).fetchone()
        if prior:
            if prior[0] != digest:
                raise ValueError('Submission token already used. Reload for a new issue.')
            return False
        for item_id, qty in selected:
            item = conn.execute('SELECT * FROM warehouse_items WHERE id=?', (item_id,)).fetchone()
            if item is None or qty > item['quantity']:
                raise ValueError(f'Stock record #{item_id}: insufficient stock or record not found. No items were issued.')
            after = item['quantity'] - qty
            conn.execute('UPDATE warehouse_items SET quantity=? WHERE id=?', (after, item_id))
            move_token = 'issue-' + hashlib.sha256(f'{token}:{item_id}'.encode()).hexdigest()
            conn.execute('''INSERT INTO warehouse_movements
                (item_id,direction,quantity,before_qty,after_qty,notes,counterparty,reference,username,created_at,request_token,movement_date)
                VALUES (?,'OUT',?,?,?,?,?,?,?,?,?,?)''',
                (item_id, qty, item['quantity'], after, notes, party, reference, username, now, move_token, date))
        conn.execute('INSERT INTO warehouse_issues VALUES (?,?)', (token, digest))
        conn.execute('INSERT INTO system_log(username,action,details,created_at) VALUES (?,?,?,?)',
                     (username, 'warehouse_bulk_issue', f'{len(selected)} stock records / {sum(q for _,q in selected)} units / {date}', now))
    return True


def report_rows(filters):
    clauses, args = [], []
    for key, column in [('item_id', 'i.id'), ('group_id', 'i.group_id')]:
        value = str(filters.get(key, '') or '').strip()
        if value:
            if not value.isascii() or not value.isdecimal():
                raise ValueError('Choose a valid equipment record.')
            clauses.append(column + '=?'); args.append(int(value))
    direction = filters.get('direction', '')
    if direction:
        if direction not in ('IN','OUT'): raise ValueError('Choose IN or OUT.')
        clauses.append('m.direction=?'); args.append(direction)
    for key, op in [('date_from', '>='), ('date_to', '<=')]:
        value = filters.get(key, '')
        if value:
            value = movement_date({'movement_date': value})
            clauses.append(f"coalesce(m.movement_date,substr(m.created_at,1,10)) {op} ?"); args.append(value)
    if filters.get('date_from') and filters.get('date_to') and filters.get('date_from') > filters.get('date_to'):
        raise ValueError('Start date must not be after end date.')
    query = clean(filters.get('q'), 'Search', 200)
    if query:
        clauses.append("(i.code LIKE ? OR i.name LIKE ? OR i.model LIKE ? OR i.serial_number LIKE ? OR i.asset_tag LIKE ?)")
        args += ['%' + query + '%'] * 5
    where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
    with closing(db.get_conn()) as conn:
        return conn.execute('''SELECT m.*,i.code,i.name,i.manufacturer,i.model,i.serial_number,i.asset_tag,
            coalesce(m.movement_date,substr(m.created_at,1,10)) AS event_date
            FROM warehouse_movements m JOIN warehouse_items i ON i.id=m.item_id''' + where +
            ' ORDER BY event_date DESC,m.id DESC', args).fetchall()


def register_routes(app, module_required):
    @app.route('/warehouse/bulk-issue', methods=['GET','POST'])
    @module_required('warehouse')
    @role_required('editor')
    def warehouse_bulk_issue():
        form, error = {}, None
        if request.method == 'POST':
            form = request.form
            try:
                posted = issue_bulk(form, current_user()['username'])
            except ValueError as exc:
                error = str(exc)
            else:
                flash('Selected equipment issued.' if posted else 'This issue was already recorded; balance unchanged.', 'success')
                return redirect(url_for('warehouse_report'))
        group_id = request.args.get('group_id', type=int)
        with closing(db.get_conn()) as conn:
            rows = conn.execute('SELECT * FROM warehouse_items WHERE quantity>0' + (' AND group_id=?' if group_id else '') + ' ORDER BY name,model,id', (group_id,) if group_id else ()).fetchall()
        selected = set(form.getlist('item_ids')) if hasattr(form, 'getlist') else set()
        return render_template('warehouse_bulk_issue.html', units=rows, form=form, error=error, selected=selected,
                               request_token=form.get('request_token') or secrets.token_urlsafe(32)), 400 if error else 200

    @app.route('/warehouse/report')
    @module_required('warehouse')
    def warehouse_report():
        error = None
        try:
            rows = report_rows(request.args)
        except ValueError as exc:
            rows, error = [], str(exc)
        if request.args.get('format') == 'xlsx' and not error:
            from openpyxl import Workbook
            book = Workbook(); sheet = book.active; sheet.title = 'Warehouse movements'
            headers = ['Movement ID','Movement date','Date source','Recorded at (UTC)','Direction','Quantity','Stock code','Equipment','Brand','Model','Serial','Asset tag','Before','After','Description','Recipient / supplier','Reference','Operator']
            sheet.append(headers)
            for row in rows:
                values = [row['id'], row['event_date'], 'Entered' if row['movement_date'] else 'Legacy registration date', row['created_at'], row['direction'], row['quantity'], row['code'], row['name'], row['manufacturer'], row['model'], row['serial_number'], row['asset_tag'], row['before_qty'], row['after_qty'], row['notes'], row['counterparty'], row['reference'], row['username']]
                sheet.append(values)
                # User text must never become an Excel formula.
                for cell in sheet[sheet.max_row]:
                    if isinstance(cell.value, str): cell.data_type = 's'
            sheet.freeze_panes = 'A2'; sheet.auto_filter.ref = sheet.dimensions
            from openpyxl.utils import get_column_letter
            for i in range(1, len(headers)+1): sheet.column_dimensions[get_column_letter(i)].width = 22
            stream = BytesIO(); book.save(stream); stream.seek(0)
            return send_file(stream, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name='Farbod AI-Hub_Warehouse_Report.xlsx')
        with closing(db.get_conn()) as conn:
            items = conn.execute('SELECT id,code,name,serial_number,asset_tag FROM warehouse_items ORDER BY name,id').fetchall()
        totals = {d: sum(r['quantity'] for r in rows if r['direction']==d) for d in ('IN','OUT')}
        return render_template('warehouse_report.html', rows=rows, items=items, filters=request.args, totals=totals, error=error), 400 if error else 200
